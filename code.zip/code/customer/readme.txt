hw_gs是java后端
垃圾分类小助手是微信小程序前端
后端项目要求jdk为1.8（java 8）。
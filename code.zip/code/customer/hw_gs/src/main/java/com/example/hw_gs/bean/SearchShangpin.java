package com.example.hw_gs.bean;

import lombok.Data;
import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.solr.core.mapping.SolrDocument;

@Data
public class SearchShangpin {
    @Field("id")
    private String id;
    @Field("sp_name")
    private String name;
    @Field("sp_image")
    private String image;
    @Field("sp_jifen")
    private int jifen;
    @Field("sp_kucun")
    private int kucun;
    @Field("sp_oldprice")
    private float oldprice;
}

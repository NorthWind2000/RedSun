package com.example.hw_gs.utils;

public class ID {

    public static String getId(){
        String uuid= java.util.UUID.randomUUID().toString().replaceAll("-","");
        return uuid;
    }

}

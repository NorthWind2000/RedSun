package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class ShouyeLunbo {

    private String zxid;
    private String image;
    private String title;
}

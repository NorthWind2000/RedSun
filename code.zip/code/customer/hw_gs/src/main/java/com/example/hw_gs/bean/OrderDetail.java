package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class OrderDetail {
    private String oid;
    private String gid;
    private String gname;
    private String image;
    private int jifen;
    private int count;
}

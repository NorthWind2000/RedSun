package com.example.hw_gs.realm;

import com.example.hw_gs.bean.LoginUser;
import com.example.hw_gs.server.UserService;
import com.example.hw_gs.utils.RedisUtil;
import com.example.hw_gs.utils.UserToken;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerRealm extends AuthorizingRealm {
    @Autowired
    UserService userService;
    @Autowired
    RedisUtil redisUtil;

    @Override
    public boolean supports(AuthenticationToken token) {
        //这个token就是从过滤器中传入的jwtToken
        return token instanceof UserToken;
    }

    /**
     * 授权
     * @param principalCollection
     * @return
     */

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        //获取身份信息
        String primaryPrincipal=(String)principalCollection.getPrimaryPrincipal();
        //授权
        LoginUser user=userService.findUserByOpenid(primaryPrincipal);
        SimpleAuthorizationInfo simpleAuthorizationInfo=new SimpleAuthorizationInfo();
        return simpleAuthorizationInfo;
    }

    /**
     * 认证
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        String principal=(String)token.getPrincipal();
        LoginUser user=userService.findUserByOpenid(principal);
        if(user!=null) {
            SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(principal,"",this.getName());
            return simpleAuthenticationInfo;
        }
        else{
            return null;
        }
    }
}
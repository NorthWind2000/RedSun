package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class Xiaoqu {
    private String id;
    private String name;
    private String province;
    private String city;
    private String county;
    private String detailaddress;
}

package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.DongTai;
import com.example.hw_gs.bean.PingLun;
import com.example.hw_gs.server.ShequService;
import com.example.hw_gs.utils.ID;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@RestController
public class ShequController {

    @Autowired
    ShequService shequService;

    @PostMapping("/hwgs/shequ/dongtai")
    @CrossOrigin
    public JSONObject upLoadDongtai(HttpServletRequest request,@RequestParam("file")MultipartFile file){
        DongTai dongTai=new DongTai();
        MultipartHttpServletRequest params=((MultipartHttpServletRequest) request);
        dongTai.setId(ID.getId());
        dongTai.setOpenid(UserInfoGetter.getOpenid());
        dongTai.setNickname(params.getParameter("nickname"));
        dongTai.setContent(params.getParameter("content"));
        dongTai.setAvatar(params.getParameter("avatar"));
        dongTai.setPubtime(new Date());
        String imgpath=shequService.saveImg(file);
        if (imgpath!=null){
            dongTai.setImage(imgpath);
            shequService.saveDongtai(dongTai);
            return ResponseUtils.success(null);
        }else{
            return ResponseUtils.fail();
        }
    }

    @GetMapping("/hwgs/shequ/allcount")
    @CrossOrigin
    public JSONObject getDongtaiAllcount(){
        return ResponseUtils.success(shequService.getDongtaiAllcount());
    }

    @GetMapping("/hwgs/shequ/{curpage}")
    @CrossOrigin
    public JSONObject getDongtai(@PathVariable(name="curpage") int curpage){
        return ResponseUtils.success(shequService.getDongtai(curpage));
    }

    @PostMapping("/hwgs/pinglun")
    @CrossOrigin
    public void upPinglun(@RequestBody PingLun pingLun){
        pingLun.setId(ID.getId());
        pingLun.setOpenid(UserInfoGetter.getOpenid());
        pingLun.setPubtime(new Date());
        shequService.savePinglun(pingLun);
        shequService.pinglunplus(pingLun.getFid());
    }

    @GetMapping("/hwgs/pinglun/{fid}")
    @CrossOrigin
    public JSONObject getDongtai(@PathVariable(name="fid") String fid){
        return ResponseUtils.success(shequService.getPinglunByFid(fid));
    }

    @GetMapping("/hwgs/dongtai/like/{id}")
    @CrossOrigin
    public void dianzan(@PathVariable(name="id") String id){
        shequService.dianzan(id);
    }

//    @GetMapping("/hwgs/shequ/bangding")
//    @CrossOrigin
//    public JSONObject getDongtai(@PathVariable(name="fid") String fid){
//        return ResponseUtils.success(shequService.getPinglunByFid(fid));
//    }
}

package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.ShangPin;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ShangchengMapper {

    @Select("select count(*) from goods")
    public int selectGoodsAllcount();

    @Select("select * from goods where status=1 limit #{startindex},8")
    public List<ShangPin> selectGoodsByIndex(int startindex);

    @Select("select image from goodslunbo where gid = #{gid}")
    public List<String> getLunbo(String gid);

    @Select("select image from goodsxuanchuan where gid = #{gid}")
    public List<String> getXuanchuan(String gid);
}

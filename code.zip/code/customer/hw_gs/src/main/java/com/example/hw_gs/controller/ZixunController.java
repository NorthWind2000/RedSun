package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.server.ZixunService;
import com.example.hw_gs.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ZixunController {

    @Autowired
    ZixunService zixunService;

    @GetMapping("/hwgs/zixun/page/{curpage}")
    @CrossOrigin
    public JSONObject getZixun(@PathVariable(name="curpage") int curpage){
        return ResponseUtils.success(zixunService.getZiXun(curpage));
    }

    @GetMapping("/hwgs/zixun/first")
    @CrossOrigin
    public JSONObject getFirstZixun(){
        return ResponseUtils.success(zixunService.getFirstZixun());
    }

    @GetMapping("/hwgs/zixun/{zxid}")
    @CrossOrigin
    public JSONObject getZixun(@PathVariable(name="zxid") String zxid){
        return ResponseUtils.success(zixunService.getZiXunById(zxid));
    }

    @GetMapping("/hwgs/zixuncontent/{zxid}")
    @CrossOrigin
    public JSONObject getContent(@PathVariable(name="zxid") String zxid){
        return ResponseUtils.success(zixunService.getContentById(zxid));
    }

    @GetMapping("/hwgs/zixun/allcount")
    @CrossOrigin
    public JSONObject getZiXunAllcount(){
        return ResponseUtils.success(zixunService.getZiXunAllcount());
    }
}

package com.example.hw_gs.utils;
import com.alibaba.fastjson.JSONObject;

public class ResponseUtils {

    public static JSONObject success(Object data){
        JSONObject response = new JSONObject();
        response.put("code", 200);
        response.put("message", "success");
        response.put("data", data);
        return response;
    }

    public static JSONObject fail(){
        JSONObject response = new JSONObject();
        response.put("code", 401);
        response.put("message", "error");
        response.put("data", null);
        return response;
    }
}

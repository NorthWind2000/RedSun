package com.example.hw_gs.server;

import com.example.hw_gs.bean.ShoppingCar;
import com.example.hw_gs.mapper.ShoppingCarMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShoppingcarService {
    @Autowired
    ShoppingCarMapping shoppingCarMapping;

    public void addShoppingcar(ShoppingCar shoppingCar){
        shoppingCarMapping.insertShoppingcar(shoppingCar);
    }

    public ShoppingCar[] selectShoppingcar(String openid){
        return shoppingCarMapping.selectShoppingCarByOpenid(openid);
    }

    public void deleteJilu(String id){
        shoppingCarMapping.deleteJilu(id);
    }
}

package com.example.hw_gs.utils;

import java.util.HashMap;

public class UserInfoGetter {

    private static String Openid=null;
    private static String Token=null;

    public static void setInfo(String openid,String token){
        Openid=openid;
        Token=token;
    }

    public static void resetInfo(){
        Openid=null;
        Token=null;
    }
    public static HashMap<String,String> getInfo(){
        HashMap<String,String> usermap=new HashMap<String,String>();
        usermap.put("openid",Openid);
        usermap.put("token",Token);
        return usermap;
    }
    public static String getOpenid(){
        return Openid;
    }

}

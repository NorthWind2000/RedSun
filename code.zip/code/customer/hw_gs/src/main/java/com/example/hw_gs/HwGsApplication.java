package com.example.hw_gs;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@MapperScan(value = "com.example.hw_gs.mapper")
@SpringBootApplication
public class HwGsApplication {

    public static void main(String[] args) {
        SpringApplication.run(HwGsApplication.class, args);
    }

}

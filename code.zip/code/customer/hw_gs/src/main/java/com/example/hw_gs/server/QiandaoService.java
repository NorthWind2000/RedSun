package com.example.hw_gs.server;

import com.example.hw_gs.bean.LoginUser;
import com.example.hw_gs.mapper.UserMapper;
import com.example.hw_gs.utils.RedisUtil;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

@Service
public class QiandaoService {

    @Autowired
    RedisTemplate redisTemplate;
    @Autowired
    UserMapper userMapper;
    @Autowired
    RedisUtil redisUtil;

    Calendar cal = Calendar.getInstance();

    public void daKa(int day){
        String openid= UserInfoGetter.getOpenid();
        redisTemplate.opsForValue().setBit(openid,day,true);
        userMapper.qiandao(openid);
    }

    public ArrayList<String> getDaka() {
        String openid = UserInfoGetter.getOpenid();
        ArrayList<String> signdata = new ArrayList<>();
        int d = cal.get(Calendar.DATE);
        for (int i = 1; i <= d; i++) {
            if (redisTemplate.opsForValue().getBit(openid, i)) {
                signdata.add(i+"");
            }
        }
        return signdata;
    }
}

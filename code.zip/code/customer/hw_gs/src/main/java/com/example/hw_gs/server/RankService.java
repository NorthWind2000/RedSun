package com.example.hw_gs.server;

import com.example.hw_gs.bean.LJ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class RankService {

    @Autowired
    private RedisTemplate redisTemplate;

    public void addLJ(String key, LJ lj, double confidence){
        ZSetOperations zSet=redisTemplate.opsForZSet();
        try{
            double d=zSet.score(key,lj);
            zSet.incrementScore(key,lj,d+confidence);
        }catch (Exception e){
            zSet.add(key,lj,confidence);
        }
    }

     public Set getRank(String key){
        Set rank=redisTemplate.opsForZSet().reverseRange(key,0,15);
        return rank;
     }

}

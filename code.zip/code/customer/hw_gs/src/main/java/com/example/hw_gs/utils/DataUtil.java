package com.example.hw_gs.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DataUtil {
    private static SimpleDateFormat sdf = new SimpleDateFormat();// 格式化时间
    public static String getHour(){
        sdf.applyPattern("HH");// a为am/pm的标记
        Date date = new Date();// 获取当前时间
        String data=sdf.format(date);
        return data;
    }
}

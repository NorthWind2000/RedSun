package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.ShiTi;
import com.example.hw_gs.server.DatiService;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DatiController {

    @Autowired
    DatiService datiService;

    @GetMapping("/hwgs/dati")
    public JSONObject getShiTi(){
        return ResponseUtils.success(datiService.getShiTi());
    }
    @PutMapping("/hwgs/dati/{jifen}")
    public void updateJifen(@PathVariable(name="jifen") int jifen){
        datiService.updateJifen(UserInfoGetter.getOpenid(),jifen);
    }
}

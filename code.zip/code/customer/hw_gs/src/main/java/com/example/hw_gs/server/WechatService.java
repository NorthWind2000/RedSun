package com.example.hw_gs.server;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;

@Service
public class WechatService {

    @Autowired
    UserMapper userMapper;

    private String code;
    private String APPID="wx95c146843fe3eac7";
    private String SECRET="9060d841bd2d7970f12b9d093533a0dc";
//    private String APPID="wx5e2032bcdb1aecca";
//    private String SECRET="1e562fb20109489a4947ab95c124e823";

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getOpenid() {
        String url = "https://api.weixin.qq.com/sns/jscode2session?appid=" + APPID + "&secret=" + SECRET + "&js_code=" + code + "&grant_type=authorization_code";
        RestTemplate client = new RestTemplate();
        String response = client.getForObject(url, String.class);
        JSONObject res = (JSONObject) JSONObject.parse(response);
        String openid = res.getString("openid");
        return openid;
    }
}
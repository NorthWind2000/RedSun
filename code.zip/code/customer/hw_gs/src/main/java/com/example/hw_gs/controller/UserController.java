package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.LoginUser;
import com.example.hw_gs.bean.ShoppingCar;
import com.example.hw_gs.server.ShoppingcarService;
import com.example.hw_gs.server.UserService;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserToken;
import com.example.hw_gs.server.JwtService;
import com.example.hw_gs.server.WechatService;
import com.example.hw_gs.utils.RedisUtil;
import com.example.hw_gs.utils.UserInfoGetter;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UnknownAccountException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.apache.shiro.subject.Subject;

import java.util.HashMap;
import java.util.Map;

@RestController
public class UserController {

    @Autowired
    RedisUtil redisUtil;
    @Autowired
    UserService userService;
    @Autowired
    WechatService wechatService;

    @GetMapping("/post/{code}")
    @CrossOrigin
    public JSONObject logi1n(@PathVariable(name="code") String code){
        System.out.println(code);
        return ResponseUtils.success(10);
    }
    //登录
    @GetMapping("/hwgs/login/{code}")
    public JSONObject login(@PathVariable(name="code") String code){
        wechatService.setCode(code);
        String openid=wechatService.getOpenid();

        JwtService jwtService=new JwtService("2575868186", SignatureAlgorithm.HS256);
        Map<String, Object> chaim = new HashMap<>();
        chaim.put("openid",openid);
        String token = jwtService.encode(openid, 180*24*60*60*1000, chaim);
        Subject subject = SecurityUtils.getSubject();
        UserToken jwtToken=new UserToken(token);
        try {
//            委托 realm 进行登录认证
//            所以这个地方最终还是调用JwtRealm进行的认证
            subject.login(jwtToken);
        } catch (UnknownAccountException e) {
            userService.register(openid);
//            redisUtil.set(openid,loginUser);
            UserInfoGetter.setInfo(openid,token);
        }
        return ResponseUtils.success(token);
    }

    @PostMapping("/hwgs/user/update")
    public void updateUser(@RequestBody LoginUser user){
        userService.updateUser(user);
    }

    @GetMapping("/hwgs/user")
    public JSONObject getUserByOpenid(){
        return ResponseUtils.success(userService.findUserByOpenid(UserInfoGetter.getOpenid()));
    }

    @GetMapping("/hwgs/user/jifen")
    public JSONObject getJifenByOpenid(){
        return ResponseUtils.success(userService.getJifenByOpenid(UserInfoGetter.getOpenid()));
    }
}

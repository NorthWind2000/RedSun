package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.ShoppingCar;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ShoppingCarMapping {
    @Select("select * from shoppingcar where openid=#{openid}")
    public ShoppingCar[] selectShoppingCarByOpenid(String openid);

    @Insert("insert into shoppingcar(id,openid,gid,gname,count,jifen,image) values(#{id},#{openid},#{gid},#{gname},#{count},#{jifen},#{image})")
    public void insertShoppingcar(ShoppingCar shoppingCar);

    @Delete("delete from shoppingcar where id=#{id}")
    public void deleteJilu(String id);
}

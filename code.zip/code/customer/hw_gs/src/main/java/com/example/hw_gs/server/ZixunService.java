package com.example.hw_gs.server;

import com.example.hw_gs.bean.ShouyeLunbo;
import com.example.hw_gs.bean.ZiXun;
import com.example.hw_gs.mapper.ZixunMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZixunService {

    @Autowired
    ZixunMapper zixunMapper;

    public int getZiXunAllcount(){
        return zixunMapper.selectZixunAllcount();
    }

    public List<ZiXun> getZiXun(int index){
        int startindex=(index-1)*7;
        return zixunMapper.selectZixunByIndex(startindex,7);
    }

    public List<ShouyeLunbo> getFirstZixun(){
        return zixunMapper.selectLunBo();
    }

    public ZiXun getZiXunById(String zxid){

        return zixunMapper.selectZixunById(zxid);
    }

    public String getContentById(String zxid){
        return zixunMapper.selectContentById(zxid);
    }

}

package com.example.hw_gs.utils;

import com.example.hw_gs.server.JwtService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.shiro.authc.AuthenticationToken;

//这个就类似UsernamePasswordToken
public class UserToken implements AuthenticationToken {

    private JwtService jwtService=new JwtService("2575868186", SignatureAlgorithm.HS256);
    private String jwt;

    public UserToken(String jwt) {
        this.jwt = jwt;
    }

    @Override
    public String getPrincipal() {
        Claims claims = jwtService.decode(jwt);
        return claims.get("openid").toString();
    }

    @Override
    public String getCredentials() {
        return "";
    }
}
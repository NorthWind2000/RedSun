package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.DongTai;
import com.example.hw_gs.bean.PingLun;
import com.example.hw_gs.bean.ZiXun;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ShequMapper {

    @Insert("insert into dongtai(id,openid,pubtime,content,image,nickname,avatar) values(#{id},#{openid},#{pubtime},#{content},#{image},#{nickname},#{avatar})")
    public void addDongtai(DongTai dongTai);

    @Select("select * from dongtai where id=#{id} ")
    public DongTai selectDongtaiById(String id);

    @Select("select * from dongtai limit #{startindex},#{count}")
    public List<DongTai> selectDongtaiByIndex(int startindex, int count);

    @Insert("insert into pinglun(id,fid,content,pubtime,openid,nickname,avatar) values(#{id},#{fid},#{content},#{pubtime},#{openid},#{nickname},#{avatar})")
    public void addPingLun(PingLun pingLun);

    @Select("select * from pinglun where fid=#{fid}")
    public List<PingLun> selectPinglunByFid(String fid);

    @Update("update dongtai set likenum=likenum+1 where id=#{id}")
    public void dianzan(String id);

    @Update("update dongtai set commentnum=commentnum+1 where id=#{id}")
    public void pinglunplus(String id);

    @Select("select count(*) from dongtai")
    public int selectDongtaiAllcount();
}

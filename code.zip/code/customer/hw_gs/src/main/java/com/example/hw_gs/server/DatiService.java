package com.example.hw_gs.server;

import com.example.hw_gs.bean.ShiTi;
import com.example.hw_gs.mapper.DatiMapper;
import com.example.hw_gs.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;

@Service
public class DatiService {

    @Autowired
    DatiMapper datiMapper;
    @Autowired
    UserMapper userMapper;
    Random r = new Random();

    public ShiTi[] getShiTi(){
        HashSet<Integer> tihao=new HashSet<>();
        while(true) {
            int num = r.nextInt(100);
            tihao.add(num);
            if(tihao.size()==10){
                break;
            }
        }
        Iterator<Integer> iterator =tihao.iterator();
        int[] TH=new int[10];
        for(int i=0;iterator.hasNext();i++){
            TH[i]=iterator.next();
        }
        return datiMapper.getShiTi(TH);
    }

    public void updateJifen(String openid,int jifen){
        userMapper.updateJifen(openid,jifen);
    }
}

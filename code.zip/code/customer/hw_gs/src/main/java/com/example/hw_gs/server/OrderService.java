package com.example.hw_gs.server;

import com.example.hw_gs.bean.Order;
import com.example.hw_gs.bean.OrderDetail;
import com.example.hw_gs.mapper.OrderMapper;
import com.example.hw_gs.mapper.XiaoquMapper;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    OrderMapper orderMapper;
    @Autowired
    XiaoquMapper xiaoquMapper;

    public Order selectOrder(String oid){
        return orderMapper.selectOrder(oid);
    }

    public Order[] getOrderByOpenid(String openid,int status){
        return orderMapper.selectOrderByOpenid(openid,status);
    }

    public void addOrder(Order order){
        order.setXiaoquid(xiaoquMapper.selectXiaoquidByOpenid(UserInfoGetter.getOpenid()));
        orderMapper.insertDingdan(order);
    }

    public void addOrderDetail(OrderDetail orderDetail){
        orderMapper.insertDingdanDetail(orderDetail);
    }

    public OrderDetail[] getOrderDetailByOid(String oid){
        return orderMapper.selectOrderDetail(oid);
    }

    public void shouhuo(String oid){
        orderMapper.shouhuo(oid);
    }
}

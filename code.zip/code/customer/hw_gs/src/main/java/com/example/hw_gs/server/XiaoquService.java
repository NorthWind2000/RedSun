package com.example.hw_gs.server;

import com.example.hw_gs.bean.Huishou;
import com.example.hw_gs.bean.Xiaoqu;
import com.example.hw_gs.mapper.XiaoquMapper;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class XiaoquService {

    @Autowired
    XiaoquMapper xiaoquMapper;

    public List<Xiaoqu> selectXiaoquByKeyWord(String keywords){
        return xiaoquMapper.selectXiao(keywords);
    }

    public void addHuishou(Huishou huishou){
        huishou.setOpenid(UserInfoGetter.getOpenid());
        huishou.setXiaoquid(xiaoquMapper.selectXiaoquidByOpenid(UserInfoGetter.getOpenid()));
        xiaoquMapper.insertHuishou(huishou);
    }

    public List<Huishou> selectHuishouByOpenid(String openid){
        return xiaoquMapper.selectHuishouOrder(openid);
    }

    public Huishou selectHuishouById(String id){
        return xiaoquMapper.selectHuishouOrderById(id);
    }

    public List<Xiaoqu> getXiaoquByCity(String city){
        return xiaoquMapper.selectXiaoquByCity(city);
    }
}

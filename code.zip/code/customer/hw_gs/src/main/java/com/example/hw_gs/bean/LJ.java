package com.example.hw_gs.bean;

import lombok.Data;
import org.apache.solr.client.solrj.beans.Field;

@Data
public class LJ {
    private String name;
    private String type;
    private float confidence;
}
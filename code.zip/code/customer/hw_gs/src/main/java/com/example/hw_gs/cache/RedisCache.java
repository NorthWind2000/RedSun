package com.example.hw_gs.cache;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Set;

//自定义Redis缓存
@Component
public class RedisCache<k,v> implements Cache<k,v> {

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public v get(k k) throws CacheException {
        System.out.println("get key: "+k);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        return (v) redisTemplate.opsForValue().get(k.toString());
    }

    @Override
    public v put(k k, v v) throws CacheException {
        System.out.println("put key: "+k);
        System.out.println("put value: "+v);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.opsForValue().set(k.toString(),v);
        return null;
    }

    @Override
    public v remove(k k) throws CacheException {

        return null;
    }

    @Override
    public void clear() throws CacheException {

    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public Set<k> keys() {
        return null;
    }

    @Override
    public Collection<v> values() {
        return null;
    }
}

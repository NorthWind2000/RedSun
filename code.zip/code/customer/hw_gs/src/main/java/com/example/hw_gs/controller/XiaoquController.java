package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.Huishou;
import com.example.hw_gs.bean.Order;
import com.example.hw_gs.bean.OrderDetail;
import com.example.hw_gs.bean.Xiaoqu;
import com.example.hw_gs.server.OrderService;
import com.example.hw_gs.server.ShoppingcarService;
import com.example.hw_gs.server.XiaoquService;
import com.example.hw_gs.utils.ID;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@RestController
public class XiaoquController {

    @Autowired
    XiaoquService xiaoquService;

    @GetMapping("/hwgs/xiaoqu/{searchkey}")
    @CrossOrigin
    public JSONObject search(@PathVariable(name="searchkey") String searchkey){
        List<Xiaoqu> xiaoquList = xiaoquService.selectXiaoquByKeyWord(searchkey);
        return ResponseUtils.success(xiaoquList);
    }

    @GetMapping("/hwgs/xiaoqu/city/{city}")
    @CrossOrigin
    public JSONObject getXiaoquByCity(@PathVariable(name="city") String city){
        List<Xiaoqu> xiaoquList = xiaoquService.getXiaoquByCity(city);
        return ResponseUtils.success(xiaoquList);
    }

    @PostMapping("/hwgs/huishou")
    @CrossOrigin
    public void addhuishou(@RequestBody Huishou huishou){
        huishou.setId(ID.getId());
        xiaoquService.addHuishou(huishou);
    }

    @GetMapping("/hwgs/huishou")
    @CrossOrigin
    public JSONObject getHuishouOrderAll(){
        List<Huishou> huishouList = xiaoquService.selectHuishouByOpenid(UserInfoGetter.getOpenid());
        return ResponseUtils.success(huishouList);
    }

    @GetMapping("/hwgs/huishou/{id}")
    @CrossOrigin
    public JSONObject getHuishouOrderById(@PathVariable(name="id") String id){
        Huishou huishou = xiaoquService.selectHuishouById(id);
        return ResponseUtils.success(huishou);
    }
}

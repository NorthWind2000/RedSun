package com.example.hw_gs.filter;

import com.example.hw_gs.server.JwtService;
import com.example.hw_gs.utils.UserInfoGetter;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.shiro.web.filter.AccessControlFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/*
 * 自定义一个Filter，用来拦截所有的请求判断是否携带Token
 * isAccessAllowed()判断是否携带了有效的JwtToken
 * onAccessDenied()当没有携带JwtToken,或因时间超时等其他原因导致JwtToken无效的时候进行重新生成新的JwtToken，返回true允许访问，返回fasle拒绝访问
 * */

public class UserFilter extends AccessControlFilter {

    private Claims claims;

    /*
     * 1. 返回true，shiro就直接允许访问url
     * 2. 返回false，shiro才会根据onAccessDenied的方法的返回值决定是否允许访问url
     * */
    @Override
    protected boolean isAccessAllowed(ServletRequest servletRequest, ServletResponse servletResponse, Object mappedValue) {
        //这里先让它始终返回false来使用onAccessDenied()方法
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String jwt = request.getHeader("Authorization");
        UserInfoGetter.resetInfo();
        claims=null;
        if(jwt==null){
            return false;
        }
        else {
            JwtService jwtService=new JwtService("2575868186", SignatureAlgorithm.HS256);
            try{
                claims=jwtService.decode(jwt);
                UserInfoGetter.setInfo(claims.get("openid").toString(),jwt);
            }catch (ExpiredJwtException e){
                claims=e.getClaims();
                System.out.println("时间超时");
                return false;
            }
        }
        return true;
    }

    /**
     * 返回结果为true表明登录通过
     */
    @Override
    protected boolean onAccessDenied(ServletRequest servletRequest, ServletResponse servletResponse) throws Exception {
        //这个地方和前端约定，要求前端将jwtToken放在请求的Header部分
        System.out.println("重新生成JwtToken");
        //所以以后发起请求的时候就需要在Header中放一个Authorization，值就是对应的Token
        JwtService jwtService=new JwtService("2575868186",SignatureAlgorithm.HS256);
        String openid;
        try {
            openid=claims.get("openid").toString();
        }catch (Exception e){
            return false;
        }
        String newtoken = jwtService.encode(openid, 5*60*1000, claims);
        UserInfoGetter.setInfo(openid,newtoken);
        System.out.println("生成成功");
        return true;
        //执行方法中没有抛出异常就表示用户登录过
    }
}

package com.example.hw_gs.config;

import com.example.hw_gs.cache.RedisCacheManager;
import com.example.hw_gs.filter.UserFilter;
import com.example.hw_gs.realm.CustomerRealm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {
    //1、创建shiroFilter,负责拦截所有请求
    @Autowired
    CustomerRealm customerRealm;
    @Autowired
    RedisCacheManager redisCacheManager;

    @Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(){
        shezhiRealm();
        //创建shiro的filter
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        Map<String, Filter> filters=shiroFilterFactoryBean.getFilters();
        filters.put("userfilter",new UserFilter());
        //给filter设置安全管理器
        shiroFilterFactoryBean.setSecurityManager(getSecurityManager());
        Map<String,String> map=new LinkedHashMap<>();
        //配置系统公共资源
        map.put("/hwgs/dati","anon");
        map.put("/hwgs/xiaoqu/**","anon");
        map.put("/hwgs/login/**","anon");
        map.put("/hwgs/filesystem/upload","anon");
        map.put("/hwgs/rank","anon");
        map.put("/hwgs/lunboandxuanchuan/**","anon");
        map.put("/post","anon");
        map.put("/hwgs/zixun/**","anon");
//        map.put("/hwgs/shequ/**","anon");
        map.put("/hwgs/goods/**","anon");
//        map.put("/hwgs/huishou/sumbit/**","anon");
        //配置系统受限资源
        map.put("/**","userfilter");
//        map.put("/hwgs/shequ/dongtai","userfilter");

        shiroFilterFactoryBean.setFilterChainDefinitionMap(map);
        return shiroFilterFactoryBean;
    }
    //2、创建安全管理器
    @Bean
    public DefaultWebSecurityManager getSecurityManager(){
        DefaultWebSecurityManager defaultWebSecurityManager = new DefaultWebSecurityManager();
        defaultWebSecurityManager.setRealm(customerRealm);
        return defaultWebSecurityManager;
    }
    //3、设置自定义realm
    @Bean
    public void shezhiRealm(){
        //开启缓存管理器
        customerRealm.setCacheManager(redisCacheManager);
        customerRealm.setCachingEnabled(true);
        customerRealm.setAuthorizationCachingEnabled(true);
        customerRealm.setAuthorizationCachingEnabled(true);
    }
}
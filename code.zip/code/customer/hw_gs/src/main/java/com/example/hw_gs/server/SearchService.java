package com.example.hw_gs.server;

import com.example.hw_gs.bean.LJ;
import com.example.hw_gs.bean.SearchShangpin;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class SearchService {
    @Autowired
    SolrClient solrClient;

    public List<LJ> simpleSearch(String SearchKeys) throws IOException, SolrServerException {
        SolrQuery solrQuery=new SolrQuery("lj_name:"+SearchKeys);//语法和可视化操作一致;
        QueryResponse queryResponse=solrClient.query("demo_core",solrQuery);
        List<LJ> list=queryResponse.getBeans(LJ.class);
        return list;
    }
    public List<SearchShangpin> simpleSearch1(String SearchKeys) throws IOException, SolrServerException {
        SolrQuery solrQuery=new SolrQuery("sp_name:"+SearchKeys);//语法和可视化操作一致;
        QueryResponse queryResponse=solrClient.query("shangpin_core",solrQuery);
        List<SearchShangpin> list=queryResponse.getBeans(SearchShangpin.class);
        return list;
    }
}

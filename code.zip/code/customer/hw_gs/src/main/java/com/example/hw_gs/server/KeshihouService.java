package com.example.hw_gs.server;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.LJ;
import com.example.hw_gs.mapper.UserMapper;
import com.example.hw_gs.utils.DataUtil;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@Service
public class KeshihouService {
    @Autowired
    UserMapper userMapper;


    @Async
    public void updateToLYL(List<LJ> ljList){
        String xqid=  userMapper.getXqidByOpenid(UserInfoGetter.getOpenid());
        if(xqid.equals("youke") || ljList.size()==0){
            return;
        }
        String url="http://47.117.66.221:8009/update";
        RestTemplate client = new RestTemplate();
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        URI uri = builder.build().encode().toUri();
        JSONObject data=new JSONObject();
        data.put("xqindex",xqid);
        List<JSONObject> ljinfos=new ArrayList<>();
        for(int i=0;i<ljList.size();i++){
            JSONObject ljinfo=new JSONObject();
            LJ lj=ljList.get(i);
            ljinfo.put("name",lj.getName());
            ljinfo.put("type",lj.getType());
            ljinfos.add(ljinfo);
            if(i>=4){
                break;
            }
        }

        data.put("ljinfo",ljinfos);
        data.put("time", DataUtil.getHour());
        client.postForEntity(uri,data,String.class);
    }
}

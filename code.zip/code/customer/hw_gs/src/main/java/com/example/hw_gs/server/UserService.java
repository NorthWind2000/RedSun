package com.example.hw_gs.server;

import com.example.hw_gs.bean.LoginUser;
import com.example.hw_gs.mapper.UserMapper;
import com.example.hw_gs.utils.RedisUtil;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserMapper userMapper;
    @Autowired
    RedisUtil redisUtil;
    
    public LoginUser findUserByOpenid(String openid){
        return userMapper.getUserByOpenid(openid);
    }
    //注册
    public void register(String openid){
        userMapper.insertUser(openid);
    }

    public void updateUser(LoginUser user){
        String openid= UserInfoGetter.getOpenid();
        user.setOpenid(openid);
        userMapper.updateUser(user);
    }

    public int getJifenByOpenid(String openid){
        return userMapper.getJifenByOpenid(openid);
    }
}

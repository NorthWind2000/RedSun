package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class LoginUser {
    private String openid;
    private String realname;
    private String phone;
    private int jifen;
    private String province;
    private String city;
    private String county;
    private String xiaoqu;
    private String detailaddress;
    private int daticount;
    private String xqid;
}

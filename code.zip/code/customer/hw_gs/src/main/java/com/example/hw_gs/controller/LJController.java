package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.*;
import com.example.hw_gs.server.*;
import com.example.hw_gs.utils.ResponseUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LJController {

    @Autowired
    LJService ljService;

    @Autowired
    SearchService searchService;

    @Autowired
    RankService rankService;

    @Autowired
    KeshihouService keshihouService;

    @GetMapping("/hwgs/lajichaxun/{searchkeys}")
    public JSONObject search(@PathVariable(name="searchkeys") String searchkeys){
        List<LJ> ljList = ljService.selectLJByKeyWord(searchkeys);
        for(LJ lj : ljList) {
            rankService.addLJ("rank", lj, 0.9);
        }
        keshihouService.updateToLYL(ljList);
        return ResponseUtils.success(ljList);
    }
}

package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.Huishou;
import com.example.hw_gs.bean.Xiaoqu;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface XiaoquMapper {

    @Select("select * from xiaoqu where name like concat('%',#{keyword},'%')")
    public List<Xiaoqu> selectXiao(String keyword);

    @Insert("insert into huishou(id,time,type,dizhi,openid,phone,realname,xiaoquid) values(#{id},#{time},#{type},#{dizhi},#{openid},#{phone},#{realname},#{xiaoquid})")
    public void insertHuishou(Huishou huishou);

    @Select("select * from huishou where openid=#{openid}")
    public List<Huishou> selectHuishouOrder(String openid);

    @Select("select * from huishou where id=#{id}")
    public Huishou selectHuishouOrderById(String id);

    @Select("select * from xiaoqu where city like concat('%',#{keyword},'%')")
    public List<Xiaoqu> selectXiaoquByCity(String keyword);

    @Select("select xqid from user where openid=#{openid}")
    public String selectXiaoquidByOpenid(String openid);
}

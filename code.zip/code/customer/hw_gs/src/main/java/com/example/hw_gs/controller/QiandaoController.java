package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.server.QiandaoService;
import com.example.hw_gs.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class QiandaoController {

    @Autowired
    QiandaoService qiandaoService;

    @GetMapping("/hwgs/qiandao/{date}")
    public void qianDao(@PathVariable(name="date") int date) {
        qiandaoService.daKa(date);
    }

    @GetMapping("/hwgs/qiandao")
    public JSONObject getQianDaoData() {
        ArrayList<String> signdata = qiandaoService.getDaka();
        return ResponseUtils.success(signdata);
    }

//    @GetMapping("/hwgs/getdayscount")
//    public int getQianDaoData() {
//        int days = qiandaoService.getDaysCount();
//        return days;
//    }

}


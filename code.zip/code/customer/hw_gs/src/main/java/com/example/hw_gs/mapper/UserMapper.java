package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.LoginUser;
import org.apache.ibatis.annotations.*;

public interface UserMapper {

    @Insert("insert into user(openid) values(#{openid})")
    public void insertUser(String openid);

    @Select("select * from user where Openid=#{openid}")
    public LoginUser getUserByOpenid(String openid);

    @Update("update user set jifen=jifen+1 where Openid=#{openid}")
    public void qiandao(String openid);

    @Update("update user set realname=#{realname},phone=#{phone},province=#{province},city=#{city},county=#{county},detailaddress=#{detailaddress},xiaoqu=#{xiaoqu},xqid=#{xqid} where Openid=#{openid}")
    public void updateUser(LoginUser user);

    @Update("update user set jifen=jifen+#{jifen} where Openid=#{openid}")
    public void updateJifen(String openid,int jifen);

    @Select("select jifen from user where Openid=#{openid}")
    public int getJifenByOpenid(String openid);

    @Select("select xqid from user where Openid=#{openid}")
    public String getXqidByOpenid(String openid);
}

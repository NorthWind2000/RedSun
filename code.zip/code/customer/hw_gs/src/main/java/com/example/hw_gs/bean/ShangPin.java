package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class ShangPin {
    private String gid;
    private String gname;
    private String note;
    private String image;
    private int jifen;
    private int status;
}

package com.example.hw_gs.server;

import com.example.hw_gs.bean.ShangPin;
import com.example.hw_gs.mapper.ShangchengMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ShangchengService {

    @Autowired
    ShangchengMapper shangchengMapper;

    public int getGoodsAllcount(){
        return shangchengMapper.selectGoodsAllcount();
    }

    public List<ShangPin> getShangpinByPage(int page){
        int startindex=(page-1)*8;
        return shangchengMapper.selectGoodsByIndex(startindex);
    }

    public Map<String,List<String>> getLunboAndXuanchuan(String gid){
        Map<String,List<String>> res =new HashMap<>();
        res.put("lunbo",shangchengMapper.getLunbo(gid));
        res.put("xuanchuan",shangchengMapper.getXuanchuan(gid));
        return res;
    }
}

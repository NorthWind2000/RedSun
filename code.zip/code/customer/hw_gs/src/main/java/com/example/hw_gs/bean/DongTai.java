package com.example.hw_gs.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class DongTai {
    private String id;
    private String openid;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date pubtime;
    private String content;
    private String image;
    private String nickname;
    private String avatar;
    private int likenum;
    private int commentnum;
}

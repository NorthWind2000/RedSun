package com.example.hw_gs.controller;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.LJ;
import com.example.hw_gs.server.*;
import com.example.hw_gs.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ImageController {

    @Autowired
    ImageService imageService;
    @Autowired
    private LJService ljService;
    @Autowired
    private RankService rankService;
    @Autowired
    KeshihouService keshihouService;

    @PostMapping("/hwgs/shibie")
    public JSONObject shibieImage(@RequestParam(name = "file") MultipartFile file)throws IOException{

        List<LJ> allresults=new ArrayList<LJ>();
        JSONObject jsonObject =imageService.imageTaggingDemo(file.getBytes());
        file.getBytes();
        JSONObject result =(JSONObject) jsonObject.get("result");
        JSONArray jsonArray = (JSONArray)result.get("tags");
        for (Object j: jsonArray){
            JSONObject jj=(JSONObject)j;
            float confidence=Float.parseFloat(jj.get("confidence").toString());
            if(confidence>=80){
                List<LJ> results=ljService.selectLJByKeyWord(jj.get("tag").toString());
                for (LJ lj : results) {
                    rankService.addLJ("rank",lj,confidence/100);
                    lj.setConfidence(confidence);
                    allresults.add(lj);
                }
            }
        }
        if(allresults.size()==0){
            for (Object j: jsonArray){
                JSONObject jj=(JSONObject)j;
                float confidence=Float.parseFloat(jj.get("confidence").toString());
                if(confidence>=60){
                    List<LJ> results=ljService.selectLJByKeyWord(jj.get("tag").toString());
                    for (LJ lj : results) {
                        rankService.addLJ("rank",lj,confidence/100);
                        lj.setConfidence(confidence);
                        allresults.add(lj);
                    }
                }
            }
        }
        if(allresults.size()==0){
            for (Object j: jsonArray){
                JSONObject jj=(JSONObject)j;
                float confidence=Float.parseFloat(jj.get("confidence").toString());
                if(confidence>=40){
                    List<LJ> results=ljService.selectLJByKeyWord(jj.get("tag").toString());
                    for (LJ lj : results) {
                        rankService.addLJ("rank",lj,confidence/100);
                        lj.setConfidence(confidence);
                        allresults.add(lj);
                    }
                }
            }
        }
        if(allresults.size()==0){
            for (Object j: jsonArray){
                JSONObject jj=(JSONObject)j;
                float confidence=Float.parseFloat(jj.get("confidence").toString());
                if(confidence>=20){
                    List<LJ> results=ljService.selectLJByKeyWord(jj.get("tag").toString());
                    for (LJ lj : results) {
                        rankService.addLJ("rank",lj,confidence/100);
                        lj.setConfidence(confidence);
                        allresults.add(lj);
                    }
                }
            }
        }
        keshihouService.updateToLYL(allresults);
        return ResponseUtils.success(allresults);
    }

}

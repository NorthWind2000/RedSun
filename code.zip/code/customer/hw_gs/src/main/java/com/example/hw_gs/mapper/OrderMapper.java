package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.Order;
import com.example.hw_gs.bean.OrderDetail;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface OrderMapper {
    @Select("select * from orders where oid=#{oid}")
    public Order selectOrder(String oid);

    @Select("select * from orderdetail where oid=#{oid}")
    public OrderDetail[] selectOrderDetail(String oid);

    @Insert("insert into orders(oid,openid,realname,phone,address,credate,jifen,xiaoquid) values(#{oid},#{openid},#{realname},#{phone},#{address},#{credate},#{jifen},#{xiaoquid})")
    public void insertDingdan(Order order);

    @Select("select * from orders where openid=#{openid} and status=#{status}")
    public Order[] selectOrderByOpenid(String openid,int status);

    @Insert("insert into orderdetail(oid,gid,gname,image,jifen,count) values(#{oid},#{gid},#{gname},#{image},#{jifen},#{count})")
    public void insertDingdanDetail(OrderDetail orderDetail);

    @Update("update orders set status=3 where oid=#{oid}")
    public void shouhuo(String oid);
}
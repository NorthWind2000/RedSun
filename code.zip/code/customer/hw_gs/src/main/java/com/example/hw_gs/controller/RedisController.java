package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.Rank;
import com.example.hw_gs.server.RankService;
import com.example.hw_gs.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Set;

@RestController
public class RedisController {

    @Autowired
    RankService rankService;

    @GetMapping("/hwgs/rank")
    public JSONObject getRank(){
        Set rank=rankService.getRank("rank");
        ArrayList<JSONObject> rankdata=new ArrayList<>();
        for(Object r : rank) {
            rankdata.add(JSONObject.parseObject(JSONObject.toJSONString(r)));
        }
        return ResponseUtils.success(rankdata);
    }
}

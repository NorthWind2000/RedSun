package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class Rank {

    private String name;
    private double mark;

}

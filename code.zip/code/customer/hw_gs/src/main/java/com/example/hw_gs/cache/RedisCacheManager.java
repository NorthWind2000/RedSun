package com.example.hw_gs.cache;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//自定义的缓存管理器
//主要是为了整合shiro
@Component
public class RedisCacheManager implements CacheManager {
    @Autowired
    RedisCache redisCache;
    //参数s:认证或授权缓存的名称
    @Override
    public <K, V> Cache<K, V> getCache(String s) throws CacheException {
        return redisCache;
    }
}
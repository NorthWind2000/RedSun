package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.ShiTi;
import org.apache.ibatis.annotations.Select;

public interface DatiMapper {

    @Select("select * from zhishiwenda where id in (#{ids[0]},#{ids[1]},#{ids[2]},#{ids[3]},#{ids[4]},#{ids[5]},#{ids[6]},#{ids[7]},#{ids[8]},#{ids[9]})")
    public ShiTi[] getShiTi(int[] ids);
}

package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.Order;
import com.example.hw_gs.bean.OrderDetail;
import com.example.hw_gs.mapper.UserMapper;
import com.example.hw_gs.server.OrderService;
import com.example.hw_gs.server.ShoppingcarService;
import com.example.hw_gs.utils.ID;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;

@RestController
public class OrderController {
    @Autowired
    OrderService orderService;
    @Autowired
    ShoppingcarService shoppingcarService;
    @Autowired
    UserMapper userMapper;

    @PostMapping("/hwgs/dingdan/shoppingcar")
    @CrossOrigin
    public JSONObject addDingdanFromShoppingcar(@RequestBody Map<String, Object> request){
        Order order=new Order();
        String oid=ID.getId();
        order.setOid(oid);
        order.setCredate(new Date());
        order.setOpenid(UserInfoGetter.getOpenid());
        order.setXiaoquid(userMapper.getXqidByOpenid(UserInfoGetter.getOpenid()));
        order.setRealname(request.get("realname").toString());
        order.setAddress(request.get("address").toString());
        order.setPhone(request.get("phone").toString());
        order.setJifen(Integer.parseInt(request.get("jifen").toString()));

        OrderDetail[] orderDetails=JSONArray.parseObject(request.get("orderdetail").toString(),OrderDetail[].class);
        orderService.addOrder(order);

        for(OrderDetail o:orderDetails){
            shoppingcarService.deleteJilu(o.getGid());
            o.setOid(oid);
            orderService.addOrderDetail(o);
        }
        userMapper.updateJifen(order.getOpenid(),0-order.getJifen());
        return ResponseUtils.success(null);
    }

    @PostMapping("/hwgs/dingdan")
    @CrossOrigin
    public JSONObject addDingdan(@RequestBody Map<String, Object> request){
        Order order=new Order();
        String oid=ID.getId();
        order.setOid(oid);
        order.setCredate(new Date());
        order.setOpenid(UserInfoGetter.getOpenid());
        order.setRealname(request.get("realname").toString());
        order.setAddress(request.get("address").toString());
        order.setPhone(request.get("phone").toString());
        order.setJifen(Integer.parseInt(request.get("jifen").toString()));

        OrderDetail[] orderDetails=JSONArray.parseObject(request.get("orderdetail").toString(),OrderDetail[].class);
        orderService.addOrder(order);
        for(OrderDetail o:orderDetails){
            o.setOid(oid);
            orderService.addOrderDetail(o);
        }
        return ResponseUtils.success(null);
    }

    @GetMapping("/hwgs/dingdan/{status}")
    @CrossOrigin
    public JSONObject selectDingdan(@PathVariable(name="status") int status){
        return ResponseUtils.success(orderService.getOrderByOpenid(UserInfoGetter.getOpenid(),status));
    }

    @GetMapping("/hwgs/dingdandetail/{oid}")
    @CrossOrigin
    public JSONObject selectDingdanDetailByOid(@PathVariable(name="oid") String oid){
        return ResponseUtils.success(orderService.getOrderDetailByOid(oid));
    }
    @Update("/hwgs/shouhuo/{oid}")
    @CrossOrigin
    public void shouhuo(@PathVariable(name="oid") String oid){
        orderService.shouhuo(oid);
    }
}

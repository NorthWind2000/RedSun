package com.example.hw_gs.server;

import com.example.hw_gs.bean.Huishou;
import com.example.hw_gs.bean.LJ;
import com.example.hw_gs.bean.ZiXun;
import com.example.hw_gs.mapper.LJMapper;
import com.example.hw_gs.utils.ID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LJService {

    @Autowired
    LJMapper ljMapper;

    public List<LJ> selectLJByKeyWord(String keywords){
        return ljMapper.selectLJByKeyWord(keywords);
    }

    public void addHuishou(Huishou huishou){
        huishou.setId(ID.getId());
        ljMapper.insertHuishou(huishou);
    }
}

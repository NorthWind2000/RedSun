package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.ShouyeLunbo;
import com.example.hw_gs.bean.ZiXun;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ZixunMapper {

    @Select("select id,title,image,publishtime from zixun where status=1 limit #{startindex},#{count}")
    public List<ZiXun> selectZixunByIndex(int startindex, int count);

    @Select("select * from shouyelunbo")
    public List<ShouyeLunbo> selectLunBo();

    @Select("select * from zixun where id=#{zxid}")
    public ZiXun selectZixunById(String zxid);

    @Select("select count(*) from zixun")
    public int selectZixunAllcount();

    @Select("select content from zixun where id=#{zxid}")
    public String selectContentById(String zxid);

}

package com.example.hw_gs.bean;

import lombok.Data;

@Data
public class ShoppingCar {
    private String id;
    private String openid;
    private String gid;
    private String gname;
    private int count;
    private int jifen;
    private String image;
}
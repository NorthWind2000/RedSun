package com.example.hw_gs.mapper;

import com.example.hw_gs.bean.Huishou;
import com.example.hw_gs.bean.LJ;
import com.example.hw_gs.bean.ZiXun;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface LJMapper {

    @Select("select * from lajiinfo where name like concat('%',#{keyword},'%')")
    public List<LJ> selectLJ(String keyword);

    @Select("select * from lajiinfokeyword where name like concat('%',#{keyword},'%')")
    public List<LJ> selectLJByKeyWord(String keyword);

    @Insert("insert into huishouinfo(id,userid,contact,phone,detailaddress,time,leibie) values(#{id},#{userid},#{contact},#{phone},#{detailaddress},#{time},#{leibie})")
    public void insertHuishou(Huishou huishou);
}

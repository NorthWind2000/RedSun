package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.ShoppingCar;
import com.example.hw_gs.server.ShoppingcarService;
import com.example.hw_gs.utils.ID;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ShoppingcarController {
    @Autowired
    ShoppingcarService shoppingcarService;

    @PostMapping("/hwgs/gouwuche")
    @CrossOrigin
    public JSONObject addShoppingcar(@RequestBody ShoppingCar shoppingCar){
        shoppingCar.setOpenid(UserInfoGetter.getOpenid());
        shoppingCar.setId(ID.getId());
        shoppingcarService.addShoppingcar(shoppingCar);
        return ResponseUtils.success(shoppingCar.getId());
    }

    @GetMapping("/hwgs/gouwuche")
    @CrossOrigin
    public JSONObject addShoppingcar(){
        String openid=UserInfoGetter.getOpenid();
        return ResponseUtils.success(shoppingcarService.selectShoppingcar(openid));
    }

    @DeleteMapping("/hwgs/gouwuche/{id}")
    @CrossOrigin
    public JSONObject deleteOneFromShoppingcar(@PathVariable(name="id") String id){
        shoppingcarService.deleteJilu(id);
        return ResponseUtils.success(null);
    }
}

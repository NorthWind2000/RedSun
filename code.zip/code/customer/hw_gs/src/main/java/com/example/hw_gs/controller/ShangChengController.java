package com.example.hw_gs.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.hw_gs.bean.*;
import com.example.hw_gs.server.SearchService;
import com.example.hw_gs.server.ShangchengService;
import com.example.hw_gs.utils.ResponseUtils;
import com.example.hw_gs.utils.UserInfoGetter;
import org.apache.solr.client.solrj.SolrServerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;


@RestController
public class ShangChengController {

    @Autowired
    ShangchengService shangchengService;

    @GetMapping("/hwgs/goods/allcount")
    @CrossOrigin
    public JSONObject getShangpinAllcount(){
        return ResponseUtils.success(shangchengService.getGoodsAllcount());
    }

    @GetMapping("/hwgs/goods/{page}")
    @CrossOrigin
    public JSONObject getShangpinByPage(@PathVariable(name="page") int page){
        return ResponseUtils.success(shangchengService.getShangpinByPage(page));
    }

    @GetMapping("/hwgs/lunboandxuanchuan/{gid}")
    @CrossOrigin
    public JSONObject getLunboAndXuanchuan(@PathVariable(name="gid") String gid) {
        return ResponseUtils.success(shangchengService.getLunboAndXuanchuan(gid));
    }
}

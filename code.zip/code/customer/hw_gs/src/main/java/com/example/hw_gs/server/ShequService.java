package com.example.hw_gs.server;

import com.example.hw_gs.bean.DongTai;
import com.example.hw_gs.bean.PingLun;
import com.example.hw_gs.mapper.ShequMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class ShequService {
    @Autowired
    FileServier fileServier;
    @Autowired
    ShequMapper shequMapper;

    public int getDongtaiAllcount(){
        return shequMapper.selectDongtaiAllcount();
    }

    public void saveDongtai(DongTai dongTai){
        shequMapper.addDongtai(dongTai);
    }

    public void savePinglun(PingLun pingLun){
        shequMapper.addPingLun(pingLun);
    }

    public List<PingLun> getPinglunByFid(String fid){
        return shequMapper.selectPinglunByFid(fid);
    }

    public List<DongTai> getDongtai(int index){
        int startindex=(index-1)*3;
        return shequMapper.selectDongtaiByIndex(startindex,3);
    }

    public void dianzan(String id){
        shequMapper.dianzan(id);
    }

    public void pinglunplus(String id){
        shequMapper.pinglunplus(id);
    }

    public String saveImg(MultipartFile file) {
        // 判断文件数组是否为空
        if (file == null) {
            System.out.println("null");
            return null;
        } else {
//              String path = "C:\\Users\\ZCC\\Desktop";
            ArrayList<String> paths = new ArrayList<>();
            // 将图片文件保存到服务器，同时返回上传后图片的名字
            String name = file.getOriginalFilename();
            String extentionname = name.substring(name.lastIndexOf(".") + 1);
            String filename = UUID.randomUUID() + extentionname;
            try {
                return fileServier.testUpload(file.getBytes(),filename,extentionname);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }

}

package com.example.hw_gs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HwGsApplicationTests {

    @Test
    void contextLoads() {
    }

}

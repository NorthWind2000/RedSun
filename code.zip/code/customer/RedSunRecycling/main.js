import Vue from 'vue'
import App from './App'
import VueRouter from 'vue-router'
import router from './router/index.js'
import store from './store'
import myRequest from './http/index.js'
import ourLoading from '@/components/our-loading/our-loading.vue'
import { getDataSet, getComponentInfo } from './utils/util.js'
Vue.component('ourLoading', ourLoading)
Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App,
	store,
})
app.$mount()

Vue.prototype.myRequest = myRequest
Vue.prototype.store = store
Vue.prototype.$getDataSet = getDataSet
Vue.prototype.$getComponentInfo = getComponentInfo
// Vue.prototype.baseUrl = 'http://localhost:8083';
Vue.prototype.baseUrl = 'https://www.360zcc.top';

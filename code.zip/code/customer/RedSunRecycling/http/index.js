const baseUrl = 'http://localhost:8083'
// const baseUrl = 'http://192.168.1.102:8083'
// const baseUrl = 'https://www.360zcc.cn'

 const request = (options = {}) => {
	options['header']={}
	options.header['Authorization']=uni.getStorageSync('token')
	 
	return new Promise((resolve, reject) => {
		uni.request({
			url: baseUrl + options.url || '',
			method: options.method || 'GET',
			data: options.data || {},
			header: options.header
		}).then(data => {
			let [err, res] = data;     
			resolve(res);
		}).catch(error => {
			reject(error)
		})
	});
}

export default request
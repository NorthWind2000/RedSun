import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const constRouter = []

const router = new VueRouter({
  mode: 'hash',
  base: 'http://127.0.0.1:8080',
  routes: constRouter
})

export default router
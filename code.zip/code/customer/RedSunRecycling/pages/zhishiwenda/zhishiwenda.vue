<template>
	<view>
		<view>
			<view>
				<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="知识问答" color="white"></uni-nav-bar>
			</view>
		</view>

		<view>
			<exam-widght :dataList='QuestionList' @upshengyu="updateshengyu" @finish='finish'>
			</exam-widght>
		</view>
	</view>
</template>

<script>
	import examWidght from '@/components/Li-ExamWidght/Li-ExamWidght.vue';
	export default {
		data() {
			return {
				fenshu: 0,
				jifen: 0,
				QuestionList: [],
				shengyu: 0,
				isClicked:0
			}
		},
		beforeMount() {
			this.myRequest({
				method: "GET",
				url: "/hwgs/dati"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {

					for (var j = 0; j < res.data.length; j++) {
						res.data[j].myanswer = ''
						this.QuestionList.push(res.data[j])
					}
					this.shengyu = res.data.length
				}
			});
		},
		methods: {
			updateshengyu() {
				this.shengyu -= 1;
			},
			goback() {
				if (this.shengyu != 0) {
					uni.showModal({
						title: '您确定退出吗？',
						content: '您还未答完试题，现在退出将无法获取积分！',
						success: function(res) {
							if (res.confirm) {
								uni.navigateBack()
							}
						}
					});
				} else {
					uni.navigateBack()

				}
			},
			gobback() {
				uni.navigateBack()
			},
			finish(fenshu) {
				this.fenshu = fenshu
				this.jifen = fenshu / 10
				var message = "你的分数为:" + fenshu + ",本次获得" + this.jifen + "积分"
				uni.showModal({
					title: '提示',
					content: message
				});
				
				if(this.isClicked==0){
					this.isClicked=1
					this.myRequest({
						method: "PUT",
						url: "/hwgs/dati/"+this.jifen
					})
				}
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components: {
			examWidght
		}
	}
</script>

<style>

</style>

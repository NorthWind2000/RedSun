<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="排行榜" color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view class="leaderboard__profiles">
			  <view v-for="item in rankdata" class="leaderboard__profile">
			    <span class="leaderboard__name">{{item.name}}</span>
			    <span class="leaderboard__value">{{item.type}}</span>
			  </view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hheight:500,
				rankdata:[]
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 90
			
			this.myRequest({
				method: "GET",
				url: "/hwgs/rank"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.rankdata=res.data
				}
			});
			
		},
		methods: {
			goback(){
				uni.navigateBack()
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	@import url("/static/css/rankstyle.css")
</style>

<template>
	<view class="container">
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="分类口诀" color="white"></uni-nav-bar>
		</view>
		<view class="biaoqian">垃圾分类助记</view>
		<view class="zhuji">
			干湿要分开，能卖拿去卖，有害单独放。绿厨厨，黄其其，红危危，蓝宝宝。可回收，丢蓝色，有害垃圾丢红色，厨余垃圾是绿色，其他垃圾用灰色。
			垃圾多危害大，分类摆放人人夸。餐厨垃圾单独放，有害垃圾别乱抛。可回收、其他垃圾，大家把它分清楚，乱丢垃圾危害大，干干净净利大家。
			垃圾分类，循环回收。垃圾分类省力气，建设城市我当先。
		</view>
		<view class="biaoqian">趣味记忆图</view>
		<image src="../../static/image/quwei.jpg"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
			goback(){
				uni.navigateBack()
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	.biaoqian{
		width: 220rpx;
		height: 50rpx;
		margin-top: 30rpx;
		margin-left:50rpx;
		border-radius: 30rpx;
		background-color: #B8E986;
		text-align: center;
	}
	.zhuji{
		width: 650rpx;
		height: 400rpx;
		margin:10rpx auto;
		padding: 10rpx;
		background-color: #F9F9F9;
		border-radius: 30rpx;
		border: solid #B2B2B2 2rpx;
	}
	image{
		width: 700rpx;
		height: 450rpx;
		margin-left: 25rpx;
	}
</style>

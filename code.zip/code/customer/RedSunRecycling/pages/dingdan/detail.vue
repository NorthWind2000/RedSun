<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="订单详情"
				color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view class="dingdancard" v-for="item,index in dingdan">
				<image style="margin-left:30rpx; width: 200rpx;height: 200rpx;"
					:src="'http://www.360zcc.top/'+item.image"></image>
				<view style="margin-left: 10rpx;margin-top: 30rpx;">
					<view>
						<textarea disable="true"
							style="margin-left: 10rpx; height: 80rpx; width: 400rpx;font-size: 25rpx;">{{item.gname}}</textarea>
					</view>
					<view style="margin-top: 20rpx;padding-left: 20rpx;display: flex;">
						<view style=" width: 200rpx;color: #CC0000;">{{item.jifen}}积分</view>
						<view style="margin-left: 150rpx; width:100rpx;font-size: 30rpx;">x{{item.count}}</view>
					</view>
				</view>
			</view>
			<view>
				<view class="ui-all">
					<view class="ui-list">
						<text>收货人</text>
						<input type="text" disabled="true" v-model="dizhi.realname" />
					</view>
					<view class="ui-list">
						<text>手机号</text>
						<input type="text" disabled="true" v-model="dizhi.phone" />
					</view>
					<view class="ui-list">
						<text>商品积分</text>
						<input type="text" disabled="true" v-model="dizhi.jifen" />
					</view>
					<view class="ui-list">
						<text>收货地址</text>
						<input disabled="true" type="text"
							v-model="dizhi.address" />
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import numberbox from "../../components/lz-numinput/lz-numinput.vue"
	export default {
		data() {
			return {
				hheight: 500,
				dingdan: [],
				dizhi:{}
			};
		},
		created() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 80
			this.dizhi = this.$store.getters.getDingdan
			this.myRequest({
				method: "GET",
				url: "/hwgs/dingdandetail/" + this.dizhi.oid
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.dingdan = res.data
				}
			})
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	page {
		background-color: #FFFFFF;
	}
	.dingdancard{
		margin-top: 20rpx;
		background-color: #FFFFFF;
		display: flex;
		width: 710rpx;
		height: 250rpx;
		margin-left: 20rpx;
		border-radius:20rpx;
		box-shadow:0 5rpx 4rpx rgba(0, 0, 0, .3);
	}

	.ui-all {
		margin-top: 30rpx;
		background-color: #FFFFFF;
		padding: 20rpx 10rpx;
	
		.ui-list {
			width: 750rpx;
			padding: 20rpx 0;
			border-bottom: solid 2px #f2f2f2;
	
			text {
				color: #4a4a4a;
				font-size: 27rpx;
				display: inline-block;
				min-width: 150rpx;
				text-align: right;
			}
	
			input {
				color: #030303;
				font-size: 28rpx;
				display: inline-block;
				text-align: right;
				width: 550rpx;
			}
		}
	}
</style>

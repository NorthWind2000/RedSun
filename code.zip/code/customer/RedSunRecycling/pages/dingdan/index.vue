<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="我的订单"
				color="white"></uni-nav-bar>
		</view>
		<view style="background-color: #FFFFFF;">
			<segmentedcontrol :current="current" :values="items" @clickItem="onClickItem" styleType="button"
				activeColor="#4CA2FF"></segmentedcontrol>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view class="dingdancard" @click="godetail(item)" v-for="item,index in dingdandata">
				<view style="margin-left: 10rpx;margin-top: 30rpx;">
					<view>订单号：{{item.oid}}</view>
					<view> 地 址：{{item.address}}</view>
					<view style="margin-top: 40rpx;padding-left: 40rpx;display: flex;">
						<view style="font-size: 27rpx; width: 200rpx;color: #CC0000;">{{item.jifen}}积分</view>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import segmentedcontrol from "../../components/uni-segmented-control/uni-segmented-control.vue"
	export default {
		data() {
			return {
				dingdandata: [],
				status: 1,
				items: ['未领取', '已领取'],
				current: 0,
				hheight:500
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 120
			this.myRequest({
				method: "GET",
				url: "/hwgs/dingdan/" + this.status
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.dingdandata = res.data
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			onClickItem(index) {
				if (this.current !== index.currentIndex) {
					this.current = index.currentIndex;
				}
				this.status = this.current + 1
				this.myRequest({
					method: "GET",
					url: "/hwgs/dingdan/" + this.status
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.dingdandata = res.data
					}
				});
			},
			godetail(item){
				this.$store.commit("setDingdan",item);
				uni.navigateTo({
					url:"/pages/dingdan/detail"
				})
			}
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		components: {
			segmentedcontrol
		}
	}
</script>

<style>
	page {
		background-color: #FFFFFF;
	}
	.dingdancard{
		margin-top: 20rpx;
		background-color: #FFFFFF;
		display: flex;
		width: 710rpx;
		height: 220rpx;
		margin-left: 20rpx;
		border-radius:20rpx;
		box-shadow:0 5rpx 4rpx rgba(0, 0, 0, .3);
	}
</style>

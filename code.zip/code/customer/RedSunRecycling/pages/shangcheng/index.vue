<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" :background-color="zhuti" title="积分商城"
				color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'rpx;margin-top:15rpx;'}" scroll-y="true" scroll-left="120"
			@scrolltolower="gonextpage">
			<waterfallsFlow :list="goodlist" :idKey="'gid'" @wapper-lick="click">
				<view v-for="(item, index) of goodlist" :key="index" slot="slot{{index}}">
					<view style="padding: 10rpx;">
						<view class="name">{{item.gname}}</view>
						<view style="display: flex;align-items: center;margin-top: 10rpx;">
							<view class="jifen">{{item.jifen}}积分</view>
							<view class="addbutton" @click.stop="addgouwuche(item)">加入购物车</view>
						</view>
					</view>
				</view>
			</waterfallsFlow>
		</scroll-view>
	</view>
</template>

<script>
	import waterfallsFlow from "@/components/maramlee-waterfalls-flow/maramlee-waterfalls-flow.vue";
	export default {
		data() {
			return {
				hheight: 500,
				goodlist: [],
				curpage: 0,
				allcount: 0
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight + 510

			this.myRequest({
				method: "GET",
				url: "/hwgs/goods/allcount"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.allcount = res.data
					this.gonextpage()
				}
			});
		},
		methods: {
			gonextpage() {
				this.curpage += 1
				if (this.goodlist.length < this.allcount) {
					this.myRequest({
						method: "GET",
						url: "/hwgs/goods/" + this.curpage
					}).then((response) => {
						var res = response.data;
						if (res.code == "200") {
							for (var i = 0; i < res.data.length; i++) {
								this.goodlist.push(res.data[i])
							}
						}
					});
				}
			},
			click(item){
				this.$store.commit("setShangpin",item);
				uni.navigateTo({
					url:"/pages/shangcheng/xiangqing"
				})
			},
			addgouwuche(item){
				item.count=1
				uni.showToast({
					title: '加入购物车成功',
					duration: 2000
				});
				this.myRequest({
					method: "POST",
					url: "/hwgs/gouwuche",
					data:item
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						item.id=res.data
						this.$store.commit("addGowuche",item);
					}
				});
			}
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		components: {
			waterfallsFlow
		}
	}
</script>

<style>
	page {
		background-color: #D3D3D3;
	}

	.addbutton {
		background-color: red;
		color: white;
		border-radius: 50rpx;
		padding: 2rpx 14rpx;
		z-index: 99;
	}

	.jifen {
		color: #8DC63F;
		font-size: 30rpx;
	}

	.name {
		font-size: 25rpx;
		color: #333333;
		line-height: 50rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 3;
	}
</style>

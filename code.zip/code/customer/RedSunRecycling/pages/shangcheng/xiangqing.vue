<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="商品详情"
				color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px;margin-top:15rpx;'}" scroll-y="true" scroll-left="120">
			<view>
				<swiper class="swiper-box">
					<swiper-item v-for="(item ,index) in lunbo" :key="index">
						<view class="swiper-item">
							<image class="image" mode="widthFix" :src="'http://www.360zcc.top/'+item"></image>
						</view>
					</swiper-item>
				</swiper>
			</view>
			<unisection title="商品介绍" type="line"></unisection>
			<view style="margin: 20rpx;font-size: 30rpx;">{{goodsdata.gname}}</view>
			<view style="margin: 20rpx;font-size: 30rpx;">{{"现价："+goodsdata.jifen+"积分"}}</view>
			<unisection title="商品详情" type="line"></unisection>
			<view style="margin: 20rpx;font-size: 30rpx;">{{goodsdata.note}}</view>
			<unisection title="商品详情图" type="line"></unisection>
			<view>
				<image v-for="item in xuanchuan" mode="widthFix" style=" margin-left:15rpx; width:720rpx;" :src="'https://www.360zcc.top/'+item"></image>	
			</view>
			<view>
				<uniGoodsNav class="isbutto" :fill="true" :options="options" :buttonGroup="buttonGroup" @click="gogouwuche"
					@buttonClick="buttonClick" />
			</view>
		</scroll-view>
	</view>
</template>

<script>
	//引入
	import uniGoodsNav from '../../components/uni-goods-nav/uni-goods-nav.vue'
	import unisection from '../../components/goo-section/goo-section.vue'
	import {
		uniList,
		uniListItem,
		uniListChat
	} from '@dcloudio/uni-ui'
	export default {
		data() {
			return {
				lunbo:[],
				xuanchuan:[],
				goodsdata: {},
				hheight: 500,
				quan: 1, //初始数量
				quan1: 0, //最终数量
				options: [{
					icon: 'cart',
					text: '购物车',
				}],
				buttonGroup: [{
						text: '加入购物车',
						backgroundColor: '#ff0000',
						color: '#fff'
					},
					{
						text: '立即购买',
						backgroundColor: '#ffa200',
						color: '#fff'
					}
				],
			}
		},
		components: {
			uniGoodsNav,
			unisection
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 100
			this.goodsdata = this.$store.getters.getShangpin
			console.log(this.goodsdata)
			this.myRequest({
				method: "GET",
				url: "/hwgs/lunboandxuanchuan/"+this.goodsdata.gid
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.lunbo = res.data.lunbo
					this.xuanchuan = res.data.xuanchuan
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			gogouwuche(){
				uni.navigateTo({
					url:"/pages/gouwuche/index"
				})
			},
			//右侧
			buttonClick(e) {
				switch (e.index) {
					case 0:
						this.addgouwuche();
						break
					case 1:
						this.orno();
						break
				}
			},
			//确认下单
			orno() {
				var thit = this
				uni.showModal({
					title: '提示',
					content: '确认下单',
					success: function(res) {
						if (res.confirm) {
							thit.goodsdata.count=1
							thit.$store.commit("setJiesuan",thit.goodsdata)
							thit.$store.commit("setOncebuy",1);
							uni.navigateTo({
								url:"/pages/jiesuan/index"
							})
						}
					}
				});
			},
			addgouwuche(){
				this.goodsdata.count=1
				uni.showToast({
					title: '加入购物车成功',
					duration: 2000
				});
				this.myRequest({
					method: "POST",
					url: "/hwgs/gouwuche",
					data:this.goodsdata
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.goodsdata.id=res.data
						this.$store.commit("addGowuche",this.goodsdata);
					}
				});
			},
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	.swiper-box {
		// min-height: 500rpx;
		height: 750rpx;
	}
	
	.swiper-item {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		background-color: $uni-text-color-grey;
		color: #fff;
	}
	
	.image {
		width: 750rpx;
	}
</style>

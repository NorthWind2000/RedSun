<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="关于我们" color="white"></uni-nav-bar>
		</view>
		<view>
			<image style="margin-top: 200rpx; margin-left: 300rpx; height: 150rpx;width: 150rpx;" src="../../static/logo.png"></image>
			<view style="font-size: 35rpx; margin-top:20rpx;margin-left: 280rpx;">红 太 阳 团 队</view>
			<view style="font-size: 35rpx; margin-left: 160rpx;">来 自 X X 大 学 软 件 学 院</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
			goback(){
				uni.navigateBack()
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
</style>
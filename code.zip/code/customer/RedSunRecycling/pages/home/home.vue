<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" :background-color="zhuti" title="红太阳回收" color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
		<view class="cu-bar bg-white margin-top" id="greet_view">
			<view class='action'>
				<text class='text-bold text-title text-xxl'>{{greeting}}</text>
			</view>
		</view>
		<view>
			<swiper class="screen-swiper" :class="dotStyle?'square-dot':'round-dot'" :indicator-dots="true" :circular="true"
			 :autoplay="true" interval="5000" duration="500">
				<swiper-item v-for="(item,index) in bannerArr" @click="dianji(index)" :key="index">
					<image :src="'http://124.70.69.175/'+item.image" mode="aspectFill"></image>
				</swiper-item>
			</swiper>
		</view>
		<view class="searchbox">
			<searchbutton></searchbutton>
		</view>

		<view class="title-header">
			<view class="title-text">
				社 / 区 / 服 / 务
			</view>
		</view>

		<view class='nav-list margin-top'>
			<navigator open-type="navigate" hover-class='none' :url="item.url"
				:class="'nav-li bg-kuxuan' + (index+1)" v-for="(item, index) in shequserver" :key="index">
				<view class="nav-name">{{item.name}}</view>
			</navigator>
		</view>
		
		<view class="title-header">
			<view class="title-text">
				实 / 用 / 小 / 工 / 具
			</view>
		</view>
		
		<view class="nav-list">
			<navigator hover-class="none" :url="item.url" class="nav-li" navigateTo :class="'bg-'+item.color"
			 :style="[{animation: 'show ' + ((index+1)*0.2+1) + 's 1'}]" v-for="(item,index) in xiaogongju" :key="index">
				<view class="nav-title">{{item.title}}</view>
				<view class="nav-name">{{item.name}}</view>
				<text :class="'cuIcon-' + item.cuIcon"></text>
			</navigator>
		</view>
		<view class="cu-tabbar-height"></view>
		</scroll-view>
	</view>
</template>

<script>
	import searchbutton from "../../my-components/search-button/searchbutton.vue"
	const util = require('@/utils/util')
	export default {
		data() {
			return {
				hheight: 500,
				greeting: "",
				bannerArr: [], //banner图片信息
				shequserver: [{
				    name: '社区动态',
					url: '/pages/shequ/index/index'
				  },
				  {
				    name: '呼叫上门',
				    url: '/pages/huishou/index'
				  }
				],
				xiaogongju: [
					{
						title: '智能识别',
						name: 'Distinguish',
						color: 'mauve',
						cuIcon: 'cuIcon',
						url:"/pages/shibie/shibie"
					},
					{
						title: '知识问答',
						name: 'Knowledge',
						color: 'cyan',
						cuIcon: 'newsfill',
						url:"/pages/zhishiwenda/zhishiwenda"
					},
					{
						title: '分类排行',
						name: 'Ranking',
						color: 'blue',
						cuIcon: 'colorlens',
						url:'/pages/rank/rank'
					},
					{
						title: '分类口诀',
						name: 'Skill',
						color: 'purple',
						cuIcon: 'font',
						url: '/pages/fenleikoujue/fenleikoujue'
					}
				],
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 120
		},
		created() {
			// 获取对应的问候语
			this.greeting = util.timeGreeting(new Date())
			this.myRequest({
				method: "GET",
				url: "/hwgs/zixun/first"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.bannerArr = res.data
				}
			});
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		methods: {
			gosearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			dianji(index) {
				this.myRequest({
					method: "GET",
					url: "/hwgs/zixun/" + this.bannerArr[index].zxid
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.$store.commit("setZixun", res.data);
						uni.navigateTo({
							url: "/pages/zixundetail/index/index"
						})
					}
				});
			}
		},
		components: {
			searchbutton,
		}
	}
</script>

<style>
	page {
		background-color: #FFFFFF;
	}

	.searchbox {
		margin: 20rpx auto;
		width: 80%;
	}
	
	.title-header {
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    height: 120rpx;
	    font-size: 40rpx;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    align-items: center;
	    -webkit-box-pack: center;
	    -webkit-justify-content: center;
	    justify-content: center;
	    font-weight: bold;
	    /* background-image: url(https://s1.ax1x.com/2020/09/16/wccswF.png);
	    background-size: cover; */
	}
	.title-text {
	    background-image: -webkit-linear-gradient(0deg, #ff8a34, #FBBD12);
	    -webkit-background-clip: text;
	    -webkit-text-fill-color: transparent;
	}
	.nav-list {
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    -webkit-flex-wrap: wrap;
	    flex-wrap: wrap;
	    padding: 0px 20px 0px;
	    -webkit-box-pack: justify;
	    -webkit-justify-content: space-between;
	    justify-content: space-between;
	}
	.margin-top {
	    margin-top: 15px;
	}
	.nav-li {
	    padding: 15px;
	    border-radius: 6px;
	    width: 45%;
	    margin: 0 2.5% 20px;
	    background-image: url(https://s1.ax1x.com/2020/06/27/NyU04x.png);
	    background-size: cover;
	    background-position: center;
	    position: relative;
	    z-index: 1;
	}
	
	.nav-name {
	    font-size: 16px;
	    font-weight: 300;
	}
	
	[class*="cuIcon-"] {
	    font-family: "cuIcon";
	    font-size: inherit;
	    font-style: normal;
	}
	
	.nav-li uni-text {
	    position: absolute;
	    right: 15px;
	    top: 15px;
	    font-size: 26px;
	    width: 30px;
	    height: 30px;
	    text-align: center;
	    line-height: 30px;
	}
	
	.nav-li text {
	  right: 0rpx;
	  font-size: 100rpx;
	  width: 108rpx;
	  height: 108rpx;
	  opacity: 0.1;
	}
	
	.bg-kuxuan1 {
	    background-color: #FF5656;
	    color: #fff;
	}
	.bg-kuxuan2 {
	    background-color: #6F68DF;
	    color: #fff;
	}
	.bg-index1 {
	    background-color: #FF5656;
	    color: #fff;
	}
	.bg-index2 {
	    background-color: #6F68DF;
	    color: #fff;
	}
	.bg-index3 {
	    background-color: #19D08B;
	    color: #fff;
	}
	.bg-index4 {
	    background-color: #8dc63f;
	    color: #fff;
	}
</style>

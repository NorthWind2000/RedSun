<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="垃圾分类小助手" color="white"></uni-nav-bar>
		</view>
		
		<view class="searchbox">
			<search @search="search" @getResult="searchResult"></search>
		</view>
		<view v-show="active" class="parent">
			<ourLoading :active="active" text="搜索中..." />
		</view>
		<view class="resultarea">
			<image v-if="isshow" src="../../static/image/kongkong.png"></image>
			<scroll-view v-else :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
				<view>
					<view style="margin-top: 10rpx; font-size: 30rpx; margin-left: 50rpx;width: 650rpx;height:70rpx;border-bottom:solid 2px #f2f2f2; display: flex;" v-for="item in result">
						<label style="width: 200rpx; margin-left: 50rpx">{{item.name}}</label>
						<lable style="margin-left: 200rpx;">{{item.type}}</lable>
					</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import search from "../../my-components/search-com/searchbar.vue"
	export default {
		data() {
			return {
				hheight:500,
				isshow:true,
				result:[],
				active:false
			};
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 130
		},
		methods: {
			goback(){
				uni.navigateBack({
					url:"pages/index/index"
				})
			},
			search(){
				this.result=[]
				this.active=true
				this.isshow=false
			},
			searchResult(data){
				this.result=data
				if(this.result.length!=0){
					this.isshow=false
				}else{
					this.isshow=true
				}
				this.active=false
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components: {
			search
		}
	}
</script>

<style lang="scss">
	.searchbox{
		margin: 20rpx auto;
		width: 80%;
	}
	.resultarea{
		text-align: center;
		image{
			margin-top: 60rpx;
			width: 220rpx;
			height: 250rpx;
		}
	}
	.parent {
	    width: 100rpx;
	    height: 100rpx;
		margin-left: 325rpx;
		margin-top: 300rpx;
	    position: relative;  /* 注意需要为加载器定义一个相对定位的父容器 */
	    .img {
	        max-width: 30rpx;
	        height: 100rpx;
	    }
	}
</style>

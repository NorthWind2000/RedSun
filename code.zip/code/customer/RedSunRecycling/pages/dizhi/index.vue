<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="完善地址" color="white"></uni-nav-bar>
		</view>
		<view class="one">
			<input v-model="searchkey" placeholder="请输入小区名称"  @confirm="searching" confirm-type="search"></input>
			<view @click="searching">
				<image src="../../static/image/sousuo.png"></image>
			</view>
		</view>
		<view v-if="isShow" class="resultarea">
			<image v-if="!isSearchResultShow" src="../../static/image/kongkong.png"></image>
			<scroll-view v-else :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
				<view>
					<view @click="xuanzhong(item)" style="margin-top: 15rpx; margin-left: 50rpx;width: 650rpx;height:90rpx;border-bottom:solid 2px #ABABAB;" v-for="item in searchResult">
						<view style="font-size: 35rpx;">{{item.name}}</view>
						<label style="color: #969799; font-size: 25rpx;">{{item.province}} {{item.city}} {{item.county}} {{item.detailaddress}}</label>
					</view>
				</view>
			</scroll-view>
		</view>
		<view v-else class="ui-all">
			<view class="ui-list">
				<text>姓名</text>
				<input type="text" placeholder="请输入姓名" v-model="dizhi.realname" placeholder-class="place" />
			</view>
			<view class="ui-list">
				<text>手机号</text>
				<input type="tel" placeholder="请输入手机号码" v-model="dizhi.phone" placeholder-class="place" />
			</view>
			<view class="ui-list">
				<text>地址</text>
				<picker disabled="true">
					<view class="picker">
						{{dizhi.province}} {{dizhi.city}} {{dizhi.county}}
					</view>
				</picker>
			</view>
			<view class="ui-list">
				<text>详细地址</text>
				<input disabled="true" type="text" style="width: 500rpx;" placeholder="请输入详细地址" v-model="dizhi.detailaddress" placeholder-class="place" />
			</view>
			<view class="ui-list">
				<text>小区名称</text>
				<input disabled="true" type="text" style="width: 500rpx;" placeholder="请输入小区名称" v-model="dizhi.xiaoqu" placeholder-class="place" />
			</view>
			<button class="save" @tap="savaInfo">保 存 修 改</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dizhi:{},
				isShow:false,
				isSearchResultShow:false,
				searchResult:[],
				hheight:500,
				searchkey:""
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 130
			this.dizhi=this.$store.getters.getAddressinfo
		},
		methods: {
			xuanzhong(item){
				this.isShow=false
				this.isSearchResultShow=item.realname				this.dizhi.xiaoqu=item.name
				this.dizhi.province=item.province
				this.dizhi.city=item.city
				this.dizhi.county=item.county
				this.dizhi.detailaddress=item.detailaddress
				this.dizhi.xqid=item.id
				this.searchkey=""
			},
			searching() {
				if (this.searchkey != "") {
					this.isShow=true
					this.myRequest({
						method: "GET",
						url: "/hwgs/xiaoqu/" + this.searchkey
					}).then((response) => {
						var res = response.data;
						if (res.code == "200") {
							this.searchResult=res.data
							if(this.searchResult.length!=0){
								this.isSearchResultShow=true
							}
						}
					});
				}
			},
			goback(){
				uni.navigateBack()
			},
			bindRegionChange(e) {
				this.region = e.detail.value;
			},
			savaInfo() {
				let that = this;
				let realname = that.dizhi.realname;
				let phone = that.dizhi.phone;
				let province=that.dizhi.province
				let city=that.dizhi.city
				let county=that.dizhi.county
				let xqid=that.dizhi.id
				if(realname==""){
					uni.showToast({
						title: '请填写真实姓名',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				if (!that.isPoneAvailable(phone)) {
					uni.showToast({
						title: '手机号码有误，请重填',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				if (province==""||city==""||county=="") {
					uni.showToast({
						title: '请选择常住地',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				this.myRequest({
					method: "POST",
					url: "/hwgs/user/update",
					data:this.dizhi
				})
				uni.showToast({
					title: '提交成功',
					icon: 'none',
					duration: 2000
				});
				this.$store.commit("setAddressinfo",this.dizhi);
			},
			isPoneAvailable(poneInput) {
				var myreg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
				if (!myreg.test(poneInput)) {
					return false;
				} else {
					return true;
				}
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="less">
	.container {
		display: block;
	}
	
	.one {
		border-radius: 30rpx;
		background-color: #F0F0F0;
		display: flex;
		flex-direction: row;
		width: 650rpx;
		margin-left: 50rpx;
		margin-top: 20rpx;
		height: 80rpx;
	
		view {
			padding-top: 20rpx;
			padding-left: 15rpx;
			width: 60rpx;
			height: 60rpx;
		}
	
		input {
			margin-left: 30rpx;
			line-height: 80rpx;
			font-size: 30rpx;
			width: 85%;
			height: 80rpx;
			text-align: left;
		}
	
		image {
			width: 30rpx;
			height: 30rpx;
		}
	}
	
	.searchbox{
		margin: 20rpx auto;
		width: 80%;
	}
	.resultarea{
		text-align: center;
		image{
			margin-top: 60rpx;
			width: 220rpx;
			height: 250rpx;
		}
	}

	.ui-all {
		padding: 20rpx 40rpx;

		.ui-list {
			width: 100%;
			text-align: left;
			padding: 20rpx 0;
			border-bottom: solid 1px #f2f2f2;
			position: relative;

			text {
				color: #4a4a4a;
				font-size: 28rpx;
				display: inline-block;
				vertical-align: middle;
				min-width: 150rpx;
			}

			input {
				color: #030303;
				font-size: 30rpx;
				display: inline-block;
				vertical-align: middle;
			}
			button{
				color: #030303;
				font-size: 30rpx;
				display: inline-block;
				vertical-align: middle;
				background: none;
				margin: 0;
				padding: 0;
				&::after{
					display: none;
				}
			}
			picker {
				width: 90%;
				color: #030303;
				font-size: 30rpx;
				display: inline-block;
				vertical-align: middle;
				position: absolute;
				top: 30rpx;
				left: 150rpx;
			}

			textarea {
				color: #030303;
				font-size: 30rpx;
				vertical-align: middle;
				height: 150rpx;
				width: 100%;
				margin-top: 50rpx;
			}

			.place {
				color: #999999;
				font-size: 28rpx;
			}
		}

		.right:after {
			content: ' ';
			width: 20rpx;
			height: 20rpx;
			border-top: solid 1px #030303;
			border-right: solid 1px #030303;
			transform: rotate(45deg);
			-ms-transform: rotate(45deg);
			/* IE 9 */
			-moz-transform: rotate(45deg);
			/* Firefox */
			-webkit-transform: rotate(45deg);
			/* Safari 和 Chrome */
			-o-transform: rotate(45deg);
			position: absolute;
			top: 40rpx;
			right: 0;
		}

		.save {
			background: #030303;
			border: none;
			color: #ffffff;
			margin-top: 40rpx;
			font-size: 28rpx;
		}
	}
</style>

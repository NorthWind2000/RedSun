<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="我的预约" color="white"></uni-nav-bar>
		</view>
		<wyb-popup ref="popup" type="center" height="150" width="660" radius="6">
		    <view style="text-align: center; padding: 20rpx;">
		        <uniSteps :options="option" :active="active"></uniSteps>
		    </view>
		</wyb-popup>
		<scroll-view :style="{height:hheight+'rpx'}" scroll-y="true" scroll-left="120">
			<view @click="jindu(index)" class="yuyuecard" v-for="item,index in yuyuedata">
				<view style="width: 660rpx;">预约时间:{{item.time}}</view>
				<view style="width: 660rpx;">客户名称:{{item.realname}}</view>
				<view style="width: 660rpx;">物品类别:{{item.type}}</view>
				<view style="width: 660rpx;">联系方式:{{item.phone}}</view>
				<textarea disabled="true" style="height: 80rpx; width: 660rpx;">
					服务地址：{{item.dizhi}}
				</textarea>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import uniSteps from '@/components/uni-steps/uni-steps.vue';
	import wybPopup from '@/components/wyb-popup/wyb-popup.vue';
	export default {
		data() {
			return {
				hheight:500,
				yuyuedata:[],
				active:0,
				option:[{title: '待接单'}, {title: '已接单'}, {title: '上门回收进行中'}, {title: '回收完毕'},{title: '订单完成'}]
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight + 600
			
			this.myRequest({
				method: "GET",
				url: "/hwgs/huishou"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.yuyuedata=res.data
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			jindu(index){
				this.active=this.yuyuedata[index].status-1
				this.$refs.popup.show() // 显示
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components:{
			uniSteps,
			wybPopup
		}
	}
</script>

<style>
	page{
		background-color: #F3F3F3;
	}
	.yuyuecard{
		padding: 20rpx;
		margin-top: 10rpx;
		margin-left: 25rpx;
		border-radius: 30rpx;
		background-color: #FFFFFF;
		width: 700rpx;
		height: 250rpx;
		box-shadow:0 5rpx 4rpx rgba(0, 0, 0, .3);
	}
</style>

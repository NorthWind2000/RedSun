<template>
	<view :style="isshow?'':'background-color:#ffffff'">
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="购物车"
				color="white"></uni-nav-bar>
		</view>
		<view v-if="isshow" style="text-align: center;">
			<image style="margin-top: 100rpx; width: 220rpx;height: 250rpx;" v-if="isshow"
				src="../../static/image/kongkong.png"></image>
		</view>
		<view v-else>
			<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
				<uni-swipe-action>
				<uni-swipe-action-item v-for="item,index in gouwuchedata" :right-options="options" @click="onClick(index)">
					<view class="gcard">
						<image style="margin-left:30rpx; width: 200rpx;height: 200rpx;"
							:src="'http://www.360zcc.top/'+item.image"></image>
						<view style="margin-left: 10rpx;margin-top: 30rpx;">
							<view>
								<textarea disable="true"
									style="margin-left: 10rpx; height: 80rpx; width: 400rpx;font-size: 25rpx;">{{item.gname}}</textarea>
							</view>
							<view style="margin-top: 20rpx;padding-left: 20rpx;display: flex;">
								<view style="width: 200rpx; color: #CC0000;">{{item.jifen}}积分</view>
								<view style="margin-left: 100rpx; width:100rpx;font-size: 30rpx;">
									<numberbox :useId="index" @change="numchange" :value="1" btnTheme="2" skin="2" :step="1"
										:min="1">
									</numberbox>
								</view>
							</view>
						</view>

					</view>
				</uni-swipe-action-item>
				</uni-swipe-action>


			</scroll-view>
			<view class="zhifu">
				<view style="font-size: 26rpx; width: 100rpx; height: 80rpx; line-height: 80rpx; margin-left: 200rpx;">
					合计：
				</view>
				<view style="width: 250rpx;height: 80rpx; line-height: 80rpx;font-size:40rpx;color: #A32E03;">
					{{jifen}}积分
				</view>
				<button @click="tijiao" type="warn"
					style="color: #FFFFFF; line-height: 80rpx;margin-right: 20rpx; background-color: #FF5053; border-radius: 50rpx;width: 300rpx;height: 80rpx;">去结算</button>
			</view>
		</view>
	</view>
</template>

<script>
	import numberbox from "../../components/lz-numinput/lz-numinput.vue"
	export default {
		data() {
			return {
				hheight: 500,
				gouwuchedata: [],
				dizhi: {},
				url: "",
				jifen: 0,
				isshow: true,
				options: [{
					text: '删除',
					style: {
						backgroundColor: '#dd524d'
					}
				}]

			};
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 140
			this.gouwuchedata = this.$store.getters.getGouwuche
			if (this.gouwuchedata.length == 0) {
				this.isshow = true
			} else {
				this.isshow = false
				this.updateJifen()
			}
		},
		onShow(){
			this.gouwuchedata = this.$store.getters.getGouwuche
			if (this.gouwuchedata.length == 0) {
				this.isshow = true
			} else {
				this.isshow = false
				this.updateJifen()
			}
		},
		methods: {
			onClick(e) {
				this.myRequest({
					method: "DELETE",
					url: "/hwgs/gouwuche/"+this.gouwuchedata[e].id
				})
				this.gouwuchedata.splice(e,0)
				this.$store.commit("removeGouwuche",e)
				this.updateJifen()
				if(this.gouwuchedata.length==0){
					this.isshow=true
				}
			},
			goback() {
				uni.navigateBack()
			},
			numchange(e) {
				this.gouwuchedata[e.useId]["count"] = e.value
				this.updateJifen()
			},
			updateJifen(){
				var sum = 0;
				for (var i = 0; i < this.gouwuchedata.length; i++) {
					sum += this.gouwuchedata[i].count * this.gouwuchedata[i].jifen
				}
				this.jifen = sum;
			},
			tijiao() {
				this.$store.commit("setGouwuche", this.gouwuchedata)
				this.$store.commit("setOncebuy", 0);
				uni.navigateTo({
					url: "/pages/jiesuan/index"
				})
			}
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		components: {
			numberbox
		}
	}
</script>

<style lang="scss">
	@font-face {
	  font-family: 'lz-iconfont';
	  src: url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAucAAsAAAAAEVwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFY8dklkY21hcAAAAYAAAADOAAAClLo3y+FnbHlmAAACUAAABt4AAAlQQ5/AX2hlYWQAAAkwAAAALwAAADYTrL6kaGhlYQAACWAAAAAcAAAAJAfeA5FobXR4AAAJfAAAAA8AAABAQAAAAGxvY2EAAAmMAAAAIgAAACIS1A+ybWF4cAAACbAAAAAfAAAAIAElAI1uYW1lAAAJ0AAAAUwAAAKRYYJBunBvc3QAAAscAAAAgAAAAKxZzvGWeJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2BkYWCcwMDKwMHUyXSGgYGhH0IzvmYwYuRgYGBiYGVmwAoC0lxTGByeMTwvYm7438AQw9zA0AAUZgTJAQDlrwxWeJzlkk0KwkAMRl+11lrrzwFEhC5KUTxX3fZArj2IK1eeIgE9hGYmUnShFzDDG5h8TGbIF2AEDI2dkUJyJSHExbJJzA8pYj7laOcVS8uUguRSy1ZaOcldK6210b0etHs84EO99Wrr6tdIrPr7WvdrE9WCGXMWTJhSMrB/pPb/jDG5ydmPyv8SZdzPr9MiOOEELyV3gp9SO9ZRZOtYb5HWiXdPjvUbuTnWeeTuhNe0cswNtHbCPGnjhJnSvRNmTVvHXEMPjvmHdg75EyLuT10AAHicXVZ9bBxHFZ83c7ezt7u3d3u3u3fnvW/bt2kMd/h8txvS4CTILY5IcBoTW42xaRtLCZKdSgEFZLW4UfMHCGgdQYItJFS1QVETbEVIiAoVlNJKIQbRkqoiEhWKkJDzHxKqVIG4DW/2fFaorXs3M++933tv3scciRLy4N/sFaYRIA7xyJPkLCGDw6zWX5UsO1MEU+I6WEUYafqj4NeB1aEBIdfsciVehExzP4wCqyVASA8BahimnRlp2hm7BDbqen7ba7MaMwtQc+vA+6u1ttHyHgXbQ55hsq+d57KaAH38+PFxHgNdlfmXTwKcbMPeYSnK1IRW+3Td1QA50Ui0ue++kSzm3YMt+rqaSKi/YY29/TknpkncAPxrWtkj+9SL8ZiknFcOTJac79ORqK4m5d0rv1jZzeKyqkeHr546dTX41+eeyTOaUBOy9cW5wzZPqDpQmj8Jb8lq1i40imgwmMfDYqNgZTmNmRciEfr5dOcGf6SRSo+WqRKHfYpCK/syZudjRgjeJHnwNvs18/FGSQy8Vq2KEdWqOmRiIJl204+B3fRaLt0PZ+JOfzy4GFzS+/sgDgvBRTzQ4Qyc0fudOHwbFuMDffHgR7AQ7xvA7+CHcXG+EKwIua6tdXaHTQhbUDHQlmQZgzqY9kgFc9D02sYg2qqxa8GyXbGDbyVtOwnfwSWcN2wbfgYvipPgeQDBfi5kvyjWApsQdgeuElVg16Hl+RWRc3b9vxuGZRnsGErDk2CXbRCkGzvqfEDfJhnc1KQwcMnMgKgDrBLPB6/Gfq+VtM5/gn9opYwGeyKRCE/wKF5rVQX6KxXUzl3IqNmSGvyRUfwX5LF4SUBTjPcae5oNkSTJowUduE0y9qOA2Kl2WJ4u1imWJKaRXLoVSUOuENNBjy3+NXLr0tgJSk+MhZQN4f4nwU9zivo8qD+4dCuIwMzYtsBMGMaOLRWj+SxaewicoWVcdHuiWmv5XgpXbvfU1rHKabsrKxEuUXJsgdKFY08sUrr4hHcI4JDXpZoZO3xPZa8tLb3G4PTJGLNyMeGpcD3YKiig7qgdW4BROu754wDjvjfeeSbVpxyB+rNLr0Yiry7tfXNJzRlUDWOJ9GIjOzn5C10gKZGT6k5OMliKWJ7sD5iO4GywiOlQYZ2pJQ1e1+hTmhY8Cy9rWWROU1WDn2ul8P7X2YdskpTJMCFRF9tXNLSLsBi7JIZCxvZtbGpE92qD1TptjdJmkZo6Ze+tu9kyVErnjkxsTBw5V65Wy7icnp4Yba5rxQx0Ol9Ynm+355dfWp4fGZlfNq439hztSX7z8MTG0cPnKmWAct/QNTVTPD0SSvYUevVxBf2bIRqpY7R4+VgfHvFrxE1/ZliqNtBJTNd+9LjlD3vNEvhe0zYT6LXJKdkMPopGQdvcBC0aDT7avK06ytqq6pjK6los9tBGUdgJIfCwQmdWUVZXFdNRke+oirK2JjZrq7jZngvvsLvsS+QR3Hi1BoSztIpTD8SnBEX8ljJhn6Bjtodcz2dvOlZtiycjp1JjqVPMkLZcK381wmGX5OgV40+SKb3b70suSFH4beGAVKUqvzMwcIertCodKFyJpvl911Jii4wtpna593k62r2nP6MvkyRLHg/7qCRymMDbQL9w1O8HzGSJ9rysQ1X6hJ9F6PmJ4z30lP4tlYpUrmf3Zq6XI0b6ezf7GtrxKa3ed3OyF4LsVJzY/wXBVKeSfFcEYZR1pxvGVNpzbs5o2sxNx0t/Nx+pZjc2stVIPp8/KFVBk9430mnjfUlDpw7mr0RNvpUumWGAMcXctcXN6Hb/InmD/hInRZ34GKW4WVGWLQxRjOWEiFkyS6JweUXMylbNrbSkbh2nK0Yl7Hi4Kyfk2Tme1KW5OSmekuZmuaHz2dno1+lQOpdLdz54+i3Of/cUpwOdDzMvT06ugCJ9QpbrBp+dk1LrfSn4ZzoH8vRtbvB3puhAYKRemp5a2e7TPfQNMW/TveGCI+U2u3Hhwg0WUniht0JKhOSDV9g99lUiExN78lNkDxkjR8lXyGnyDfICvuU4i+r4ONvcxLp3cSY1bcsVZ+LJLgJ3pTp4mMgivt0udga+ydgPUr8rtESqdXB9vI3RsAp08FvYLwUwccS1/dGwFASaP4j9XwxB6/h7ABGGQKCN0I4sO/kkft6zShYAkr/LBYfzvJx3ZHlTLyS4figu6OWkZSXPJk0zeUjniYL+XFxO5vXsdCg4JZTuoXYIsHPCgf8YxQrxy0L4gFBeFzBpPbSZ4DNilxMkqXOEawjo+DznTkHeLVyTN3ZA85yPh6AfX34IM2EhZsICK3khdKvLo6FbfFpobbtFyP8ABbSm1wAAeJxjYGRgYABiI4Z9m+L5bb4ycLMwgMANt70hCPr/AhYG5nggl4OBCSQKABUjCcAAeJxjYGRgYG7438AQw8IAAkCSkQEVCAAARxYCeXicY2FgYGChAAMACMAAQQAAAAAAAKoA4AEOASgBWAGOAfICGAJoArYC/ANuA8YD4ASoAAB4nGNgZGBgEGBoZOBmAAEmIOYCQgaG/2A+AwAXkAGzAHicdZDLSgNBEEXv5KE4Ay4Us243Ckomj40QcBVIXEfIfjLpyYN50ekEkoV/4MLv8Sv8Af0K914nFQgx9tDFqVu3aooGcIFPONieK94tO/CYbbmEUyjhMvVb4Qq5LVwlPwqfkJ+EXdzjWdjDJV44wamcMbvDm7CDGt6FSzjHh3CZ+pdwhfwtXEXN8YRPyNfCLobOg7CHG+fV7RodWD1Wo7WahVkaZal14019xwM9WcaB2VP2cKjNYpalquU399S+TrXZzVysJm1rIxWZLFE9VnUcZyo32VyH1p9am3cajUh0P8wSrtiFgUYAyzjms46wZpwhRIYUUREtfTE2qP/RB+yaYMlqwDnHPcfVITsNFtR/c4UWfDT/8fbpTQv/4Z4LrPj/NlVLt+I17ElIPenVnBmTFfKiNqcSUvcxLbpydNDgFx34/WKH5AemYneTeJxtTNsOwiAUo5PLNm/zU/ZF5kwnO4ZAFEjmvl6Ir/ahbdq0ohE/9OI/BjTYQUJBw6BFhx57HHDECWcMuAjpaCJtM/mJ9ZNpoWCK+KJ6Lek2qzunPMrK7VoaW0jHkGMO5sXe3pbcxUTv64Odk9WplNnO8lPm9WsjHoX4AgocJZU=') format('woff');
	}
	.gcard{
		margin-bottom: 5rpx;
		background-color: #FFFFFF;
		display: flex;
		width: 710rpx;
		height: 250rpx;
		margin-left: 20rpx;
		border-radius:20rpx;
		box-shadow:0 5rpx 4rpx rgba(0, 0, 0, .3);
	}
	.zhifu{
		padding-top: 20rpx;
		height: 110rpx;
		background-color: #FFFFFF;
		display: flex;
		box-shadow:0 -3rpx 4rpx rgba(0, 0, 0, .3);
	}
	.lz-iconfont {
	  font-family: 'lz-iconfont' !important;
	  font-size: inherit;
	  font-weight: normal;
	  font-style: normal;
	  display: inline-block;
	  text-decoration: none;
	  -webkit-font-smoothing: antialiased;
	  -moz-osx-font-smoothing: grayscale;
	}
	
	.lz-icon-jiahao:before {
	  content: "\e727";
	}
	.lz-icon-jianhao:before {
	  content: "\e729";
	}
	
</style>

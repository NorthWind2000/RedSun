<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="账单结算"
				color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view style="background-color: #FFFFFF; display: flex;" @click="golianxiren">
				<image style="margin-left: 30rpx; width: 100rpx;height: 100rpx;" src="../../static/tianjia.png"></image>
				<view style="height: 100rpx;line-height: 100rpx; margin-left: 20rpx;">添加收货人</view>
				<image style="margin-left: 370rpx; margin-top: 30rpx;width: 40rpx;height: 40rpx;"
					src="../../static/jiantou.png"></image>
			</view>
			<view v-for="item,index in jiesuandata"
				style="margin-top: 20rpx; background-color: #FFFFFF; display: flex; width: 750rpx;height: 250rpx;">
				<image style="margin-left:30rpx; width: 200rpx;height: 200rpx;"
					:src="'https://www.360zcc.top/'+item.image"></image>
				<view style="margin-left: 10rpx;margin-top: 30rpx;">
					<view>
						<textarea disable="true"
							style="margin-left: 10rpx; height: 80rpx; width: 400rpx;font-size: 25rpx;">{{item.gname}}</textarea>
					</view>
					<view style="margin-top: 20rpx;padding-left: 20rpx;display: flex;">
						<view style=" width: 200rpx;color: #CC0000;">{{item.jifen}}积分</view>
						<view style="margin-left: 150rpx; width:100rpx;font-size: 30rpx;">x{{item.count}}</view>
					</view>
				</view>
			</view>
			<view>
				<view class="ui-all">
					<view class="ui-list">
						<text>收货人</text>
						<input type="text" disabled="true" v-model="dizhi.realname" />
					</view>
					<view class="ui-list">
						<text>手机号</text>
						<input type="text" disabled="true" v-model="dizhi.phone" />
					</view>
					<view class="ui-list">
						<text>商品积分</text>
						<input type="text" disabled="true" v-model="jifen" />
					</view>
					<view class="ui-list">
						<text>收货地址</text>
						<input disabled="true" type="text"
							v-model="dizhi.province+dizhi.city+dizhi.county+dizhi.detailaddress" />
					</view>
					<view class="ui-list">
						<text>小区名称</text>
						<input disabled="true" type="text" v-model="dizhi.xiaoqu" />
					</view>
				</view>
			</view>
		</scroll-view>
		<view style="padding-top: 20rpx;height: 130rpx; background-color: #FFFFFF;display: flex">
			<view style="font-size: 26rpx; width: 100rpx; height: 80rpx; line-height: 80rpx; margin-left: 200rpx;">合计：
			</view>
			<view style="width: 250rpx;height: 80rpx; line-height: 80rpx;font-size:40rpx;color: #A32E03;">{{jifen}}积分
			</view>
			<button @click="tijiao" type="warn"
				style="color: #FFFFFF; line-height: 80rpx;margin-right: 20rpx; background-color: #FF5053; border-radius: 50rpx;width: 300rpx;height: 80rpx;">提交订单</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hheight: 500,
				jiesuandata: [],
				dizhi: {},
				url: "",
				jifen: 0

			};
		},
		created() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 165
			if (this.$store.getters.getOncebuy == 1) {
				this.jiesuandata = this.$store.getters.getJiesuan
			} else {
				this.jiesuandata = this.$store.getters.getGouwuche
				this.url = "/shoppingcar"
			}
			this.dizhi = this.$store.getters.getAddressinfo
			var sum = 0;
			for (var i = 0; i < this.jiesuandata.length; i++) {
				sum += this.jiesuandata[i].count * this.jiesuandata[i].jifen
			}
			this.jifen = sum;
		},
		methods: {
			goback() {
				if (this.$store.getters.getOncebuy == 1) {
					this.$store.commit("clearJiesuan");
				}
				uni.navigateBack()
			},
			golianxiren(){
				uni.navigateTo({
					url:"/pages/dizhi/index"
				})
			},
			tijiao() {
				var thit = this
				if (this.dizhi.xiaoqu == "") {
					uni.showToast({
						title: '请完善地址信息',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				
				this.myRequest({
					method: "GET",
					url: "/hwgs/user/jifen"
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						var curjifen=res.data
						if(curjifen>=thit.jifen){
							this.tijiaodingdan(thit)
						}
						else{
							uni.showToast({
								title: '抱歉，您的积分不足，无法购买！',
								icon: 'none',
								duration: 2000
							});
							return;
						}
					}
				});
			},
			tijiaodingdan(thit){
				uni.showModal({
					title: '提示',
					content: '确认结算',
					success: function(res) {
						if (res.confirm) {
							let goodsdata = {};
							goodsdata["realname"] = thit.dizhi.realname;
							goodsdata["phone"] = thit.dizhi.phone;
							goodsdata["address"] = thit.dizhi.province + thit.dizhi.city + thit.dizhi
								.county + thit.dizhi.detailaddress;
							goodsdata["jifen"] = thit.jifen;
							var goodsdatalist = [];
							for (var i = 0; i < thit.jiesuandata.length; i++) {
								goodsdatalist.push({
									gid: thit.jiesuandata[i].id,
									gname: thit.jiesuandata[i].gname,
									image: thit.jiesuandata[i].image,
									jifen: thit.jiesuandata[i].jifen,
									count: thit.jiesuandata[i].count,
								});
							}
							goodsdata["orderdetail"] = JSON.stringify(goodsdatalist);
							thit.myRequest({
									method: "post",
									url: "/hwgs/dingdan" + thit.url,
									data: goodsdata
								})
								.then((response) => {
									var res = response.data;
									if (res.code == "200") {
										uni.showToast({
											title: '提交成功',
											icon: 'none',
											duration: 2000
										});
										uni.navigateBack();
									}
								});
							if (thit.$store.getters.getOncebuy == 1) {
								thit.$store.commit("clearJiesuan");
							} else {
								thit.$store.commit("clearGouwuche");
							}
						}
					}
				})
			}
			
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	page {
		background-color: #D8D8D8;
	}

	.ui-all {
		margin-top: 30rpx;
		background-color: #FFFFFF;
		padding: 20rpx 10rpx;

		.ui-list {
			width: 750rpx;
			padding: 20rpx 0;
			border-bottom: solid 2px #f2f2f2;

			text {
				color: #4a4a4a;
				font-size: 27rpx;
				display: inline-block;
				min-width: 150rpx;
				text-align: right;
			}

			input {
				color: #030303;
				font-size: 28rpx;
				display: inline-block;
				text-align: right;
				width: 550rpx;
			}
		}
	}
</style>

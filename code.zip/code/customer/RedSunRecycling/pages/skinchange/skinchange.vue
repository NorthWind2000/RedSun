<template>
	<view>
		<view>
			<view>
				<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="垃圾分类小助手" color="white"></uni-nav-bar>
			</view>
		</view>
		<view class="list-content">
			<radio-group @change="radioChange">
				<label class="list" v-for="(item, index) in items" :key="item.value">
					<view class="text">{{item.name}}</view>
					<view>
						<radio :value="item.value" :checked="index === current" />
					</view>
				</label>
			</radio-group>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				title: 'radio',
				items: [{
						value: '#fa5a5a',
						name: '火焰红',
					},
					{
						value: '#82c8a0',
						name: '草木绿',
					},
					{
						value: '#7fccde',
						name: '湖光青',
					},
					{
						value: '#6698cb',
						name: '深海蓝',
					},
					{
						value: '#cb99c5',
						name: '青春粉',
					},
					{
						value: '#5351fb',
						name: '经典紫',
					}
				],
				current: 1
			}
		},
		beforeMount() {
			if(uni.getStorageSync('zhutiindex')){
				this.current = uni.getStorageSync('zhutiindex');	
			}
		},
		methods: {
			radioChange(evt) {
				for (let i = 0; i < this.items.length; i++) {
					if (this.items[i].value === evt.target.value) {
						this.current = i;
						break;
					}
				}
				this.$store.commit("setZhuti",this.items[this.current].value);
				uni.setStorageSync('zhuti', this.items[this.current].value);
				uni.setStorageSync('zhutiindex', this.current);
			},
			goback(){
				uni.navigateBack({
					url:"/pages/myhome/myhome"
				})
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style>
	.list-content{
		padding: 20upx;
		font-size: 30upx;
	}
	.list{
		display:flex;
		height: 100upx;
		line-height: 100upx;
		width: 100%;
		border-bottom:1px solid rgb(243,243,243);
	}
	.text{
		flex:1 1 auto;
	}
	
</style>
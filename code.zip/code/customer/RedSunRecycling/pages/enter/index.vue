<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" :background-color="zhuti" title="登录授权" color="white"></uni-nav-bar>
		</view>
		<view>
			<view>
				<view>申请获取以下权限</view>
				<text>获得你的公开信息(昵称，头像、地区等)</text>
			</view>
			<button :loading="loading" style="width: 300rpx;" type='primary' withCredentials="true" lang="zh_CN" @click="wxGetUserInfo">
				授权登录
			</button>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				loading:false
			}
		},
		methods: {
			//第一次授权获取用户信息===》按钮触发
			wxGetUserInfo() {
				this.loading=true
				let _this = this;

				uni.getUserProfile({
					provider: 'weixin',
					desc:"用于完善会员资料",
					success: function(infoRes) {
						console.log(infoRes)
						let nickName = infoRes.userInfo.nickName; //昵称
						let avatarUrl = infoRes.userInfo.avatarUrl; //头像
						_this.$store.commit("setNickName", nickName);
						_this.$store.commit("setAvatarUrl", avatarUrl);
						uni.setStorageSync('isShouquan', true); //记录是否已授权  true:表示已授权
						uni.setStorageSync('nickName', nickName);
						uni.setStorageSync('avatarUrl', avatarUrl);
						_this.login()
					},
					fail:function(){
						_this.loading=false
					}
				});
			},

			//使用到的登录接口
			login() {
				let _this = this;
				// wx获取登录用户code
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						//获取到code 拿着code去请求后台接口换openid和unionid 这里说到unionid只有关联了微信开放平台才会有
						_this.myRequest({
							method: "GET",
							url: "/hwgs/login/" + loginRes.code
						}).then((response) => {
							var res = response.data;
							if (res.code == "200") {
								uni.setStorageSync('token', res.data);
								_this.init()
								uni.navigateBack()
							}
						});
					}
				})
			},
			init(){
				this.myRequest({
					method: "GET",
					url: "/hwgs/user"
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.$store.commit("setAddressinfo",res.data);
					}
				});
				this.myRequest({
					method: "GET",
					url: "/hwgs/gouwuche"
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.$store.commit("setGouwuche",res.data);
					}
				});
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components: {

		},
	}
</script>

<style>
</style>

<template>
	<view>
		<view>
			<view>
				<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="垃圾分类小助手" color="white"></uni-nav-bar>
			</view>
		</view>
		<view>
				<u-parse :content="content" @navigate="navigate"></u-parse>
		</view>
	</view>
</template>

<script>
	import uParse from "@/components/feng-parse/parse.vue"
	export default {
		data() {
			return {
				title: 'Hello Feng',
				content:'<image src="/static/image/touxiang.jpg"></images>'
			};
		},
		methods:{
			
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components:{
			uParse
		}
	}
</script>

<style lang="scss">

</style>

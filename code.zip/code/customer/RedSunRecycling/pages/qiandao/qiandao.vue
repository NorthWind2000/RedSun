<template>
	<view>
		<view>
			<view>
				<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="垃圾分类小助手" color="white"></uni-nav-bar>
			</view>
		</view>
		<qiandao></qiandao>
	</view>
</template>

<script>
	import qiandao from "../../my-components/calendar/Calendar.vue"
	export default {
		data() {
			return {
			};
		},
		methods:{
			goback(){
				uni.navigateBack()
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components:{
			qiandao
		}
		
	}
</script>

<style lang="scss">

</style>

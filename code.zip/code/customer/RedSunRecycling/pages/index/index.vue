<template>
	<view class="index">
		<home v-if="tabberPageLoadFlag.home" :style="{display: curPage != 'home' ? 'none' : ''}" ref="home"></home>
		<shangcheng v-if="tabberPageLoadFlag.shangcheng" :style="{display: curPage != 'shangcheng' ? 'none' : ''}"
			ref="shangcheng"></shangcheng>
		<zixun v-if="tabberPageLoadFlag.zixun" :style="{display: curPage != 'zixun' ? 'none' : ''}" ref="zixun"></zixun>
		<my v-if="tabberPageLoadFlag.my" :style="{display: curPage != 'my' ? 'none' : ''}" ref="my"></my>


		<view class="cu-bar tabbar bg-white shadow foot">
			<view class="action" @click="navChange" data-cur="home">
				<view class='cuIcon-cu-image'>
					<image :src="'/static/colorimage/home' + [curPage=='home'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="curPage=='home'?'text-select-color':'text-color'">首页</view>
			</view>
			<view class="action" @click="navChange" data-cur="shangcheng">
				<view class='cuIcon-cu-image'>
					<image :src="'/static/colorimage/shangcheng' + [curPage=='shangcheng'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="curPage=='shangcheng'?'text-select-color':'text-color'">商城</view>
			</view>
			<view class="action" @click="navChange" data-cur="zixun">
				<view class='cuIcon-cu-image'>
					<image :src="'/static/colorimage/zixun' + [curPage=='zixun'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="curPage=='zixun'?'text-select-color':'text-color'">资讯</view>
			</view>
			<view class="action" @click="navChange" data-cur="my">
				<view class='cuIcon-cu-image'>
					<image :src="'/static/colorimage/my' + [curPage=='my'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="curPage=='my'?'text-select-color':'text-color'">我的</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniNavBar from "@/components/uni-nav-bar/uni-nav-bar.vue"
	import home from '@/pages/home/home';
	import shangcheng from '@/pages/shangcheng/index';
	import zixun from '@/pages/zixun/zixun';
	import my from '@/pages/myhome/myhome';
	export default {

		data() {
			return {
				curPage: 'home',
				tabberPageLoadFlag: {
					home: true,
					shangcheng: false,
					zixun: false,
					my: false
				}
			}
		},
		created() {
			if (uni.getStorageSync('zhuti')) {
				this.$store.commit("setZhuti", uni.getStorageSync('zhuti'))
			}

			if (!uni.getStorageSync('isShouquan')) {
				this.goLogin()
			} else {
				this.init()
			}
			this.myRequest({
				method: "GET",
				url: "/hwgs/zixun/first"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.datalist = res.data
				}
			});
			this.$store.commit("setAvatarUrl", uni.getStorageSync('avatarUrl'));
			this.$store.commit("setNickName", uni.getStorageSync('nickName'));
		},
		methods: {
			init() {
				this.myRequest({
					method: "GET",
					url: "/hwgs/user"
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.$store.commit("setAddressinfo", res.data);
					}
				});
				this.myRequest({
					method: "GET",
					url: "/hwgs/gouwuche"
				}).then((response) => {
					var res = response.data;
					if (res.code == "200") {
						this.$store.commit("setGouwuche", res.data);
					}
				});
			},
			navChange(e) {
				this.curPage = this.$getDataSet(e, 'cur')
				this.tabberPageLoadFlag[this.curPage] = true

			},
			goLogin() {
				uni.navigateTo({
					url: "/pages/enter/index"
				})
			},
		},
		computed: {
			nickName() {
				return this.$store.getters.getNickName
			},
			avatarUrl() {
				return this.$store.getters.getAvatarUrl
			}
		},
		components: {
			uniNavBar,
			home,
			shangcheng,
			zixun,
			my
		}

	}
</script>

<style lang="scss">
</style>

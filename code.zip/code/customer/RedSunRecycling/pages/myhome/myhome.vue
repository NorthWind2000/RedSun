<template>
	<view class="components-theme">
		<view class='UCenter-bg'
			style="background-image: url(https://cdn.nlark.com/yuque/0/2019/jpeg/280373/1551924824231-assets/web-upload/5fd0d7ff-f3a9-41d5-a166-220621437c10.jpeg);">
				<view class='text-center'>
					<view class="cu-avatar round margin-right-sm shadow-blur bg-img"
						:style="'background-image:url('+avatar+');'">
					</view>
					<view class="padding text-black text-xxl">{{nickname}}</view>
				</view>
			</block>

			<image
				src='https://cdn.nlark.com/yuque/0/2019/gif/280373/1570670848649-assets/web-upload/3dbaa72a-062b-470f-9b9d-058ff8f85ab8.gif'
				mode='scaleToFill' class='gif-wave'></image>
		</view>
			<view class='padding flex text-center text-grey bg-white shadow-warp-my'>
				<view class='item flex flex-sub flex-direction solid-right' @click='goqiandao'>
					<view class="icon">
						<image src="../../static/user/qiandao.png" />
					</view>
					<view class="text">签到</view>
				</view>
				<view class='item flex flex-sub flex-direction' @click='goyuyue'>
					<view class="icon">
						<image src="../../static/yuyue.png" />
					</view>
					<view class="text">预约</view>
				</view>
			</view>

			<myhome></myhome>
	</view>
</template>

<script>
	import myhome from "@/my-components/myhome-com/wkiwi-user/wkiwi-user.vue"
	export default {
		data() {
			return {
				nickname: "",
				avatar: "",
			};
		},
		beforeMount() {
			this.nickname = this.$store.getters.getNickName
			this.avatar = this.$store.getters.getAvatarUrl
		},
		methods: {
			goqiandao() {
				uni.navigateTo({
					url: "/pages/qiandao/qiandao"
				});
			},
			goyuyue() {
				uni.navigateTo({
					url: "/pages/yuyue/index"
				})
			},
		},
		components: {
			myhome
		}
	}
</script>

<style lang="scss">
	.item {
		flex: 1 1 auto;
		display: flex;
		flex-wrap: wrap;
		flex-direction: row;
		justify-content: center;
		margin: 15rpx 0;
	}

	.icon {
		flex-shrink: 0;
		width: 50rpx;
		height: 50rpx;

		image {
			margin-left: 10rpx;
			width: 50rpx;
			height: 50rpx;
		}
	}

	.text {
		padding-left: 20upx;
		width: 100%;
		color: #666;
	}

	.UCenter-bg {
		background: #fff;
		background-size: 100% 100%;
		/* background-size: cover; */
		height: 550rpx;
		display: flex;
		justify-content: center;
		padding-top: 40rpx;
		overflow: hidden;
		position: relative;
		flex-direction: column;
		align-items: center;
		color: #fff;
		font-weight: 300;
		text-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
	}

	.UCenter-bg text {
		opacity: 0.8;
	}

	.UCenter-bg image {
		width: 200rpx;
		height: 200rpx;
	}

	.UCenter-bg .gif-wave {
		position: absolute;
		width: 100%;
		bottom: 0;
		left: 0;
		z-index: 99;
		mix-blend-mode: screen;
		height: 100rpx;
	}

	map,
	.mapBox {
		left: 0;
		z-index: 99;
		mix-blend-mode: screen;
		height: 100rpx;
	}

	map,
	.mapBox {
		width: 750rpx;
		height: 300rpx;
	}



	.cu-avatar {
		font-variant: small-caps;
		margin: 0;
		padding: 0;
		display: inline-flex;
		text-align: center;
		justify-content: center;
		align-items: center;
		background: #ccc;
		color: #fff;
		white-space: nowrap;
		position: relative;
		width: 150rpx;
		height: 150rpx;
		background-size: cover;
		background-position: center;
		vertical-align: middle;
		font-size: 1.5em;
		z-index: 0;
	}

	.name {
		text-shadow: 2px 2px 1px #FFFFFF;
	}

	.dialog2 {
		background: none;
	}

	.saicode {
		background-size: 100% 100%;
		-moz-background-size: 100% 100%;
	}

	.img-big image {
		top: -40px;
		width: 280rpx;
		height: 280rpx;
	}


	.shadow-me {
		box-shadow: 0rpx 0rpx 100rpx 0rpx rgba(0, 0, 0, 0.1);
	}

	.tn-footerfixed {
		position: fixed;
		width: 100%;
		bottom: 0;
		z-index: 1024;
		box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0.35);
	}

	.my_logo {
		background: none;
		padding: 50rpx 0 30rpx 0;
	}

	.my-radius {
		border-radius: 12rpx;
		overflow: hidden
	}

	.my-icon image {
		width: 100rpx;
		height: 100rpx;
		display: inline-block;
		margin: 0 auto
	}

	.my-iconcolor {
		background: rgba(255, 255, 255, 0.96)
	}

	.shadow-shop {
		box-shadow: 0rpx 0rpx 90rpx 0rpx rgba(0, 0, 0, 0.1);
	}

	.qrcode-img {
		position: fixed;
		width: 80rpx;
		height: 80rpx;
		bottom: 350rpx;
		right: 30rpx;
		z-index: 1024;
		opacity: 0.8;
		box-shadow: 0rpx 8rpx 30rpx 0rpx rgba(0, 0, 0, 0.3);
		border: none
	}


	/* 数字背景 */
	.shadow-warp-my {
		position: relative;
		box-shadow: 0 10rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.shadow-warp-my:before,
	.shadow-warp-my:after {
		position: absolute;
		content: "";
		top: 20rpx;
		bottom: 30rpx;
		left: 20rpx;
		width: 50%;
		box-shadow: 0 30rpx 20rpx rgba(0, 0, 0, 0.16);
		transform: rotate(-6deg);
		z-index: -1;
	}

	.shadow-warp-my:after {
		right: 20rpx;
		left: auto;
		transform: rotate(6deg);
	}


	.bg-product {
		background-image: linear-gradient(rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0));
		color: #fff;
	}

	.margin-bottom-my {
		margin-bottom: 150rpx;
	}
</style>

<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" :background-color="zhuti" title="资讯专区"
				color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'rpx'}" scroll-y="true" scroll-left="120" @scrolltolower="gonextpage">
			<view class="content">
				<view class="cu-card article" v-for="item,index in datalist" :key="index">
					<view class="cu-item shadow" @click='click(item)'>
						<view class="content">
							<image :src="'http://www.360zcc.top/'+item.image" mode="aspectFill"></image>
							<view class="desc">
								<view class="text-content">{{item.title}}</view>
								<view>
									<view class="cu-tag bg-green light sm round">{{item.publishtime}}</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hheight: 500,
				curpage: 0,
				datalist: [],
				allcount: 0
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight+525
			this.myRequest({
				method: "GET",
				url: "/hwgs/zixun/allcount"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.allcount = res.data
					this.gonextpage()
				}
			});
		},
		methods: {
			click(item) {
				this.$store.commit("setZixun", item);
				uni.navigateTo({
					url: "/pages/zixundetail/index/index"
				})
			},
			gonextpage() {
				this.curpage += 1
				if (this.datalist.length < this.allcount) {
					this.myRequest({
						method: "GET",
						url: "/hwgs/zixun/page/" + this.curpage
					}).then((response) => {
						var res = response.data;
						if (res.code == "200") {
							for (var i = 0; i < res.data.length; i++) {
								this.datalist.push(res.data[i])
							}
						}
					});
				}
			}

		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style lang="scss">
	page {
		width: 100%;
		height: 100%;
		background-color: #AAAAAA;
	}
</style>

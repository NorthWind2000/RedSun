<template>
	<view class="container">
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="我的积分" color="white"></uni-nav-bar>
		</view>
		<view style="text-align: center; padding-left: 250rpx;margin-top: 30rpx; width: 750rpx;height: 300rpx;">
			<view style="color: #007FFF; font-size: 50rpx; text-align: center;line-height: 250rpx; width: 250rpx;height: 250rpx;border-radius: 150rpx; background-color: #5BE9FF;">
				{{jifen}}
			</view>
			<view style="width: 250rpx; font-size: 40rpx;color: #8DC63F;">当前积分</view>
		</view>

		<view class="biaoqian">积分赚取方式</view>
		<view class="zhuji">
			1. 通过每日打卡签到获取积分，每次签到成功后将可获取1积分。<br/>
			2. 通过知识问答获取积分，每一个用户一天拥有三次答题的机会，每正确回答一道题将可获取1个积分。<br/>
			3. 通过智能识别功能获取积分，每天不限次数，每一次拍照识别，用户将可获得1积分。<br/>
			4. 呼叫上门回收，每成功交易一单，1元可获取1积分。
		</view>
		<view class="biaoqian">积分消费方式</view>
		<view style="height: 100rpx;" class="zhuji">
			用户可在积分商城使用积分换取商品，用户成功换取的商品我们将免费包邮到家。
		</view>
	</view>
</template>

<script>

	export default {
		data() {
			return {
				jifen:0
			}
		},
		beforeMount(){
			this.myRequest({
				method: "GET",
				url: "/hwgs/user/jifen"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.jifen=res.data
				}
			});
		},
		methods: {
			goback(){
				uni.navigateBack()
			},
			conClick(e) {
			                this.$refs.clickCircle.conClick(e);
			            }
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		}
	}
</script>

<style lang="scss">
	.biaoqian{
		width: 250rpx;
		height: 50rpx;
		margin-top: 30rpx;
		margin-left:50rpx;
		border-radius: 30rpx;
		background-color: #B8E986;
		text-align: center;
	}
	.zhuji{
		width: 650rpx;
		height: 400rpx;
		margin:10rpx auto;
		padding: 10rpx;
		background-color: #F9F9F9;
		border-radius: 30rpx;
		border: solid #B2B2B2 2rpx;
	}
	image{
		width: 700rpx;
		height: 450rpx;
		margin-left: 25rpx;
	}
</style>

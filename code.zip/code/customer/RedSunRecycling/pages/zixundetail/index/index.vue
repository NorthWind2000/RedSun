<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="资讯专区" color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view>
				<view style="width:700rpx;margin-left: 25rpx; margin-top: 10rpx;margin-bottom: 20rpx; font-weight: bold;">{{zixundata.title}}</view>
				<view style="width:700rpx;margin-left: 25rpx; font-size: 25rpx;">{{zixundata.publishtime}}</view>
				<view style="margin-left: 25rpx; width: 700rpx; border-bottom: #09BB07 1rpx solid"></view>
				<view style="width: 700rpx;margin-top: 20rpx;margin-left: 25rpx;">
					<u-parse :content="zixundata.content" @navigate="navigate"></u-parse>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import uParse from "@/components/feng-parse/parse.vue"
	export default {
		data() {
			return {
				zixundata: {},
				hheight: 500,
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 100
			this.zixundata = this.$store.getters.getZixun
			this.myRequest({
				method: "GET",
				url: "/hwgs/zixuncontent/"+this.zixundata.id
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.zixundata.content=res.data
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
		components: {
			uParse
		}
	}
</script>

<style>
	@import url("@/components/feng-parse/parse.css");
	image {
		width: 700rpx;
		margin-top: 10rpx;
		margin-bottom: 10rpx;
	}
</style>

<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="发布动态" color="white"></uni-nav-bar>
		</view>
		<view style="margin-top: 20rpx; border-radius: 20rpx; margin-left: 25rpx; width: 700rpx;height: 600rpx; border: #BBBBBB 1rpx solid">
			<textarea v-model="content" style="margin-top: 10rpx; margin-left: 10rpx; width: 680rpx;height: 580rpx;"></textarea>
		</view>
		<view :style="{'margin-top:20rpx;width: 750rpx;height':hheight+'rpx;'}">
			<view v-if="!isCanAdd" style="margin-left: 25rpx;width: 710rpx;">
				<image @tap="selectImage" style="border: #BBBBBB 1rpx solid; border-radius: 15rpx;" :src="imageurl"></image>
			</view>
			<view v-if="isCanAdd" class="imageUpload" @tap="selectImage">+</view>
		</view>
		<button @click="sumbit" style="margin-top: 20rpx;width: 200rpx;" type="primary">发布</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				content: "",
				imageurl: '',
				isCanAdd: true,
				hheight: 500,
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 160
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			},
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			selectImage: function() {
				var _self = this

				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['camera', 'album'],
					success: function(res) {
						_self.imageurl = res.tempFilePaths[0]
						_self.isCanAdd = false
					}
				});
			},
			sumbit() {
				var _self = this
				console.log(123)
				uni.uploadFile({
					url: 'https://www.360zcc.cn'+'/hwgs/shequ/dongtai',
					filePath:_self.imageurl,
					name: 'file',
					header:{
						'Authorization':uni.getStorageSync('token')
					},
					formData: {
						'content':_self.content,
						'avatar':_self.$store.getters.getAvatarUrl,
						'nickname':_self.$store.getters.getNickName,
					},
					success: (uploadFileRes) => {
						console.log(uploadFileRes.data);
					}
				});
			},
		}
	}
</script>

<style>
	.imageUpload {
		margin-left: 20rpx;
		width: 200rpx;
		height: 200rpx;
		line-height: 200rpx;
		text-align: center;
		font-size: 150rpx;
		color: #D9D9D9;
		border: 1px solid #D9D9D9;
		border-radius: 8rpx;
	}
</style>

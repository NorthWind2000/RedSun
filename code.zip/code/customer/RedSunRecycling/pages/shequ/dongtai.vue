<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="动态详情" color="white"></uni-nav-bar>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120">
			<view style="display: flex;text-align: center;">
				<view style="margin-left: 30rpx; margin-top: 20rpx; width: 120rpx;height: 120rpx;">
					<image style="width: 120rpx;height: 120rpx;border-radius: 60rpx;" :src="dongtaiData.avatar"></image>
				</view>
				<view style="margin-top: 30rpx; text-align: left; margin-left: 10rpx; height: 80rpx;width: 200rpx;">
					<text style="width: 100rpx; font-size: 32rpx;line-height: 40rpx;height: 40rpx;">{{dongtaiData.nickname}}</text><br />
					<text style="color: #B2B2B2; width: 100rpx; font-size: 25rpx;line-height: 40rpx;height: 40rpx;">{{dongtaiData.pubtime}}</text>
				</view>
			</view>
			<view style="max-height: 700rpx; margin-top: 10px; padding: 15rpx; width: 670rpx;margin-left:30rpx;">
				{{dongtaiData.content}}
			</view>
			<view>
				<image style="margin-left: 40rpx; width: 680rpx;" mode="aspectFit" :src="'https://www.360zcc.top/'+dongtaiData.image"></image>
			</view>
			<view style="margin-bottom: 20rpx; margin-left:500rpx; width: 750rpx;display: flex;">
				<view @click="dianzan">
					<image style="width: 50rpx;height: 50rpx;" src="../../static/dianzan.png"></image>
					<text style="line-height: 50rpx;">{{dongtaiData.likenum}}</text>
				</view>
				<view style="margin-left: 30rpx;">
					<image style="width: 50rpx;height: 50rpx;" src="../../static/liaotian.png"></image>
					<text style="line-height: 50rpx;">{{dongtaiData.commentnum}}</text>
				</view>
			</view>
			<view style="width: 750rpx; height: 30rpx; background-color: #F0F0F0;"></view>
			<view style="margin-left: 10rpx;width: 730rpx;">
				<view style="margin-bottom: 20rpx;" v-for="item in pinglun">
					<view style="display: flex;text-align: center;">
						<view style="margin-left: 30rpx; margin-top: 20rpx; width: 120rpx;height: 120rpx;">
							<image style="width: 100rpx;height: 100rpx;border-radius: 50rpx;" :src="item.avatar"></image>
						</view>
						<view style="margin-top: 20rpx; text-align: left; margin-left: 10rpx; height: 80rpx;width: 200rpx;">
							<text style="width: 100rpx; font-size: 30rpx;line-height: 40rpx;height: 40rpx;">{{item.nickname}}</text><br />
							<text style="color: #B2B2B2; width: 100rpx; font-size: 23rpx;line-height: 40rpx;height: 40rpx;">{{item.pubtime}}</text>
						</view>
					</view>
					<view style="border-bottom:#D3D3D3 1rpx solid; max-height: 200rpx; padding: 15rpx; width: 670rpx;margin-left:30rpx;">
						{{item.content}}
					</view>
				</view>
			</view>
		</scroll-view>
		<view>
			<button @click="pinglunit" style="font-size: 35rpx; line-height: 80rpx; height: 80rpx; width: 500rpx;" type="primary"
			 plain="true">评论一下</button>
		</view>
		<ygc-comment ref="ygcComment" :placeholder="'发布评论'" @pubComment="pubComment"></ygc-comment>

	</view>
</template>

<script>
	import ygcComment from '@/components/ygc-comment/ygc-comment.vue';

	export default {
		data() {
			return {
				boolShow: false,
				hheight: 500,
				dongtaiData: {},
				pinglun: [],
				comment:''
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 150
			this.dongtaiData = this.$store.getters.getDongtai
			this.myRequest({
				method: "GET",
				url: "/hwgs/pinglun/"+this.dongtaiData.id
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.pinglun=res.data
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			pinglunit() {
				this.$refs.ygcComment.toggleMask(1);
			},
			dianzan(){
				this.myRequest({
					method: "GET",
					url: "/hwgs/dongtai/like/"+this.dongtaiData.id,
				})
				this.dongtaiData.likenum+=1
			},
			pubComment(e){
				this.myRequest({
					method: "POST",
					url: "/hwgs/pinglun",
					data:{
						content:e,
						avatar:this.$store.getters.getAvatarUrl,
						nickname:this.$store.getters.getNickName,
						fid:this.dongtaiData.id
					}
				})
				this.dongtaiData.commentnum+=1
			}
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		components: {
			ygcComment
		}
	}
</script>

<style>

</style>

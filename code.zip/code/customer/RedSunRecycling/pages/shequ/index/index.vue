<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="社区动态" color="white"></uni-nav-bar>
		</view>
		<view>
			<drag-button :texta="texta" @btnClick="fabu"></drag-button>
		</view>
		<scroll-view :style="{height:hheight+'px'}" scroll-y="true" scroll-left="120"  @scrolltolower="gonextpage">
		<view @click="godongtai(item)" v-for="item in datalist">
			<hm-talk-card :options="item"></hm-talk-card>
		</view>
		</scroll-view>
	</view>
</template>

<script>
	import HmTalkCard from '@/components/hm-talk-card/index.vue'
	import dragButton from "@/components/drag-button/drag-button.vue"
	export default {
		components: {
			HmTalkCard,
			dragButton
		},
		data() {
			return {
				texta:"发布",
				hheight:500,
				curpage:0,
				datalist: [],
				allcount:0
			}
		},
		beforeMount() {
			var res = uni.getSystemInfoSync()
			this.hheight = res.windowHeight - 70
			this.myRequest({
				method: "GET",
				url: "/hwgs/shequ/allcount"
			}).then((response) => {
				var res = response.data;
				if (res.code == "200") {
					this.allcount=res.data
					this.gonextpage()
				}
			});
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			fabu(){
				uni.navigateTo({
					url:'../fabu'
				})
			},
			godongtai(item){
				this.$store.commit("setDongtai",item);
				uni.navigateTo({
					url: "/pages/shequ/dongtai"
				})
			},
			gonextpage(){
				this.curpage+=1
				if(this.datalist.length<this.allcount){
					this.myRequest({
						method: "GET",
						url: "/hwgs/shequ/"+this.curpage
					}).then((response) => {
						var res = response.data;
						if (res.code == "200") {			
							for(var i=0; i<res.data.length; i++){
							     this.datalist.push(res.data[i])
							}
						}
					});
				}
			}
		},
		computed: {
			zhuti(){
				return this.$store.getters.getZhuti
			}
		},
	}
</script>

<style>

</style>

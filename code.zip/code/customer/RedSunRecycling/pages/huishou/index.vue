<template>
	<view>
		<view>
			<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti" title="回收预约"
				color="white"></uni-nav-bar>
		</view>
		<view style="margin-top: 20rpx; margin-left: 30rpx; margin-bottom: 20rpx; font-size: 35rpx;">选择所需回收的类别</view>
		<view style="text-align: center; margin-bottom: 30rpx; margin-left: 30rpx;">
			<view style="margin-bottom: 20rpx; display: flex;">
				<image :class="isactive==1?'active':''" @click="dianji('衣物图书',1)" style="width: 334rpx; height: 200rpx;"
					src="../../static/leibie1.jpg"></image>
				<image :class="isactive==2?'active':''" @click="dianji('废旧物品',2)"
					style="margin-left: 20rpx; width: 334rpx; height: 200rpx;" src="../../static/leibie2.jpg"></image>
			</view>
			<view style="display: flex;">
				<image :class="isactive==3?'active':''" @click="dianji('大件家具',3)" style="width: 334rpx; height: 200rpx;"
					src="../../static/leibie3.jpg"></image>
				<image :class="isactive==4?'active':''" @click="dianji('高值二手',4)"
					style="margin-left: 20rpx; width: 334rpx; height: 200rpx;" src="../../static/leibie4.jpg"></image>
			</view>
		</view>
		<view style="margin-left: 30rpx; margin-bottom: 20rpx; font-size: 35rpx;">选择预约时间</view>
		<times @change="getTime"></times>
		<view style="margin-left: 30rpx; margin-bottom: 20rpx; font-size: 35rpx;">预约地址：</view>
		<textarea disabled="true" @click="godizhi" style="height: 170rpx; width: 700rpx; margin-left: 25rpx;">
			{{dizhi}}
		</textarea>
	</view>
</template>

<script>
	import times from '@/components/pretty-times/pretty-times.vue'

	export default {
		data() {
			return {
				avatar: "",
				isactive: 0,
				type:""
			}
		},
		methods: {
			goback() {
				uni.navigateBack()
			},
			dianji(type,e) {
				this.isactive = e
				this.type=type
			},
			godizhi(){
				uni.navigateTo({
					url:"../dizhi/index"
				})
			},
			getTime(e){
				if(this.dizhi==""){
					uni.showToast({
						title: '请完善地址信息',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				if(this.type==""){
					uni.showToast({
						title: '请选择回收类别',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				this.sumithuishou(e)
			},
			sumithuishou(e){
				this.myRequest({
					method: "POST",
					url: "/hwgs/huishou",
					data:{
						type:this.type,
						time:e,
						dizhi:this.dizhi,
						phone:this.$store.getters.getAddressinfo.phone,
						realname:this.$store.getters.getAddressinfo.realname
					}
				})
				uni.showToast({
					title: '预约成功',
					icon: 'none',
					duration: 2000
				});
			}
			

		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			},
			dizhi(){
				var dd=this.$store.getters.getAddressinfo
				return dd.province+dd.city+dd.county+dd.detailaddress
			}
			
		},
		components: {
			times
		}
	}
</script>

<style>
	.active {
		border: #0066CC 1rpx solid;
	}
</style>

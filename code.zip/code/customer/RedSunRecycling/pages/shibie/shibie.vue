<template>
	<view>
		<view>
			<view>
				<uni-nav-bar statusBar="true" left-icon="back" @clickLeft="goback" :background-color="zhuti"
					title="图像识别" color="white"></uni-nav-bar>
			</view>
		</view>
		<view>
			<drag-button @btnClick="takePhoto"></drag-button>
		</view>
		<camera device-position="back" flash="off" @error="error" style="width: 100%; height: 300px;"></camera>
		<text style="font-size: 27rpx;">识别结果\n\n</text>
		<view class="resultarea">
			<view class="headtitle">
				<view>名称</view>
				<view>可能性(百分制)</view>
				<view>垃圾种类</view>
			</view>
			<view v-show="active" class="parent">
				<ourLoading :active="active" text="识别中..." />
			</view>
			<view v-for="item in shibieresult" class="tail">
				<uni-grid :column="3" :show-border="false" :square="false">
					<uni-grid-item>
						<text class="text">{{item.name}}</text>
					</uni-grid-item>
					<uni-grid-item>
						<text class="text">{{item.confidence}}</text>
					</uni-grid-item>
					<uni-grid-item>
						<text class="text">{{item.type}}</text>
					</uni-grid-item>
				</uni-grid>
			</view>
			<text style="color: #00CE47;font-size: 26rpx;">\n垃圾分类，举手之劳，变废为宝，美化家园</text>
		</view>
	</view>
</template>

<script>
	import uniGrid from "@/components/uni-grid/uni-grid.vue"
	import uniGridItem from "@/components/uni-grid-item/uni-grid-item.vue"
	import dragButton from "@/components/drag-button/drag-button.vue"

	export default {
		data() {
			return {
				src: "",
				shibieresult: [],
				active:false
			};
		},
		methods: {
			goback(){
				uni.navigateBack()
			},
			takePhoto() {
				const ctx = uni.createCameraContext();
				this.active=true
				ctx.takePhoto({
					quality: 'high',
					success: (res) => {
						this.src = res.tempImagePath
						this.upImage(this.src)
					}
				});
			},
			upImage(src) {
				var that = this
				
				var header={}
				header['Authorization']=uni.getStorageSync('token')
				uni.uploadFile({
					url: 'https://www.360zcc.cn/hwgs/shibie',
					filePath: src,
					name: 'file',
					header:header,
					success: (uploadFileRes) => {
						that.shibieresult = JSON.parse(uploadFileRes.data).data
						this.active=false
						if(that.shibieresult.length==0){
							uni.showToast({
								title: '未识别出结果',
								duration: 2000
							});
						}
					}
				});
			}
		},
		computed: {
			zhuti() {
				return this.$store.getters.getZhuti
			}
		},
		components: {
			uniGrid,
			uniGridItem,
			dragButton
		}

	}
</script>

<style lang="scss">
	.resultarea {
		text-align: center;

		.headtitle {
			display: flex;
			text-align: center;

			view {
				font-size: 28rpx;
				width: 250rpx;
				height: 60rpx;
				border-bottom: solid #C8C7CC 3rpx;
			}
		}

		.tail {
			width: 750rpx;
			font-size: 28rpx;
		}
	}
	.parent {
	    width: 100rpx;
	    height: 100rpx;
		margin-left: 325rpx;
		margin-top: 300rpx;
	    position: relative;  /* 注意需要为加载器定义一个相对定位的父容器 */
	    .img {
	        max-width: 30rpx;
	        height: 100rpx;
	    }
	}
</style>

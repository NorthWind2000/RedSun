<template>
	<view>
		<view class="exam-item-testing">
			<view class="exam-item-inner" v-if='dataList.length > 0'>
				<view class="line_under exam-item-title">
					{{currentIndex+1}}.{{currentItem.question}}
				</view>
				<view style="height: 400rpx;">
					<radio-group>
						<view class="exam-item-option" @click="radioChange('A')">
							<radio disabled="true" :checked="currentItem.myanswer!='' && 'A' === currentItem.myanswer"/>
							<text>a.{{currentItem.a}}</text>
						</view>
						<view class="exam-item-option" @click="radioChange('B')">
							<radio disabled="true" :checked="currentItem.myanswer!='' && 'B' === currentItem.myanswer"/>
							<text>b.{{currentItem.b}}</text>
						</view>
						<view class="exam-item-option" @click="radioChange('C')" >
							<radio disabled="true" :checked="currentItem.myanswer!='' && 'C' === currentItem.myanswer"/>
							<text>c.{{currentItem.c}}</text>
						</view>
						<view class="exam-item-option" @click="radioChange('D')">
							<radio disabled="true" :checked="currentItem.myanswer!='' && 'D' === currentItem.myanswer" />
							<text>d.{{currentItem.d}}</text>
						</view>
					</radio-group>
				</view>

				<view class="exam-button-row">
					<view>
						<button :disabled="currentIndex == 0" size='mini' @click="lastQuestion" style="margin-right: 20rpx;">上一题</button>
						<button :disabled="shengyu!=0" size='mini' @click="finish" style="margin-right: 20rpx;">完成</button>
						<button :disabled="currentIndex == dataList.length-1" size='mini' @click="nextQuestion">下一题</button>
					</view>
				</view>

				<view v-show="isfinish">
					<label>答案：{{currentItem.answer}}</label><br />
					<label>解析：{{currentItem.jiexi}}</label>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'Li-ExamWidght',
		props: {
			dataList: {
				type: Array,
				default: function() {
					return [];
				}
			},
		},
		data() {
			return {
				shengyu: 0,
				isfinish: false,
				fenshu: 0,
				windowHeight: 500,
				showIndexBox: false,
				currentIndex: 0,
				currentItem: {}, //当前项
				currentCheck: -1, //单选选定
			};
		},
		watch: {
			dataList: function(val, oldVal) {
				this.init();
			}
		},
		created() {
			let that = this;
			uni.getSystemInfo({
				success: function(res) {
					that.windowHeight = res.windowHeight;
				}
			});
			this.init();
		},
		methods: {
			init() {
				this.currentItem = this.getCurrentItem();
				this.shengyu=this.dataList.length
			},
			radioChange(item) { //单选改变
				if(this.isfinish){
					return
				}
				if(this.currentItem.myanswer==""){
					this.shengyu-=1
					this.$emit('upshengyu');
				}
				this.dataList[this.currentIndex].myanswer = item
				this.currentItem.myanswer=item
				
			},

			lastQuestion() { //上一题
				let newIndex = this.currentIndex - 1;
				this.currentSelectFinish(newIndex);
			},
			nextQuestion() { //下一题
				let newIndex = this.currentIndex + 1;
				this.currentSelectFinish(newIndex);
			},
			currentSelectFinish(newIndex) { //切换题目
				this.currentIndex = newIndex;
				this.currentItem = this.getCurrentItem();
			},
			finish() { //全部选择完成
				if(this.isfinish){
					this.$emit('finish',this.fenshu);
					return
				}
				for (var i=0; i < this.dataList.length; i++) {
					if (this.dataList[i].myanswer == this.dataList[i].answer) {
						this.fenshu += 10
					}
				}

				this.isfinish = true
				this.$emit('finish',this.fenshu);
			},
			getCurrentItem() { //获取当前项
				var _item = {};
				if (this.dataList.length == 0)
					_item = {};
				if (this.dataList[this.currentIndex])
					_item = { ...this.dataList[this.currentIndex]
					};
				return _item;
			}
		}
	}
</script>

<style>
	page {
		font-size: 28rpx;
	}

	.exam-item-testing {
		margin: 20rpx 10rpx 20rpx 10rpx;
		border-radius: 10rpx;
		background-color: #fff;
	}

	.exam-item-inner {
		padding: 0 20rpx;
	}

	.exam-item-title {
		font-size: 35rpx;
		padding: 10rpx 0;
	}

	.exam-item-option {
		font-size: 30rpx;
		padding: 10rpx 0;
	}

	.exam-item-option textarea {
		border: 1px solid gainsboro;
		border-radius: 10rpx;
		height: 200rpx;
		width: 100%;
	}

	.exam-button-row {
		text-align: center;
	}

	.exam-indexbox {
		padding-bottom: 20rpx;
	}

	.exam-indexbox:before,
	.exam-indexbox:after {
		display: table;
		content: ' ';
	}

	.exam-indexbox:after {
		clear: both;
	}

	.exam-indexbox-item {
		text-align: center;
		vertical-align: middle;
		line-height: 56rpx;
		float: left;
		border: 1rpx solid gainsboro;
		height: 56rpx;
		width: 56rpx;
		margin: 5rpx;
		padding: 10rpx;
		border-radius: 10rpx;
		background-color: #fff;
		-moz-box-shadow: 0px 1px 1px #ABABAB;
		-webkit-box-shadow: 0px 1px 1px #ABABAB;
		box-shadow: 0px 1px 1px #ABABAB;
	}

	.exam-indexbox-item-selected {
		color: #007AFF;
	}

	/* 以下为实现0.5px底部边界 */
	.line_under {
		position: relative;
		/* .line_under:before{顶部top: 0;background: #000;} */
	}

	.line_under:before,
	.line_under:after {
		position: absolute;
		content: " ";
		height: 1px;
		width: 100%;
		left: 0;
		transform-origin: 0 0;
		-webkit-transform-origin: 0 0;
	}

	.line_under:after {
		bottom: 0;
		border-bottom: 1px solid gainsboro;
	}

	@media only screen and (-webkit-min-device-pixel-ratio: 1.5) {

		.line_under:after,
		.line_under:before {
			-webkit-transform: scaleY(0.667);
		}
	}

	@media only screen and (-webkit-min-device-pixel-ratio: 2) {

		.line_under:after,
		.line_under:before {
			-webkit-transform: scaleY(0.5);
		}
	}

	.exam-mask {
		position: absolute;
		z-index: 1;
		width: 100%;
		height: 100%;
		background-color: #999999;
		opacity: 0.5;
		left: 0;
		top: 0;
	}

	.exam-mask-content {
		position: absolute;
		z-index: 1;
		width: 100%;
		height: 50%;
		background-color: white;
		left: 0;
		bottom: 0;
		padding: 15rpx 5rpx;

	}

	.exam-indexbox-item-mask {
		text-align: center;
		vertical-align: middle;
		line-height: 63rpx;
		float: left;
		border: 1rpx solid gainsboro;
		height: 63rpx;
		width: 63rpx;
		margin: 5rpx;
		padding: 10rpx;
		border-radius: 10rpx;
		background-color: #fff;
		-moz-box-shadow: 0px 1px 1px #ABABAB;
		-webkit-box-shadow: 0px 1px 1px #ABABAB;
		box-shadow: 0px 1px 1px #ABABAB;
	}
</style>

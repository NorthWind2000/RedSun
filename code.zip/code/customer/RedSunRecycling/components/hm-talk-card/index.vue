<template>
  <view class="hm-talk-card">
    <view :style="{'background-color':curcolor}" class="head">
      <view class="state">
        <view class="imghead">
          <image class="avator" :src="options.avatar" />
		  <view>
			  <text class="name">{{ options.nickname }}</text><br/>
			  <text style="font-size: 25rpx;color: #FFFFFF;">{{options.pubtime}}</text>
		  </view>
        </view>
      </view>
      <view class="main">
        <text class="text">{{ options.content }}</text>
      </view>
	  <view style="text-align: center; margin-top:10rpx; width: 720.78rpx;height: 300rpx;">
		  <image style="height: 300rpx;" mode="heightFix" :src="'http://www.360zcc.top/'+options.image"></image>
	  </view>
      <view class="body">
        <view class="block">
		  <image class="iconTest" src="../../static/hm-talk-card/images/img_25252_0_0.png" />
          <text class="num">{{ options.likenum }}</text>
          <text class="like">喜欢</text>
        </view>
        <view class="group">
          <image class="iconTest" src="../../static/hm-talk-card/images/img_25252_0_1.png" />
          <text class="commentNum">{{ options.commentnum }}</text>
          <text class="comments">条评论</text>
        </view>
      </view>
    </view>
  </view>
</template>
<script>
export default {
  name: 'HmTalkCard',
  props: {
    options: {
      type: Object,
      }
    },
  data() {
    return {
		colorlist:['#fa5a5a;','#f0d264;','#82c8a0;','#7fccde;','#6698cb;','#cb99c5;','#5351fb;'],
		curcolor:''
	};
  },
  beforeMount() {
	var index=Math.floor(Math.random()*7);  
  	this.curcolor=this.colorlist[index]
  },
  methods: {
  }
};
</script>
<style>
@import './index.response.css';
</style>

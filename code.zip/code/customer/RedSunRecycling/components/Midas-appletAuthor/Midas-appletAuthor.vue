<template>
	<view style="position:relative">
		<slot></slot>
		<button class="authorBtn" open-type="getUserInfo" @getuserinfo="ckSession" v-show="isBind == 1" />
		<button class="authorBtn" open-type="getPhoneNumber" @getphonenumber="getPhoneNumber" v-show="isBind == 2" />
	</view>
</template>

<script>
export default {
	data() {
		return {
			isBind: 0,
			userInfo: {}
		};
	},
	mounted() {
		const that = this;
		that.wxLogin();
		const userInfo = that.$u.userInfo;
		if (!userInfo) {
			that.isBind = 1;
		} else if (userInfo && !userInfo.mobile) {
			uni.checkSession({
				success() {
					that.isBind = 2;
				},
				fail() {
					that.isBind = 1;
				}
			});
		}
		that.userInfo = userInfo;
	},
	methods: {
		wxLogin(fn) {
			uni.login({
				success: res => {
					this.code = res.code;
					if (fn) fn();
				},
				fail() {
					uni.showModal({
						title: '获取失败',
						content: '未获取到您的信息',
						confirmText: '去设置',
						success: function(res) {
							if (res.confirm) {
								uni.openSetting();
							}
						}
					});
				}
			});
		},
		ckSession(e) {
			const that = this;
			uni.checkSession({
				success: () => {
					that.bindGetUserInfo(e);
				},
				fail() {
					that.wxLogin(that.bindGetUserInfo(e));
				}
			});
		},
		getPhoneNumber(e) {
			//绑定手机号
			if (e.detail.errMsg == 'getPhoneNumber:ok') {
				this.isBind = 0;
				const { encryptedData, iv } = e.detail;
				if (this.$u.userInfo.mobile) {
					this.bindPhone();
				} else {
					this.$ajax(
						{
							url: '/app/wxuser/decryptPro',
							data: {
								encryptedData,
								iv,
								openId: this.$u.userInfo.openid
							}
						},
						({ data }) => {
							this.$u.userInfo.mobile = data.purePhoneNumber;
							this.$u.userInfo = Object.assign(this.$u.userInfo, data.userInfo || {});
							uni.setStorageSync('userInfo', this.$u.userInfo);
							this.bindPhone();
						}
					);
				}
			} else {
				uni.showModal({
					title: '提示',
					content: '您点击了拒绝授权，将无法获取手机号',
					showCancel: false,
					confirmText: '关闭'
				});
			}
		},
		bindPhone() {
			let { mobile, openid, avatarUrl, nickName } = uni.getStorageSync('userInfo');
			this.$ajax(
				{
					url: '/app/wxuser/wxMobile',
					data: {
						mobile,
						openid,
						validCode: '0000'
					}
				},
				res => {
					this.$emit('authorSuccess');
					const { data } = res;
					let userInfo = Object.assign(this.$u.userInfo || {}, data);
					this.$u.userInfo = userInfo;
					uni.setStorageSync('userInfo', userInfo);
				}
			);
		},
		bindGetUserInfo(e) {
			//绑定微信
			if (e.detail.errMsg == 'getUserInfo:ok') {
				const { encryptedData, iv } = e.detail;
				this.$ajax(
					{
						url: '/app/wxuser/wxLogin',
						data: {
							code: this.code,
							encryptedData,
							iv
						}
					},
					({ data }) => {
						const { isBind } = data;
						this.isBind = isBind ? 0 : 2;
						let userInfo = Object.assign(this.$u.userInfo || {}, Object.assign(data || {}));
						this.$u.userInfo = userInfo;
						this.$util.showToast('授权成功');
						uni.setStorageSync('userInfo', userInfo);
						this.$emit('authorSuccess');
					}
				);
			}
		}
	}
};
</script>

<style>
.authorBtn {
	opacity: 0;
	position: absolute;
	width: 100% !important;
	height: 100%;
	top: 0;
	left: 0;
	right: 0;
	z-index: 999;
}
</style>

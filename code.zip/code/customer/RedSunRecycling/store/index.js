import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		nickName: "",
		avatarUrl: "",
		addressinfo: {},
		goodsinfo: {},
		curoperation: "",
		zixundata: {},
		dongtaidata:{},
		myzhuti:"#82c8a0;",
		shangpin:{},
		oncebuy:0,
		jiesuan:[],
		gouwuche:[],
		dingdandata:{}
	},
	mutations: {
		setDingdan(state,v){
			state.dingdandata=v
		},
		setGouwuche(state,v){
			state.gouwuche=v
		},
		setOncebuy(state,v){
			state.oncebuy=v
		},
		removeGouwuche(state,v){
			state.gouwuche.splice(v,1); 
		},
		clearGouwuche(state){
			state.gouwuche=[]
		},
		addGowuche(state,v){
			state.gouwuche.push(v)
		},
		clearJiesuan(state){
			state.jiesuan=[]
		},
		setJiesuan(state, v){
			state.jiesuan.push(v)
		},
		setShangpin(state, v){
			state.shangpin = v
		},
		setDongtai(state, v){
			state.dongtaidata = v
		},
		setZhuti(state, v){
			state.myzhuti = v
		},
		setNickName(state, v) {
			state.nickName = v
		},
		setAvatarUrl(state, v) {
			state.avatarUrl = v
		},
		setZixun(state, v) {
			state.zixundata = v
		},
		setLogin(state, v) {
			state.islogin = v
		},
		setAccount(state, v) {
			state.account = v;
		},
		setAddressinfo(state, v) {
			state.addressinfo = v;
		},
		setGoodsinfo(state, v) {
			state.goodsinfo = v
		},
		setCuroperation(state, v) {
			state.curoperation = v
		},
		setGoodsAmount(state, v) {
			state.shoppingcar[v.index].amount = v.amount
		}
	},
	getters: {
		getDingdan(state){
			return state.dingdandata
		},
		getOncebuy(state){
			return state.oncebuy
		},
		getGouwuche(state){
			return state.gouwuche
		},
		getJiesuan(state){
			return state.jiesuan
		},
		getShangpin(state, v){
			return state.shangpin
		},
		getDongtai(state) {
			return state.dongtaidata
		},
		getZhuti(state){
			return state.myzhuti
		},
		getNickName(state) {
			return state.nickName
		},
		getAvatarUrl(state) {
			return state.avatarUrl
		},
		getZixun(state) {
			return state.zixundata
		},
		getLogin(state) {
			return state.islogin
		},
		getAccount(state) {
			return state.user.account
		},
		getName(state) {
			return state.user.name
		},
		getAddressinfo(state) {
			return state.addressinfo
		},
		getGoodsinfo(state) {
			return state.goodsinfo
		},
		getCuroperation(state) {
			return state.curoperation
		}
	}
})

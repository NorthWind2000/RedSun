<template>
	<view>
		<view class="one">
			<view @click="gosearch">点击进入垃圾查询</view>
			<image src="../../static/image/sousuo.png"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			gosearch(){
				uni.navigateTo({
				    url: '/pages/search/search'
				  })
			}
		}
	}
</script>

<style lang="scss">
	page{
		width: 100%;
		height: 100%;
	}
	.one{
		border-radius: 30rpx;
		background-color: #F0F0F0;
		display: flex;
		flex-direction: row;
		width: 100%;
		height: 80rpx;
		view{
			margin-left: 30rpx;
			line-height: 80rpx;
			font-size: 30rpx;
			width: 85%;
			height:80rpx;
			text-align: left;
		}
		image{
			margin-top: 25rpx;
			width: 30rpx;
			height: 30rpx;
		}
	}
</style>


<template>
	<view>
		<view class="one">
			<input v-model="searchkey" placeholder="请输入垃圾名称" @confirm="searching" confirm-type="search"></input>
			<view @click="searching">
				<image src="../../static/image/sousuo.png"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				searchkey: ""
			}
		},
		methods: {
			searching() {
				if (this.searchkey != "") {
					this.$emit("search")
					this.myRequest({
						method: "GET",
						url: "/hwgs/lajichaxun/" + this.searchkey
					}).then((response) => {
						var res = response.data;
						if (res.code == "200") {
							this.$emit("getResult",res.data)
						}
					});
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		width: 100%;
		height: 100%;
	}

	.one {
		border-radius: 30rpx;
		background-color: #F0F0F0;
		display: flex;
		flex-direction: row;
		width: 100%;
		height: 80rpx;

		view {
			padding-top: 20rpx;
			padding-left: 15rpx;
			width: 60rpx;
			height: 60rpx;
		}

		input {
			margin-left: 30rpx;
			line-height: 80rpx;
			font-size: 30rpx;
			width: 85%;
			height: 80rpx;
			text-align: left;
		}

		image {
			width: 30rpx;
			height: 30rpx;
		}
	}
</style>

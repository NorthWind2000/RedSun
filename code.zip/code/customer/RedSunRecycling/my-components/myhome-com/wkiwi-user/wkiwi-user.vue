<template>
	<view
		class="cu-list menu card-menu margin-top-xl margin-bottom-xl shadow-shop bg-white text-black my-radius sm-border">

			<view class="list">
				<view class="li " @click="changeSkin">
					<view class="icon">
						<image src="../../../static/user/skin.png"></image>
					</view>
					<view class="text">主题切换</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
				<view class="li " @click="godizhi">
					<view class="icon">
						<image src="../../../static/user/dizhi.png"></image>
					</view>
					<view class="text">完善地址</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
				<view class="li" @click="godingdan">
					<view class="icon">
						<image src="../../../static/user/dingdan.png"></image>
					</view>
					<view class="text">我的订单</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
				<view class="li" @click="gogouwuche">
					<view class="icon">
						<image src="../../../static/image/gouwuche.png"></image>
					</view>
					<view class="text">购物车</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
				<view class="li " @click="gojifen">
					<view class="icon">
						<image src="../../../static/jifen.png"></image>
					</view>
					<view class="text">我的积分</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
				<view class="li " @click="gowe">
					<view class="icon">
						<image src="../../../static/image/we.png"></image>
					</view>
					<view class="text">关于我们</view>
					<image class="to" src="../../../static/user/to.png"></image>
				</view>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
			};
		},
		methods: {
			changeSkin() {
				uni.navigateTo({
					url: "/pages/skinchange/skinchange"
				});
			},
			godizhi() {
				uni.navigateTo({
					url: "/pages/dizhi/index"
				})
			},
			goshangcheng() {
				uni.navigateTo({
					url: "/pages/shangcheng/index"
				})
			},
			gojifen() {
				uni.navigateTo({
					url: "/pages/jifen/index"
				})
			},
			godingdan() {
				uni.navigateTo({
					url: "/pages/dingdan/index"
				})
			},
			gogouwuche(){
				uni.navigateTo({
					url: '/pages/gouwuche/index'
				})
			},
			gowe(){
				uni.navigateTo({
					url:"/pages/we/we"
				})
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #f1f1f1;
		font-size: 30upx;
	}

	.list {
		width: 100%;
		border-bottom: 15upx solid #f1f1f1;
		background: #fff;

		&:last-child {
			border: none;
		}

		.li {
			width: 92%;
			height: 100upx;
			padding: 0 4%;
			border-bottom: 1px solid rgb(243, 243, 243);
			display: flex;
			align-items: center;

			&.noborder {
				border-bottom: 0
			}

			.icon {
				flex-shrink: 0;
				width: 50upx;
				height: 50upx;

				image {
					width: 50upx;
					height: 50upx;
				}
			}

			.text {
				padding-left: 20upx;
				width: 100%;
				color: #666;
			}

			.to {
				flex-shrink: 0;
				width: 40upx;
				height: 40upx;
			}
		}
	}
</style>

<template>
	<div id="colWords">
		{{words}}
	</div>
</template>

<script>
	
	export default {
		name: 'colWords',
		props: {
			'words':String
		},
		data() {
			return {
				
			};
		},
		methods:{
			
		},
		components:{

		}
	}
</script>

<style scoped>
	#colWords {
		width: 20px;
		margin: 0 auto;  
		line-height: 24px;  
		font-size: 20px;
		height: 265px;
	}
</style>

<template>
	<div class="container" id="login">
		<div class="login_warp">
			<div class="loginbox fl">
				<div class="login_header">
					<span>账号登录</span>
				</div>
				<div class="login_content">
					<div>
						<div class="form_item"><input type="text" name="name" placeholder="用户名"></div>
						<div class="form_item"><input type="password" name="password" placeholder="密码"></div>
						<div class="form_item">
							<input type="submit" @click="ulogin" name="" value="登录">
						</div>
					</div>
				</div>
			</div>
			<div class="loginrslider fl">
				<colWords words="垃圾分类小助手后台管理"></colWords>
			</div>
		</div>
	</div>
</template>

<script>
	import colWords from "./col-words.vue"
	
	export default {
		name: 'login',
		props: {
			msg: String
		},
		data() {
			return {
				islogin:false
			};
		},
		methods:{
			ulogin(){
				this.$emit("loginsuccess")
			}
		},
		components:{
			colWords
		}
	}
</script>

<style>
	@import url("../../static/css/main.css");
</style>

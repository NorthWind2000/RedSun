<template>
	<div id="mainPage">
		<el-container>
			<el-container>
				<el-aside width="200px">
					<h4>RedSun控制台</h4>
					<el-menu background-color="#545c64" text-color="#fff" active-text-color="#ffd04b" @select="select">
						<el-submenu index="1">
							<template slot="title">
								<i class="el-icon-user"></i>
								<span slot="title">用户</span>
							</template>
							<div class="twoclass">
								<el-menu-item index="1-1" style="font-size: 10px;">普通用户</el-menu-item>
								<el-menu-item index="1-2" style="font-size: 10px;">管理员</el-menu-item>
							</div>
						</el-submenu>
						<el-menu-item index="2">
							<template slot="title">
								<i class="el-icon-info"></i>
								<span slot="title">垃圾</span>
							</template>
						</el-menu-item>
						<el-menu-item index="3">
							<template slot="title">
								<i class="el-icon-s-shop"></i>
								<span slot="title">商品</span>
							</template>
						</el-menu-item>
						<el-menu-item index="4">
							<template slot="title">
								<i class="el-icon-files"></i>
								<span slot="title">题库</span>
							</template>
						</el-menu-item>
						<el-menu-item index="5">
							<template slot="title">
								<i class="el-icon-s-promotion"></i>
								<span slot="title">资讯</span>
							</template>
						</el-menu-item>
					</el-menu>
				</el-aside>
				<el-main>
					<userPage v-show="index=='1-1'"></userPage>
					<adminPage v-show="index=='1-2'"></adminPage>
					<ljPage v-show="index=='2'"></ljPage>
					<addTanchuang v-show="index=='3'"></addTanchuang>
				</el-main>
			</el-container>
		</el-container>
	</div>
</template>

<script>
	import userPage from "./userPage.vue"
	import adminPage from "./adminPage.vue"
	import ljPage from "./ljPage.vue"
	import addTanchuang from "./addTanchuang.vue"
	
	export default {
		name: 'mainPage',
		props: {},
		data() {
			return {
				index: "1-1"
			};
		},
		methods: {
			select(e) {
				this.index = e
			}
		},
		components: {
			userPage,
			adminPage,
			ljPage,
			addTanchuang
		}
	}
</script>

<style>
	.el-aside {
		margin-left: 30px;
		background-color: #545c64;
		color: #FFFFFF;
		text-align: center;
		height: 700px;
	}

	.el-main {
		margin-left: 20px;
		margin-right: 30px;
		background-color: #E9EEF3;
		color: #333;
		text-align: center;
	}

	.el-menu-vertical-demo:not(.el-menu--collapse) {
		width: 200px;
		min-height: 400px;
	}
</style>

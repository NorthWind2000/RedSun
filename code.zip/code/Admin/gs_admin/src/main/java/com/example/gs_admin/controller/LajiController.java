package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.server.LajiService;
import com.example.gs_admin.utils.ResponseUtils;
import com.example.gs_admin.utils.UsePython;
//import com.sun.org.apache.bcel.internal.generic.RETURN;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
public class LajiController {

    @Autowired
    LajiService lajiService;

    @GetMapping("/laji/allcount")
    @CrossOrigin
    public JSONObject getLajiAllcount(){
        return ResponseUtils.success(lajiService.selectAllcount());
    }

    @GetMapping("/laji/{page}")
    @CrossOrigin
    public JSONObject getLajiByPage(@PathVariable(name="page") int page) {
        return ResponseUtils.success(lajiService.getLajiByPage(page));
    }

    @GetMapping("/laji/search/{searchkeys}")
    @CrossOrigin
    public JSONObject search(@PathVariable(name="searchkeys") String searchkeys){
        List<LJ> ljList = lajiService.selectLJByKeyWord(searchkeys);
        return ResponseUtils.success(ljList);
    }

    @PostMapping("/laji")
    @CrossOrigin
    public JSONObject addLaJI(@RequestBody LJ lj){
        lajiService.addLJ(lj);
        return ResponseUtils.success(null);
    }

    @PostMapping("/lajis/{count}")
    @CrossOrigin
    public JSONObject upLJ(@RequestParam(name = "file") MultipartFile file, @PathVariable(name="count") String count){
        String extentionname="xlsx";
        String filename= UUID.randomUUID()+"."+extentionname;
//        String path="/home/lj/excel/"+filename;
        String path="C:\\Users\\ZCC\\Desktop\\"+filename;
        File file1= new File(path);
        FileOutputStream fileOutputStream= null;
        try {
            fileOutputStream = new FileOutputStream(file1);
            fileOutputStream.write(file.getBytes());
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        UsePython.exePython("C:\\Users\\ZCC\\Desktop\\ToLaJi.py",path,count);
        return ResponseUtils.success(null);
    }
}

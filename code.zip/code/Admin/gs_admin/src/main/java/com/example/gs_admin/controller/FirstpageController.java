package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.ShouyeLunbo;
import com.example.gs_admin.bean.ZiXun;
import com.example.gs_admin.mapper.ZixunMapper;
import com.example.gs_admin.server.FirstpageService;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class FirstpageController {
    @Autowired
    FirstpageService firstpageService;
    @Autowired
    ZixunMapper zixunMapper;


    @GetMapping("/firstpage/lunbo")
    @CrossOrigin
    public JSONObject getAllLunbo() {
        return ResponseUtils.success(firstpageService.getAllLunbo());
    }

    @GetMapping("/firstpage/lunbo/{zxid}")
    @CrossOrigin
    public void addLunboPic(@PathVariable(name="zxid") String zxid){
        ZiXun ziXun =zixunMapper.selectZixunById(zxid);
        ShouyeLunbo shouyeLunbo=new ShouyeLunbo();
        shouyeLunbo.setZxid(zxid);
        shouyeLunbo.setTitle(ziXun.getTitle());
        shouyeLunbo.setImage(ziXun.getImage());
        firstpageService.addLunboPic(shouyeLunbo);
    }

    @DeleteMapping("/firstpage/lunbo/{zxid}")
    @CrossOrigin
    public void deleteLunboPic(@PathVariable(name="zxid") String zxid){
        firstpageService.deleteLunboPic(zxid);
    }
}

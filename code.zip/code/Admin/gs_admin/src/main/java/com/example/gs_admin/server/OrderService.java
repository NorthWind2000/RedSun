package com.example.gs_admin.server;

import com.example.gs_admin.bean.Order;
import com.example.gs_admin.bean.OrderDetail;
import com.example.gs_admin.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    OrderMapper orderMapper;

    public int selectAllcount(int status){
        return orderMapper.selectAllcount(status);
    }

    public Order selectOrder(String oid, int status){
        return orderMapper.selectOrder(oid,status);
    }

    public List<Order> getOrderByPage(int status,int page){
        int startindex=(page-1)*7;
        return orderMapper.selectOrderByIndex(status,startindex);
    }

    public void finishOrder(String oid){
        orderMapper.finishOrder(oid);
    }

    public OrderDetail[] getOrderdetail(String oid){
        return orderMapper.selectOrderdetail(oid);
    }

}

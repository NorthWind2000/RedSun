package com.example.gs_admin.bean;

import lombok.Data;
import org.apache.solr.client.solrj.beans.Field;

@Data
public class LJ {
    private int id;
    private String name;
    private String type;
}
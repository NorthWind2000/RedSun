package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class HuiShouYuan {

    private String id;
    private String account;
    private String password;
    private String phone;
    private String xiaoquid;
    private String realname;
    private String xiaoquname;
}

package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class Admin {
    private String account;
    private String name;
    private String password;
    private int isSuper;
}

package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.bean.ShiTi;
import com.example.gs_admin.server.TikuService;
import com.example.gs_admin.utils.ResponseUtils;
import com.example.gs_admin.utils.UsePython;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@RestController
public class TikuController {

    @Autowired
    TikuService tikuService;

    @GetMapping("/tiku/allcount")
    @CrossOrigin
    public JSONObject getShitiAllcount(){
        return ResponseUtils.success(tikuService.selectAllcount());
    }

    @GetMapping("/tiku/{page}")
    @CrossOrigin
    public JSONObject getShitiByPage(@PathVariable(name="page") int page) {
        return ResponseUtils.success(tikuService.getShitiByPage(page));
    }

    @PostMapping("/tiku")
    @CrossOrigin
    public JSONObject addShiti(@RequestBody ShiTi shiti){
        try{
            tikuService.addShiti(shiti);
            return ResponseUtils.success(null);
        }catch (Exception e){
            return ResponseUtils.fail(null);
        }
    }

    @PutMapping("/tiku/{id}")
    @CrossOrigin
    public JSONObject alterShiTiByID(@PathVariable(name="id") int id, @RequestBody Map<String,String> shiti) {
        tikuService.upateShiti(id,shiti.get("question"),shiti.get("a"),shiti.get("b"),shiti.get("c"),shiti.get("d"),shiti.get("answer"),shiti.get("jiexi"));
        return ResponseUtils.success(null);
    }

    @DeleteMapping("/tiku/{id}")
    @CrossOrigin
    public JSONObject deleteLaji(@PathVariable(name="id") int id) {
        try{
            tikuService.deleteShiti(id);
            return ResponseUtils.success(null);
        }catch (Exception e){
            return ResponseUtils.fail(null);
        }
    }

    @PostMapping("/tikus/{count}")
    @CrossOrigin
    public void upTK(@RequestParam(name = "file") MultipartFile file, @PathVariable(name="count") String count){
        String extentionname="xlsx";
        String filename= UUID.randomUUID()+"."+extentionname;
        String path="/home/lj/excel/"+filename;
        File file1= new File(path);
        FileOutputStream fileOutputStream= null;
        try {
            fileOutputStream = new FileOutputStream(file1);
            fileOutputStream.write(file.getBytes());
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        UsePython.exePython("/home/lj/python/ToTiKu.py",path,count);
    }
}

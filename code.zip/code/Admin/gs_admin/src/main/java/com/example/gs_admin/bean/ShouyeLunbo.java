package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class ShouyeLunbo {

    private String zxid;
    private String image;
    private String title;
}

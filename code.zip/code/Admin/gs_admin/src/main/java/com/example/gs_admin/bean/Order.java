package com.example.gs_admin.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class Order {
    private String oid;
    private String openid;
    private String realname;
    private String phone;
    private String address;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date credate;
    private int jifen;
    private int status;
}

package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.Xiaoqu;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface YuyueMapper {

    @Select("select * from huishou limit #{startindex},8")
    public List<Huishou> selectHuishouByPage(int startindex);

    @Select("select count(*) from huishou")
    public int getAllcount();

    @Update("update huishou set status=status+1 where id=#{id}")
    public void xiaYiBu(String id);
}

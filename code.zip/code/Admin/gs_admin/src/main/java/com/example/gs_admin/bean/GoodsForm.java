package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class GoodsForm {

    private String gid;
    private String gname;
    private int status;
    private String image;
    private String note;
    private int jifen;
}

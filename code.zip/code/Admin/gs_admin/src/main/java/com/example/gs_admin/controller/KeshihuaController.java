package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.server.KeshihuaService;
import com.example.gs_admin.utils.DataUtil;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;

@RestController
public class KeshihuaController {
    @Autowired
    KeshihuaService keshihuaService;

    @GetMapping("/keshihua/{xqid}/{pictype}")
    @CrossOrigin
    public JSONObject getPic(@PathVariable(name="xqid") String xqid,@PathVariable(name="pictype") int pictype){
        Object pic=keshihuaService.getPic(xqid,pictype+"");
        if(pic==null){
            JSONObject resdata=keshihuaService.getPicByXiaoqu(xqid,pictype);
            if(resdata==null){
                return ResponseUtils.fail(null);
            }else{
                return ResponseUtils.success(resdata);
            }
        }else{
            String resultdata=pic.toString();
            String[] data=resultdata.split("&");
            if(!data[2].equals(DataUtil.getHour())){
                return ResponseUtils.success(keshihuaService.getPicByXiaoqu(xqid,pictype));
            }else{
                HashMap<String,String> resdata=new HashMap<>();
                resdata.put("picc",data[0]);
                resdata.put("jss",data[1]);
                return ResponseUtils.success(resdata);
            }
        }

    }
}

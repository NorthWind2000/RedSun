package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.Xiaoqu;
import com.example.gs_admin.bean.ZiXun;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ZixunMapper {

    @Insert("insert into zixun(id,title,image,content,status,publishtime) values(#{id},#{title},#{image},#{content},#{status},#{publishtime})")
    public void addZixun(ZiXun ziXun);

    @Select("select title,image from zixun where id=#{zxid} ")
    public ZiXun selectZixunById(String zxid);

    @Select("select count(*) from zixun where status=#{status}")
    public int selectAllcount(int status);

    @Select("select id,title,status,publishtime from zixun where status=#{status} limit #{startindex},8")
    public List<ZiXun> selectZixunByPage(int startindex, int status);

    @Update("update zixun set status=0 where id=#{id}")
    public void xiajia(String id);

    @Update("update zixun set status=1 where id=#{id}")
    public void fabu(String id);

}

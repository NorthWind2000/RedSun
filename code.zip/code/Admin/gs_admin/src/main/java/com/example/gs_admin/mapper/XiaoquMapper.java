package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.Xiaoqu;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface XiaoquMapper {

    @Select("select count(*) from xiaoqu")
    public int selectAllcount();

    @Select("select * from xiaoqu limit #{startindex},8")
    public List<Xiaoqu> selectXiaoquByIndex(int startindex);

    @Update("update xiaoqu set name=#{name},province=#{province},city=#{city},county=#{county},detailaddress=#{detailaddress} where id=#{id}")
    public void updateXiaoqu(Xiaoqu xiaoqu);

    @Delete("delete from xiaoqu where id=#{id}")
    public void deleteXiaoqu(String id);

    @Insert("insert into xiaoqu(id,name,province,city,county,detailaddress) values(#{id},#{name},#{province},#{city},#{county},#{detailaddress})")
    public void addXiaoqu(Xiaoqu xiaoqu);

    @Select("select count(*) from xiaoqu where name like concat('%',#{keyword},'%')")
    public int selectKeyAllcount();

    @Select("select * from xiaoqu where name like concat('%',#{keyword},'%') limit #{startindex},8")
    public List<Xiaoqu> selectXiao(String keyword,int startindex);

    @Select("select id,name from xiaoqu")
    public List<Xiaoqu> selectXiaoqu();
}

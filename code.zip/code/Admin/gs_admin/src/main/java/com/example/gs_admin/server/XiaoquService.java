package com.example.gs_admin.server;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.Xiaoqu;
import com.example.gs_admin.mapper.XiaoquMapper;
import com.example.gs_admin.utils.DataUtil;
import com.example.gs_admin.utils.UserInfoGetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@Service
public class XiaoquService {

    @Autowired
    XiaoquMapper xiaoquMapper;

    public int selectAllcount(){
        return xiaoquMapper.selectAllcount();
    }

    public int selectKeyAllcount(){
        return xiaoquMapper.selectKeyAllcount();
    }

    public void addXiaoqu(Xiaoqu xiaoqu){
        xiaoquMapper.addXiaoqu(xiaoqu);
//        addXiaoquToLYL(xiaoqu.getId());
    }

//    @Async
//    public void addXiaoquToLYL(String id){
//        String url = "http://127.0.0.1:1235/addxiaoqu?xqindex="+id;
//        RestTemplate client = new RestTemplate();
//        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
//        URI uri = builder.build().encode().toUri();
//        client.getForObject(uri,String.class);
//    }

    public List<Xiaoqu> getXiaoByPage(int page){
        int startindex=(page-1)*8;
        return xiaoquMapper.selectXiaoquByIndex(startindex);
    }

    public List<Xiaoqu> getXiao(){
        return xiaoquMapper.selectXiaoqu();
    }

    public void deleteXiaoqu(String id){
        xiaoquMapper.deleteXiaoqu(id);
    }

    public List<Xiaoqu> selectXiaoquByKeyWord(String keywords,int page){
        int startindex=(page-1)*8;
        return xiaoquMapper.selectXiao(keywords,startindex);
    }

    public void updateXiaoqu(Xiaoqu xiaoqu){
        xiaoquMapper.updateXiaoqu(xiaoqu);
    }


}

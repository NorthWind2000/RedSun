package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.*;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AdminMapper {

    @Insert("insert into admin(account,password,isSuper) values(#{account},#{password},#{isSuper})")
    public void insertAdmin(Admin admin);

    @Select("select * from admin where account=#{account}")
    public Admin getAdminByAccount(String account);

    @Select("select * from admin")
    public List<Admin> getAdmin();

    @Select("select count(*) from user where xqid=#{xqid}")
    public int selectUserCountByXiaoqu(String xqid);

    @Select("select * from user where xqid=#{xqid} limit #{startindex},8")
    public List<User> selectUserByXiaoquAndIndex(String xqid,int startindex);

}

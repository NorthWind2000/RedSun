package com.example.gs_admin.server;

import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.bean.ShiTi;
import com.example.gs_admin.mapper.TikuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TikuService {

    @Autowired
    TikuMapper tikuMapper;

    public int selectAllcount(){
        return tikuMapper.selectAllcount();
    }

    public List<ShiTi>  getShitiByPage(int page){
        int startindex=(page-1)*8;
        return tikuMapper.selectShitiByIndex(startindex);
    }

    public void addShiti(ShiTi shiti){
        tikuMapper.addShiti(shiti);
    }

    public void upateShiti(int id, String question, String a,String b,String c,String d,String answer,String jiexi){
        tikuMapper.updateShiti(id,question,a,b,c,d,answer,jiexi);
    }

    public void deleteShiti(int id){
        tikuMapper.deleteShiti(id);
    }

}

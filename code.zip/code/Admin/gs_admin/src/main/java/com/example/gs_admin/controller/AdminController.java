package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.*;
import com.example.gs_admin.server.AdminService;
import com.example.gs_admin.server.FileServier;
import com.example.gs_admin.utils.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class AdminController {

    @Autowired
    AdminService adminService;
    @Autowired
    FileServier fileServier;

    @GetMapping("/admin/login")
    @CrossOrigin
    public JSONObject login(@RequestParam(name="account") String account, @RequestParam(name="password") String password){
        Admin admin=adminService.getAdminByAccount(account);
        if(admin!=null&&admin.getPassword().equals(password)){
            return ResponseUtils.success("token");
        }else{
            return ResponseUtils.fail(null);
        }
    }

    @PostMapping("/update")
    @CrossOrigin
    public void logi1n(@RequestBody Map<String,Object> jsonObject){
        System.out.println(jsonObject);

    }

    @GetMapping("/admin/all")
    @CrossOrigin
    public JSONObject getAllAdmin(){
        return ResponseUtils.success(adminService.getAdmin());
    }

    @GetMapping("/user/count/{xqid}")
    @CrossOrigin
    public JSONObject getUserCountByXiaoqu(@PathVariable(name="xqid") String xqid){
        return ResponseUtils.success(adminService.getUserCountByXiaoqu(xqid));
    }

    @GetMapping("/user/{index}/{xqid}")
    @CrossOrigin
    public JSONObject getUserInfo(@PathVariable(name="index") int index,@PathVariable(name="xqid") String xqid){
        return ResponseUtils.success(adminService.getUserByXiaoquAndIndex(xqid,index));
    }
}

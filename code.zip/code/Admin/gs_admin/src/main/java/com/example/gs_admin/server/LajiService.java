package com.example.gs_admin.server;

import com.example.gs_admin.bean.GoodsForm;
import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.mapper.LajiMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LajiService {

    @Autowired
    LajiMapper lajiMapper;

    public List<LJ> selectLJByKeyWord(String keywords){
        return lajiMapper.searchLJ(keywords);
    }

    public int selectAllcount(){
        return lajiMapper.selectAllcount();
    }

    public List<LJ> getLajiByPage(int page){
        int startindex=(page-1)*8;
        return lajiMapper.selectLajiByIndex(startindex);
    }

    public void addLJ(LJ lj){
        lajiMapper.addLJ(lj);
    }
}

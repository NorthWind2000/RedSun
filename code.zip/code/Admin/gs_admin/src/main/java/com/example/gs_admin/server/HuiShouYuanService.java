package com.example.gs_admin.server;

import com.example.gs_admin.bean.HuiShouYuan;
import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.Order;
import com.example.gs_admin.bean.OrderDetail;
import com.example.gs_admin.mapper.HuiShouYuanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HuiShouYuanService {

    @Autowired
    HuiShouYuanMapper huiShouYuanMapper;

    public HuiShouYuan findHuiShouYuanByAccount(String account){
        return huiShouYuanMapper.selectHuiShouYuanByAccount(account);
    }

    public void addHuiShouYuan(String xqid,HuiShouYuan huiShouYuan){
        huiShouYuanMapper.insertHuiShouYuan(huiShouYuan);
        huiShouYuanMapper.alterXiaoquhsyid(xqid,huiShouYuan.getId());
    }

    public void alterHuishouyuan(HuiShouYuan huiShouYuan){
        huiShouYuanMapper.alterHuishouyuanByid(huiShouYuan);
    }

    public HuiShouYuan getHuiShouYuan(String id){
        return huiShouYuanMapper.selectHuiShouYuanById(id);
    }

    public List<Order> getOrderList(String xqid,int status){
        return huiShouYuanMapper.selectOrserByXqidAndStatus(xqid,status);
    }

    public OrderDetail[] getOrderXQ(String oid){
        return huiShouYuanMapper.selectOrderdetail(oid);
    }

    public List<Huishou> getYuyueList(String xqid, int status){
        if(status==3){
            return huiShouYuanMapper.selectUnfinishYuyueByXqid(xqid);
        }else{
            return huiShouYuanMapper.selectFinishYuyueByXqid(xqid);
        }
    }
}

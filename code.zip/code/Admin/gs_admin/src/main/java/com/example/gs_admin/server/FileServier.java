package com.example.gs_admin.server;

import org.csource.common.NameValuePair;
import org.csource.fastdfs.*;
import org.springframework.stereotype.Service;

@Service
public class FileServier {

    //上传文件
    public String testUpload(String filepath, String filename, String extentionname){

        try {
            //加载fastDFS客户端配置文件
//             ClientGlobal.initByProperties("/home/lj/fastdfs-client.properties");
            ClientGlobal.initByProperties("E:\\works\\projects\\RedSun\\Admin\\gs_admin\\src\\main\\resources\\static\\fastdfs-client.properties");
            //创建一个tracker客户端
            TrackerClient tracker = new TrackerClient();
            TrackerServer trackerServer = tracker.getConnection();

            StorageServer storageServer = null;
            //定义一个storage客户端
            StorageClient1 client = new StorageClient1(trackerServer, storageServer);
            //文件元信息
            NameValuePair[] metaList = new NameValuePair[1];
            metaList[0] = new NameValuePair("fileName", filename);
            //执行上传,将客户端上传到web服务器上的文件，上传到fastDFS
            String fileId = client.upload_file1(filepath,extentionname, metaList) ;
            if (null != trackerServer) {
                trackerServer.close();
            }
            return fileId;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    //上传文件
    public String testUpload(byte[] file_buff, String filename, String extentionname){
        try {
            //加载fastDFS客户端配置文件
//            ClientGlobal.initByProperties("/home/hwgs/fastdfs-client.properties");
            ClientGlobal.initByProperties("E:\\works\\projects\\RedSun\\Admin\\gs_admin\\src\\main\\resources\\static\\fastdfs-client.properties");

            //创建一个tracker客户端
            TrackerClient tracker = new TrackerClient();
            TrackerServer trackerServer = tracker.getConnection();

            StorageServer storageServer = null;
            //定义一个storage客户端
            StorageClient1 client = new StorageClient1(trackerServer, storageServer);
            //文件元信息
            NameValuePair[] metaList = new NameValuePair[1];
            metaList[0] = new NameValuePair("fileName", filename);
            //执行上传,将客户端上传到web服务器上的文件，上传到fastDFS
            String fileId = client.upload_file1(file_buff,extentionname, metaList) ;
            if (null != trackerServer) {
                trackerServer.close();
            }
            return fileId;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}

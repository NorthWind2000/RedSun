package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.ShiTi;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface TikuMapper {

    @Select("select count(*) from zhishiwenda")
    public int selectAllcount();

    @Select("select * from zhishiwenda limit #{startindex},8")
    public List<ShiTi> selectShitiByIndex(int startindex);

    @Insert("insert into zhishiwenda(Question,A,B,C,D,Answer,jiexi) values(#{question},#{A},#{B},#{C},#{D},#{answer},#{jiexi})")
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "ID")
    public void addShiti(ShiTi shiti);

    @Update("update zhishiwenda set Question=#{question},A=#{a},B=#{b},C=#{c},D=#{d},Answer=#{answer},jiexi=#{jiexi} where id=#{id}")
    public void updateShiti(int id, String question, String a,String b,String c,String d,String answer,String jiexi);

    @Delete("delete from zhishiwenda where id=#{id}")
    public void deleteShiti(int id);

}

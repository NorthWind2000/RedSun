package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.HuiShouYuan;
import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.Order;
import com.example.gs_admin.bean.OrderDetail;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface HuiShouYuanMapper {
    @Insert("insert into huishouyuan(id,account,password,xiaoquid,phone,realname,xiaoquname) values(#{id},#{account},#{password},#{xiaoquid},#{phone},#{realname},#{xiaoquname})")
    public void insertHuiShouYuan(HuiShouYuan huiShouYuan);

    @Select("select * from huishouyuan where id=#{id}")
    public HuiShouYuan selectHuiShouYuanById(String id);

    @Update("update huishouyuan set account=#{account},password=#{password},phone=#{phone},realname=#{realname}  where id=#{id}")
    public void alterHuishouyuanByid(HuiShouYuan huiShouYuan);

    @Update("update xiaoqu set huishouyuanid=#{id} where id=#{xqid}")
    public void alterXiaoquhsyid(String xqid,String id);

    @Select("select * from huishouyuan where account=#{account}")
    public HuiShouYuan selectHuiShouYuanByAccount(String account);

    @Select("select * from orders where xiaoquid=#{xqid} and status=#{status}")
    public List<Order> selectOrserByXqidAndStatus(String xqid,int status);

    @Select("select * from orderdetail where oid=#{oid}")
    public OrderDetail[] selectOrderdetail(String oid);

    @Select("select * from huishou where xiaoquid=#{xqid} and status<>5")
    public List<Huishou> selectUnfinishYuyueByXqid(String xqid);

    @Select("select * from huishou where xiaoquid=#{xqid} and status=5")
    public List<Huishou> selectFinishYuyueByXqid(String xqid);
}

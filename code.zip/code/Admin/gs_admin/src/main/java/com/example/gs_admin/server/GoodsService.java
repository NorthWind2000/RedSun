package com.example.gs_admin.server;

import com.example.gs_admin.bean.GoodsForm;
import com.example.gs_admin.mapper.GoodsMapper;
import com.example.gs_admin.utils.ID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class GoodsService {
    @Autowired
    GoodsMapper goodsMapper;

    @Autowired
    FileServier fileServier;

    public int selectAllcount(int status){
        return goodsMapper.selectAllcount(status);
    }

    public List<GoodsForm> getGoodsByPage(int status, int page){
        int startindex=(page-1)*7;
        return goodsMapper.selectGoodByIndex(status,startindex);
    }

    public void upateGoods(String gid, String gname, int jifen){
        goodsMapper.updateGoods(gid,gname,jifen);
        GoodsForm goods = goodsMapper.selectGoodsByGid(gid);
//        solrService.updateGoods(goods);
    }

    public void xiajiaGoods(String gid){
        goodsMapper.xiajiaGoods(gid);
        GoodsForm goods = goodsMapper.selectGoodsByGid(gid);
        goods.setStatus(0);
//        solrService.updateGoods(goods);
    }

    public void shangjiaGoods(String gid){
        goodsMapper.shangjiaGoods(gid);
        GoodsForm goods = goodsMapper.selectGoodsByGid(gid);
        goods.setStatus(1);
//        solrService.updateGoods(goods);
    }

    public void addGoods(GoodsForm goodsForm){
        goodsMapper.insertGoods(goodsForm);
//        solrService.updateGoods(goodsForm);
    }

    public void addLunboPic(String gid, ArrayList<String> pic){
        for(String p : pic){
            goodsMapper.insertLunboPic(ID.getId(),gid,p);
        }
    }

    public void addXuanchuanPic(String gid,ArrayList<String> pic){
        for(String p : pic){
            goodsMapper.insertXuanchuanPic(ID.getId(),gid,p);
        }
    }

    public ArrayList<String> saveImg(List<MultipartFile> files) {
        try {
            // 判断文件数组是否为空
            if (files == null || files.size() < 1) {
                return null;
            } else {
//                String path = "C:\\Users\\ZCC\\Desktop";
                ArrayList<String> paths=new ArrayList<>();
                // 遍历图片文件
                for (int i = 0; i < files.size(); i++) {
                    MultipartFile file = files.get(i);
                    //String image = uploadFile(file,path);
                    // 将图片文件保存到服务器，同时返回上传后图片的名字
                    String name = file.getOriginalFilename();
                    String extentionname = name.substring(name.lastIndexOf(".")+1);
                    String filename= UUID.randomUUID()+extentionname;
                    paths.add(fileServier.testUpload(file.getBytes(),filename,extentionname));
                }
                return paths;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String uploadFile(MultipartFile file, String path) throws IOException {
        String name = file.getOriginalFilename();
        String suffixName = name.substring(name.lastIndexOf("."));
        // 生成图片id
        String imgid = ID.getId();
        String fileName = imgid + suffixName;
        File tempFile = new File(path,fileName);

        tempFile.createNewFile();
        file.transferTo(tempFile);
        return tempFile.getName();
    }
}

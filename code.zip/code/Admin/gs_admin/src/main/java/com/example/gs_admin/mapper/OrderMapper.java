package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.Order;
import com.example.gs_admin.bean.OrderDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface OrderMapper {
    @Select("select * from orders where oid=#{oid} and status=#{status}")
    public Order selectOrder(String oid, int status);

    @Select("select count(*) from orders where status=#{status}")
    public int selectAllcount(int status);

    @Select("select * from orders where status=#{status} limit #{startindex},7")
    public List<Order> selectOrderByIndex(int status, int startindex);

    @Update("update orders set status=2 where oid=#{oid}")
    public void finishOrder(String oid);

    @Select("select * from orderdetail where oid=#{oid}")
    public OrderDetail[] selectOrderdetail(String oid);
}

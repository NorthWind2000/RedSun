package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.server.YuyueService;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class YuyueController {

    @Autowired
    YuyueService yuyueService;

    @GetMapping("/yuyue/allcount")
    @CrossOrigin
    public JSONObject getHuishouAllcount(){
        return ResponseUtils.success(yuyueService.selectAllcount());
    }

    @GetMapping("/yuyue/{page}")
    @CrossOrigin
    public JSONObject getZixunByPage(@PathVariable(name="page") int page) {
        return ResponseUtils.success(yuyueService.getHuishouByPage(page));
    }

    @PutMapping("/yuyue/{id}")
    @CrossOrigin
    public void xiaYiBu(@PathVariable(name="id") String id) {
        yuyueService.xiaYiBu(id);
    }

    @GetMapping("/yuyue/update/{id}")
    @CrossOrigin
    public JSONObject update(@PathVariable(name="id") String id) {
        yuyueService.xiaYiBu(id);
        return ResponseUtils.success(null);
    }
}

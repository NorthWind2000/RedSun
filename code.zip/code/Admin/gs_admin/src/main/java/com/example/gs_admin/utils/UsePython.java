package com.example.gs_admin.utils;

public class UsePython {

    public static void exePython(String pythonPath,String excelPath,String sum) {
//        String[] args = new String[]{"/usr/local/python3/bin/python3.6",pythonPath,excelPath,sum};
        String[] args = new String[]{"python",pythonPath,excelPath,sum};
        Runtime rn = Runtime.getRuntime();
        Process p = null;
        try {
            p = rn.exec(args);
            p.waitFor();
        } catch (Exception e) {
            System.out.println("Error exec!");
        }
    }
}

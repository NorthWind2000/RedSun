package com.example.gs_admin.server;

import com.example.gs_admin.bean.Huishou;
import com.example.gs_admin.bean.ZiXun;
import com.example.gs_admin.mapper.YuyueMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class YuyueService {

    @Autowired
    YuyueMapper yuyueMapper;

    public int selectAllcount(){
        return yuyueMapper.getAllcount();
    }

    public List<Huishou> getHuishouByPage(int page){
        int startindex=(page-1)*8;
        return yuyueMapper.selectHuishouByPage(startindex);
    }

    public void xiaYiBu(String id){
        yuyueMapper.xiaYiBu(id);
    }

}

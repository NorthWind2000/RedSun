package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.ShouyeLunbo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface FirstpageMapper {

    @Select("select * from shouyelunbo")
    public ShouyeLunbo[] selectAllLunbo();

    @Insert("insert into shouyelunbo(zxid,image,title) values(#{zxid},#{image},#{title})")
    public void insertLunboPic(ShouyeLunbo firstpageLunbo);

    @Delete("delete from shouyelunbo where zxid=#{zxid}")
    public void deleteLunboPic(String zxid);

}

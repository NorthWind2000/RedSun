package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class Huishou {
    private String id;
    private String openid;
    private String phone;
    private String time;
    private String dizhi;
    private String type;
    private String realname;
    private int status;
    private String xiaoquid;
}

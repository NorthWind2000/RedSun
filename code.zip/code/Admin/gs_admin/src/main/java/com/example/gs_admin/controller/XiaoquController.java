package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.bean.Xiaoqu;
import com.example.gs_admin.server.XiaoquService;
import com.example.gs_admin.utils.ID;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class XiaoquController {

    @Autowired
    XiaoquService xiaoquService;

    @PostMapping("/xiaoqu")
    @CrossOrigin
    public JSONObject addLaJI(@RequestBody Xiaoqu xiaoqu){
        xiaoqu.setId(ID.getId());
        xiaoquService.addXiaoqu(xiaoqu);
        return ResponseUtils.success(null);
    }

    @GetMapping("/xiaoqu/allcount")
    @CrossOrigin
    public JSONObject getXiaoquAllcount(){
        return ResponseUtils.success(xiaoquService.selectAllcount());
    }

    @GetMapping("/xiaoqu/{page}")
    @CrossOrigin
    public JSONObject getXiaoquByPage(@PathVariable(name="page") int page) {
        return ResponseUtils.success(xiaoquService.getXiaoByPage(page));
    }

    @GetMapping("/xiaoqu")
    @CrossOrigin
    public JSONObject getXiaoqu() {
        return ResponseUtils.success(xiaoquService.getXiao());
    }

    @DeleteMapping("/xiaoqu/{page}")
    @CrossOrigin
    public void deleteXiaoqu(@PathVariable(name="page") String id){
        xiaoquService.deleteXiaoqu(id);
    }

    @GetMapping("/xiaoqu/search/allcount")
    @CrossOrigin
    public JSONObject getSearchAllcount(){
        return ResponseUtils.success(xiaoquService.selectKeyAllcount());
    }

    @GetMapping("/xiaoqu/search/{searchkey}/{page}")
    @CrossOrigin
    public JSONObject search(@PathVariable(name="searchkey") String searchkey,@PathVariable(name="page") int page){
        List<Xiaoqu> xiaoquList = xiaoquService.selectXiaoquByKeyWord(searchkey,page);
        return ResponseUtils.success(xiaoquList);
    }

    @PutMapping("/xiaoqu")
    @CrossOrigin
    public void alterXiaoqu(@RequestBody Xiaoqu xiaoqu) {
        xiaoquService.updateXiaoqu(xiaoqu);
    }
}

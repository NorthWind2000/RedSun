package com.example.gs_admin.server;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.*;
import com.example.gs_admin.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {

    @Autowired
    AdminMapper adminMapper;

    public Admin getAdminByAccount(String account){
        return adminMapper.getAdminByAccount(account);
    }

    public int getUserCountByXiaoqu(String xiaoqu){
        return adminMapper.selectUserCountByXiaoqu(xiaoqu);
    }

    public List<User> getUserByXiaoquAndIndex(String xiaoqu,int index){
        int startindex=(index-1)*8;
        return adminMapper.selectUserByXiaoquAndIndex(xiaoqu,startindex);
    }

    public List<Admin> getAdmin(){
        return adminMapper.getAdmin();
    }


}

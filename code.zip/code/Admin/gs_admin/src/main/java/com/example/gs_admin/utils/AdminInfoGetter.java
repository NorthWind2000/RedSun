package com.example.gs_admin.utils;

import java.util.HashMap;

public class AdminInfoGetter {

    private static String Account=null;
    private static String Token=null;

    public static void setInfo(String account,String token){
        Account=account;
        Token=token;
    }

    public static void resetInfo(){
        Account=null;
        Token=null;
    }
    public static HashMap<String,String> getInfo(){
        HashMap<String,String> usermap=new HashMap<String,String>();
        usermap.put("account",Account);
        usermap.put("token",Token);
        return usermap;
    }
    public static String getAccount(){
        return Account;
    }
}

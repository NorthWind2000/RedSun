package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.server.OrderService;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {
    @Autowired
    OrderService orderService;

    @GetMapping("/order/allcount/{status}")
    @CrossOrigin
    public JSONObject getOrderAllcount(@PathVariable(name="status") int status){
        return ResponseUtils.success(orderService.selectAllcount(status));
    }

    @GetMapping("/order/{status}/{page}")
    @CrossOrigin
    public JSONObject getOrderByPage(@PathVariable(name="status") int status, @PathVariable(name="page") int page) {
        return ResponseUtils.success(orderService.getOrderByPage(status,page));
    }

    @GetMapping("/order/finish/{oid}")
    @CrossOrigin
    public JSONObject finishOrder(@PathVariable(name="oid") String oid) {
        orderService.finishOrder(oid);
        return ResponseUtils.success(null);
    }

    @GetMapping("/orderdetail/{oid}")
    @CrossOrigin
    public JSONObject getOrderdetail(@PathVariable(name="oid") String oid) {
        return ResponseUtils.success(orderService.getOrderdetail(oid));
    }

    @GetMapping("/order/search/{status}/{oid}")
    @CrossOrigin
    public JSONObject searchOrder(@PathVariable(name="oid") String oid, @PathVariable(name="status") int status) {
        return ResponseUtils.success(orderService.selectOrder(oid,status));
    }
}

package com.example.gs_admin.server;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.utils.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Service
public class KeshihuaService {
    @Autowired
    private RedisTemplate redisTemplate;

    public JSONObject getPicByXiaoqu(String xqid,int pictype){
        String url = "http://47.117.66.221:8009/getpic?xqindex="+xqid;
        RestTemplate client = new RestTemplate();
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        URI uri = builder.build().encode().toUri();
        JSONObject resdata=client.getForObject(uri,JSONObject.class);
        for(int i=0;i<resdata.size();i++){
            addPic(xqid,i+1+"",resdata.getJSONObject(i+"").get("picc").toString(),resdata.getJSONObject(i+"").get("jss").toString(), DataUtil.getHour());
        }
        return resdata.getJSONObject(pictype-1+"");
    }

    public void addPic(String xqid,String pictype,String picc,String jss,String hour){
        ValueOperations valueOperations =redisTemplate.opsForValue();
        valueOperations.set(xqid+pictype,picc+"&"+jss+"&"+hour);
    }

    public Object getPic(String xqid,String pictype){
        ValueOperations valueOperations =redisTemplate.opsForValue();
        return valueOperations.get(xqid+pictype);
    }
}

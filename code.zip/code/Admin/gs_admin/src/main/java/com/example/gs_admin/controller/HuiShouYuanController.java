package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.HuiShouYuan;
import com.example.gs_admin.server.HuiShouYuanService;
import com.example.gs_admin.utils.ID;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class HuiShouYuanController {

    @Autowired
    HuiShouYuanService huiShouYuanService;

    //登录
    @CrossOrigin
    @GetMapping("/huishouyuan/login/{account}/{password}")
    public JSONObject login(@PathVariable(name="account") String account,@PathVariable(name="password") String password){
        HuiShouYuan huiShouYuan =huiShouYuanService.findHuiShouYuanByAccount(account);
        if(huiShouYuan==null){
            JSONObject response = new JSONObject();
            response.put("err","账号不存在！");
            return ResponseUtils.fail(response);
        }else{
            if(huiShouYuan.getPassword().equals(password)){
                return ResponseUtils.success(huiShouYuan);
            }
            else{
                JSONObject response = new JSONObject();
                response.put("err","密码错误！");
                return ResponseUtils.fail(response);
            }
        }
    }

    @PostMapping("/huishouyuan/{xqid}/{xqname}")
    @CrossOrigin
    public void addHuishouyuan(@RequestBody HuiShouYuan huiShouYuan,@PathVariable(name="xqid") String xqid,@PathVariable(name="xqname") String xqname){
        huiShouYuan.setId(ID.getId());
        huiShouYuan.setXiaoquid(xqid);
        huiShouYuan.setXiaoquname(xqname);
        huiShouYuanService.addHuiShouYuan(xqid,huiShouYuan);
    }

    @PutMapping("/huishouyuan")
    @CrossOrigin
    public void alterHuishouyuan(@RequestBody HuiShouYuan huiShouYuan){
        huiShouYuanService.alterHuishouyuan(huiShouYuan);
    }

    @GetMapping("/huishouyuan/{id}")
    @CrossOrigin
    public JSONObject getHuishouyuanByID(@PathVariable(name="id") String id) {
        HuiShouYuan huiShouYuan=huiShouYuanService.getHuiShouYuan(id);
        return ResponseUtils.success(huiShouYuan);
    }

    @GetMapping("/huishouyuan/order/{xqid}/{status}")
    @CrossOrigin
    public JSONObject getOrders(@PathVariable(name="xqid") String xqid,@PathVariable(name="status") int status) {
        return ResponseUtils.success(huiShouYuanService.getOrderList(xqid,status));
    }

    @GetMapping("/huishouyuan/orderxq/{oid}")
    @CrossOrigin
    public JSONObject getOrders(@PathVariable(name="oid") String oid) {
        return ResponseUtils.success(huiShouYuanService.getOrderXQ(oid));
    }

    @GetMapping("/huishouyuan/yuyue/{xqid}/{status}")
    @CrossOrigin
    public JSONObject getYuyues(@PathVariable(name="xqid") String xqid,@PathVariable(name="status") int status) {
        return ResponseUtils.success(huiShouYuanService.getYuyueList(xqid,status));
    }
}

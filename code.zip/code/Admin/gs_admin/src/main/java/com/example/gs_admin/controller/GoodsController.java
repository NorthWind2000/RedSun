package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.GoodsForm;
import com.example.gs_admin.server.GoodsService;
import com.example.gs_admin.utils.ID;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
public class GoodsController {

    @Autowired
    GoodsService goodsService;

    @PostMapping("/goods")
    @CrossOrigin
    public JSONObject addGoods(HttpServletRequest request) {
        GoodsForm goods=new GoodsForm();
        MultipartHttpServletRequest params=((MultipartHttpServletRequest) request);
        List<MultipartFile> lunbopic = params.getFiles("lunbopic");
        List<MultipartFile> xuanchuanpic = params.getFiles("xuanchuanpic");
        JSONObject j= JSON.parseObject(params.getParameter("goodsform"));
        goods.setGid(ID.getId());
        goods.setGname(j.getString("gname"));
        goods.setNote(j.getString("note"));
        goods.setJifen(Integer.parseInt(j.getString("jifen")));
        goods.setStatus(1);
        ArrayList<String> lunbopicpaths=goodsService.saveImg(lunbopic);
        ArrayList<String> xuanchuanpicpaths=goodsService.saveImg(xuanchuanpic);
        if (lunbopicpaths!=null && xuanchuanpicpaths!=null){
            goods.setImage(lunbopicpaths.get(0));
            goodsService.addGoods(goods);
            goodsService.addLunboPic(goods.getGid(),lunbopicpaths);
            goodsService.addXuanchuanPic(goods.getGid(),xuanchuanpicpaths);
            return ResponseUtils.success(null);
        }else{
            return ResponseUtils.fail(null);
        }
    }

    @GetMapping("/goods/allcount/{status}")
    @CrossOrigin
    public JSONObject getGoodsAllcount(@PathVariable(name="status") int status){
        return ResponseUtils.success(goodsService.selectAllcount(status));
    }

    @GetMapping("/goods/{status}/{page}")
    @CrossOrigin
    public JSONObject getGoodsByPage(@PathVariable(name="status") int status, @PathVariable(name="page") int page) {
        return ResponseUtils.success(goodsService.getGoodsByPage(status,page));
    }
    @PutMapping("/goods/{gid}")
    @CrossOrigin
    public JSONObject alterGoodsByID(@PathVariable(name="gid") String gid, @RequestBody Map<String,String> goods) {
        goodsService.upateGoods(gid,goods.get("name"),Integer.parseInt(goods.get("jifen")));
        return ResponseUtils.success(null);
    }

    @GetMapping("/goods/xiajia/{gid}")
    @CrossOrigin
    public JSONObject xiajiaGoods(@PathVariable(name="gid") String gid) {
        goodsService.xiajiaGoods(gid);
        return ResponseUtils.success(null);
    }
    @GetMapping("/goods/shangjia/{gid}")
    @CrossOrigin
    public JSONObject shangjiaGoods(@PathVariable(name="gid") String gid) {
        goodsService.shangjiaGoods(gid);
        return ResponseUtils.success(null);
    }
}

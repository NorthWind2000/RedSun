package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.LJ;
import com.example.gs_admin.bean.OrderDetail;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface LajiMapper {

    @Select("select count(*) from lajiinfo")
    public int selectAllcount();

    @Select("select * from lajiinfo limit #{startindex},8")
    public List<LJ> selectLajiByIndex(int startindex);

    @Insert("insert into lajiinfo(name,type) values(#{name},#{type})")
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "id")
    public void addLJ(LJ lj);

    @Select("select * from lajiinfo where name like concat('%',#{keyword},'%')")
    public List<LJ> searchLJ(String keyword);
}

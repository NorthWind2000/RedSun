package com.example.gs_admin.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.gs_admin.bean.ZiXun;
import com.example.gs_admin.server.ZixunService;
import com.example.gs_admin.utils.ID;
import com.example.gs_admin.utils.ResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@RestController
public class ZixunController {

    @Autowired
    ZixunService zixunService;

    @PostMapping("/zixun")
    @CrossOrigin
    public JSONObject addZixun(HttpServletRequest request) {
        ZiXun ziXun=new ZiXun();
        MultipartHttpServletRequest params=((MultipartHttpServletRequest) request);
        MultipartFile fengmianimg = params.getFile("fengmian");
        JSONObject j= JSON.parseObject(params.getParameter("zixun"));
        ziXun.setId(ID.getId());
        ziXun.setTitle(j.getString("title"));
        ziXun.setContent(j.getString("content"));
        ziXun.setPublishtime(new Date());
        ziXun.setStatus(1);
        System.out.println(ziXun.getContent());
        String fengmianpath=zixunService.saveImg(fengmianimg);
        if (fengmianpath!=null){
            ziXun.setImage(fengmianpath);
            zixunService.saveZixun(ziXun);
            return ResponseUtils.success(fengmianpath);
        }else{
            return ResponseUtils.fail(null);
        }
    }

    @PostMapping("/zixun/uploadimage")
    @CrossOrigin
    public JSONObject updateImage(MultipartFile file){
        String path=zixunService.saveImg(file);
        if (path!=null){
            JSONObject data=new JSONObject();

            data.put("url","http://124.70.69.175/"+path);
            return ResponseUtils.success(data);
        }else{
            return ResponseUtils.fail(null);
        }
    }

    @GetMapping("/zixun/{status}/allcount")
    @CrossOrigin
    public JSONObject getXiaoquAllcount(@PathVariable(name="status") int status){
        return ResponseUtils.success(zixunService.selectAllcount(status));
    }

    @GetMapping("/zixun/{status}/{page}")
    @CrossOrigin
    public JSONObject getZixunByPage(@PathVariable(name="status") int status,@PathVariable(name="page") int page) {
        return ResponseUtils.success(zixunService.getZixunByPage(status,page));
    }

    @GetMapping("/zixun/xiajia/{id}")
    @CrossOrigin
    public void xiajia(@PathVariable(name="id") String id) {
        zixunService.xiajia(id);
    }

    @GetMapping("/zixun/fabu/{id}")
    @CrossOrigin
    public void fabu(@PathVariable(name="id") String id) {
        zixunService.fabu(id);
    }



}

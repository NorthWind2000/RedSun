package com.example.gs_admin.server;

import com.example.gs_admin.bean.ShouyeLunbo;
import com.example.gs_admin.mapper.FirstpageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class FirstpageService {
    @Autowired
    FirstpageMapper firstpageMapper;
    @Autowired
    FileServier fileServier;

    public ShouyeLunbo[] getAllLunbo(){

        return firstpageMapper.selectAllLunbo();
    }

    public void addLunboPic(ShouyeLunbo firstpageLunbo){
        firstpageMapper.insertLunboPic(firstpageLunbo);
    }
    public void deleteLunboPic(String zxid){
        firstpageMapper.deleteLunboPic(zxid);
    }

}

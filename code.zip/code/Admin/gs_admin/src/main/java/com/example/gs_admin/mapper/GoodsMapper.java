package com.example.gs_admin.mapper;

import com.example.gs_admin.bean.GoodsForm;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.Date;
import java.util.List;

@Mapper
public interface GoodsMapper {
    @Insert("insert into goods(gid,gname,jifen,note,image,status) values(#{gid},#{gname},#{jifen},#{note},#{image},#{status})")
    public void insertGoods(GoodsForm goodsForm);

    @Insert("insert into goodslunbo(lunboid,gid,image) values(#{lunboid},#{gid},#{image})")
    public void insertLunboPic(String lunboid, String gid, String image);
    @Insert("insert into goodsxuanchuan(xuanchuanid,gid,image) values(#{xuanchuanid},#{gid},#{image})")
    public void insertXuanchuanPic(String xuanchuanid, String gid, String image);

    @Select("select count(*) from goods where status=#{status}")
    public int selectAllcount(int status);

    @Select("select * from goods where gid=#{gid}")
    public GoodsForm selectGoodsByGid(String gid);

    @Select("select * from goods where status=#{status} limit #{startindex},7")
    public List<GoodsForm> selectGoodByIndex(int status, int startindex);

    @Update("update goods set gname=#{gname},jifen=#{jifen} where gid=#{gid}")
    public void updateGoods(String gid, String gname, int jifen);

    @Update("update goods set status=0 where gid=#{gid}")
    public void xiajiaGoods(String gid);

    @Update("update goods set status=1 where gid=#{gid}")
    public void shangjiaGoods(String gid);
}

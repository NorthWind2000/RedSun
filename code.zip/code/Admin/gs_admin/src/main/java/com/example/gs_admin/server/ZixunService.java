package com.example.gs_admin.server;

import com.example.gs_admin.bean.ZiXun;
import com.example.gs_admin.mapper.ZixunMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class ZixunService {

    @Autowired
    FileServier fileServier;
    @Autowired
    ZixunMapper zixunMapper;

    public void xiajia(String id){
        zixunMapper.xiajia(id);
    }

    public void fabu(String id){
        zixunMapper.fabu(id);
    }

    public void saveZixun(ZiXun ziXun){
        zixunMapper.addZixun(ziXun);
    }

    public int selectAllcount(int status){
        return zixunMapper.selectAllcount(status);
    }

    public List<ZiXun> getZixunByPage(int status,int page){
        int startindex=(page-1)*8;
        return zixunMapper.selectZixunByPage(startindex,status);
    }

    public String saveImg(MultipartFile file) {
        // 判断文件数组是否为空
        if (file == null) {
            System.out.println("null");
            return null;
        } else {
//              String path = "C:\\Users\\ZCC\\Desktop";
            // 将图片文件保存到服务器，同时返回上传后图片的名字
            String name = file.getOriginalFilename();
            String extentionname = name.substring(name.lastIndexOf(".") + 1);
            String filename = UUID.randomUUID() + extentionname;
            try {
                return fileServier.testUpload(file.getBytes(),filename,extentionname);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }

}

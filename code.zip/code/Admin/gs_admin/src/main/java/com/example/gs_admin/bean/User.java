package com.example.gs_admin.bean;

import lombok.Data;

@Data
public class User {
    private String openid;
    private String realname;
    private int jifen;
    private String phone;
    private String province;
    private String city;
    private String county;
    private String detailaddress;
    private String xiaoqu;
    private String address;

}

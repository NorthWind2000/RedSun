package com.example.gs_admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}

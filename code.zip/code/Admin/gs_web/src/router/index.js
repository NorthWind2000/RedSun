import Vue from 'vue'
import VueRouter from 'vue-router'

import Layout from '@/layout' //布局页



Vue.use(VueRouter)

// 通用页面, 这里的配置不需要权限
export const constRouter = [{
    path: '/login',
    component: () => import('@/views/login/Login'),
    hidden: true //导航菜单忽略选项
  },
  {
    path: '',
    component: Layout, //应用布局页
    redirect: '/index',
    hidden: true,
  },
  {
    path: '/index',
    component: Layout, //应用布局页
    name: 'index',
    meta: {
      title: "首页", //导航菜单项标题
      icon: 'el-icon-s-home' //导航菜单图标
    },
    children: [{
      path: '',
      component: () => import('@/views/index/index.vue'),
      name: 'indexs',
      meta: {
        title: "工作台",
        icon: 'el-icon-s-home',
        roles: ['admin', 'jerry']
      }
    }]
  }
]

// 动态路由 communication
export const asyncRoutes = [{
    path: '/goods',
    component: Layout,
    redirect: '/goods/index',
    meta: {
      title: "商品管理",
      icon: 'el-icon-s-goods',
      hidden: false,
    },
    children: [{
        path: 'index',
        component: () => import('@/views/goods/Index.vue'),
        name: 'goodsindex',
        meta: {
          title: "在售产品",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'onindex',
        component: () => import('@/views/goods/OnIndex.vue'),
        name: 'onindex',
        meta: {
          title: "上架产品",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'offindex',
        component: () => import('@/views/goods/OffIndex.vue'),
        name: 'offindex',
        meta: {
          title: "已下架产品",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      }
    ]
  },
  {
    path: '/control',
    component: Layout,
    children: [{
        path: 'carousel',
        component: () => import('@/views/control/Carousel.vue'),
        name: 'carousel',
        meta: {
          title: "首页轮播图",
          icon: 'el-icon-message',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      }
    ]
  },
  {
    path: '/dingdan',
    component: Layout,
    redirect: '/dingdan/area',
    meta: {
      title: "订单管理",
      icon: 'el-icon-s-order',
      hidden: false,
    },
    children: [{
        path: 'daifahuo',
        component: () => import('@/views/dingdan/daifahuo.vue'),
        name: 'daifahuo',
        meta: {
          title: "待领取",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'yifahuo',
        component: () => import('@/views/dingdan/yifahuo.vue'),
        name: 'yifahuo',
        meta: {
          title: "已领取",
          icon: 'el-icon-tickets',
          hidden: false,
        }
      }
    ]
  },
  {
    path: '/laji',
    component: Layout,
    redirect: '/laji/index',
    meta: {
      title: "垃圾信息管理",
      icon: 'el-icon-s-platform',
      hidden: false,
    },
    children: [{
        path: 'index',
        component: () => import('@/views/laji/index.vue'),
        name: 'alllaji',
        meta: {
          title: "全部信息",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'update',
        component: () => import('@/views/laji/update.vue'),
        name: 'updatelaji',
        meta: {
          title: "信息更新",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
    ]
  },
  {
    path: '/tiku',
    component: Layout,
    redirect: '/tiku/index',
    meta: {
      title: "题库管理",
      icon: 'el-icon-s-help',
      hidden: false,
    },
    children: [{
        path: 'index',
        component: () => import('@/views/tiku/index.vue'),
        name: 'index',
        meta: {
          title: "全部试题",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'update',
        component: () => import('@/views/tiku/update.vue'),
        name: 'update',
        meta: {
          title: "新增试题",
          icon: 'el-icon-tickets',
          hidden: false,
        }
      }
    ]
  },
  {
    path: '/zixun',
    component: Layout,
    redirect: '/zixun/index',
    meta: {
      title: "资讯管理",
      icon: 'el-icon-s-promotion',
      hidden: false,
    },
    children: [{
        path: 'index',
        component: () => import('@/views/zixun/index.vue'),
        name: 'index',
        meta: {
          title: "在线资讯",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'weifabu',
        component: () => import('@/views/zixun/weifabu.vue'),
        name: 'weifabu',
        meta: {
          title: "下架资讯",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'update',
        component: () => import('@/views/zixun/update.vue'),
        name: 'update',
        meta: {
          title: "新增资讯",
          icon: 'el-icon-tickets',
          hidden: false,
        }
      }
    ]
  },
  {
    path: '/shequ',
    component: Layout,
    redirect: '/shequ/index',
    meta: {
      title: "社区管理",
      icon: 'el-icon-s-home',
      hidden: false,
    },
    children: [{
        path: 'daifahuo',
        component: () => import('@/views/shequ/index.vue'),
        name: 'daifahuo',
        meta: {
          title: "全部社区",
          icon: 'el-icon-tickets',
          hidden: false,
          roles: ['admin', 'jerry']
        }
      },
      {
        path: 'yifahuo',
        component: () => import('@/views/shequ/addshequ.vue'),
        name: 'yifahuo',
        meta: {
          title: "新增社区",
          icon: 'el-icon-tickets',
          hidden: false,
        }
      },
      {
        path: 'dataview',
        component: () => import('@/views/shequ/dataview.vue'),
        name: 'dataview',
        meta: {
          title: "社区数据可视化",
          icon: 'el-icon-tickets',
          hidden: false,
        }
      }
    ]
  },
  {
    path: '/yuyue',
    component: Layout,
    name: 'yuyue',
    children: [{
      path: '',
      component: () => import('@/views/yuyue/index.vue'),
      name: 'yuyue',
      meta: {
        title: "预约管理",
        icon: 'el-icon-date',
        hidden: false,
        roles: ['admin', 'jerry']
      }
    }]
  },
  {
    path: '/user',
    component: Layout,
    name: 'user',
    children: [{
      path: '',
      component: () => import('@/views/user.vue'),
      name: 'users',
      meta: {
        title: "用户管理",
        icon: 'el-icon-user',
        hidden: false,
        roles: ['admin', 'jerry']
      }
    }]
  }
]
const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes: constRouter
})
export default router
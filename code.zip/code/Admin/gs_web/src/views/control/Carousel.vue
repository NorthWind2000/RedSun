<template>
  <div class="Carousel">
    <!-- 添加 -->
    <el-row :gutter="20" class="Carousel-Info">
      <el-col :xs="6" :sm="4" :md="3" :lg="2" :xl="2" :offset="1">
        <el-button
          type="primary"
          class="Carousel-Info-li"
          size="small"
          @click="CarouselShow = true"
          >添加</el-button
        >
      </el-col>
    </el-row>
    <!-- 查询列表 -->
    <el-row class="Carousel-list">
      <el-col :span="24">
        <el-table :data="tableData" border style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="title" label="标题" width="500">
          </el-table-column>
          <el-table-column prop="zxid" label="资讯ID" width="380">
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="deleteRow(scope.$index)"
                type="text"
                size="small"
              >
                移除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 添加或编辑关键词 -->
    <el-dialog title="添加轮播图" :visible.sync="CarouselShow">
      <el-form :model="CarouselForm">
        <el-form-item label="资讯ID" :label-width="CarouselWidth" prop="zxid">
          <el-input
            v-model="CarouselForm.zxid"
            autocomplete="off"
            placeholder="请输入链接的资讯ID"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="CarouselSubmit" type="primary">添 加</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [],
      // 上传
      dialogImageUrl: "",
      dialogVisible: false,
      // 弹出层
      CarouselShow: false,
      CarouselForm: {
        zxid: ""
      },
      CarouselWidth: "120px",
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/firstpage/lunbo",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.tableData = res.data;
      }
    });
  },
  methods: {
    CarouselSubmit() {
      this.myRequest({
        method: "get",
        url: "/firstpage/lunbo/"+this.CarouselForm.zxid,
      });
      this.CarouselShow = false;
    },
    deleteRow(index) {
      this.myRequest({
        method: "delete",
        url: "/firstpage/lunbo/" + this.tableData[index].zxid,
      });
      this.tableData.splice(index, 1);
    }
  },
};
</script>

<style scoped>
.Carousel {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
.Carousel-Info {
  width: 100%;
  margin-bottom: 15px;
}
.Carousel-Info-li {
  width: 100%;
}
.Carousel-list {
  width: 100%;
  margin-bottom: 20px;
}
.Carousel-page-box {
  display: flex;
  justify-content: flex-end;
}
</style>
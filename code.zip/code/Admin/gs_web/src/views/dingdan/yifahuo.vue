<template>
  <div class="goodsindex">
    <!-- 搜索条件 -->
    <el-row :gutter="20" class="goodsindex-queryInfo">
      <!-- 用户搜索 -->
      <el-col :xs="8" :sm="6" :md="6" :lg="4" :xl="4">
        <el-input
          class="goodsindex-queryInfo-li"
          v-model="queryInfo.oid"
          clearable
          size="small"
          placeholder="请输入订单号"
        ></el-input>
      </el-col>
      <el-col :xs="6" :sm="4" :md="3" :lg="2" :xl="2">
        <el-button
          type="primary"
          class="goodsindex-queryInfo-li"
          size="small"
          @click="search"
          >搜索</el-button
        >
      </el-col>
    </el-row>
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="ordersData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="oid" label="订单号" width="240">
          </el-table-column>
          <el-table-column prop="openid" label="买家账号" width="220">
          </el-table-column>
          <el-table-column prop="realname" label="买家姓名" width="80">
          </el-table-column>
          <el-table-column prop="phone" label="电话" width="120">
          </el-table-column>
          <el-table-column prop="address" label="地址" width="250">
          </el-table-column>
          <el-table-column prop="credate" label="下单时间" width="150">
          </el-table-column>
          <el-table-column prop="jifen" label="积分" width="80">
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="lookdetail(scope.$index)"
                type="text"
                size="small"
              >
                查看详情
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="ordertotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
    <el-dialog title="订单详情" :visible.sync="detailShow">
      <el-table :data="orderData" height="250" border style="width: 100%">
        <el-table-column prop="gid" label="商品ID" width="280">
        </el-table-column>
        <el-table-column prop="gname" label="商品名称" width="320">
        </el-table-column>
        <el-table-column prop="jifen" label="价格" width="80"> </el-table-column>
        <el-table-column prop="count" label="数量" width="80"> </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="oneSortSUbmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      orderData: [],
      detailShow: false,
      ordertotal: 0,
      queryInfo: {
        oid: "",
        page: 1,
        pageSize: 7,
      },
      alterGoodsTable: {
        index: 0,
        name: "",
        price: "",
      },
      ordersData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/order/allcount/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.ordertotal = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/order/1/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.ordersData = res.data;
      }
    });
  },
  methods: {
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/order/1/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    oneSortSUbmit(){
      this.detailShow = false;
    },
    search() {
      this.myRequest({
        method: "get",
        url: "/order/search/1/" + this.queryInfo.oid,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.ordersData = [res.data];
        }
      });
    },
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/order/1/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.ordersData = res.data;
        }
      });
    },
    lookdetail(index) {
      this.detailShow = true;
      this.myRequest({
        method: "get",
        url: "/orderdetail/" + this.ordersData[index].oid,
      }).then((response) => {
        this.orderData=response.data.data
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
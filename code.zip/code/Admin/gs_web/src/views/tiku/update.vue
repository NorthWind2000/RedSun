<template>
  <div class="goodsindex">
    <el-divider content-position="left">单个添加</el-divider>
    <el-form :model="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item label="题目">
        <el-input v-model="ruleForm.question"></el-input>
      </el-form-item>
      <el-form-item label="A">
        <el-input v-model="ruleForm.A"></el-input>
      </el-form-item>
      <el-form-item label="B">
        <el-input v-model="ruleForm.B"></el-input>
      </el-form-item>
      <el-form-item label="C">
        <el-input v-model="ruleForm.C"></el-input>
      </el-form-item>
      <el-form-item label="D">
        <el-input v-model="ruleForm.D"></el-input>
      </el-form-item>
      <el-form-item label="答案">
        <el-input v-model="ruleForm.answer"></el-input>
      </el-form-item>
      <el-form-item label="解析">
        <el-input v-model="ruleForm.jiexi"></el-input>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="submitone"
          >添加</el-button
        ></el-form-item
      >
    </el-form>
    <el-divider content-position="left">批次添加</el-divider>
    <el-form :model="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item>
        <input type="file" id="LJExcel" accept=".xls,.xlsx" />
      </el-form-item>
      <el-form-item label="数据条数">
        <el-input v-model="ruleForm.ljname"></el-input>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="submit"
          >添加</el-button
        ></el-form-item
      >
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      ruleForm: {
        question:"",
        A:"",
        B:"",
        C:"",
        D:"",
        answer:"",
        jiexi:"",
        count: 0
      },
    };
  },
  methods: {
    submitone() {
      this.myRequest({
        method: "post",
        url: "/tiku",
        data: {
          question: this.ruleForm.question,
          a: this.ruleForm.A,
          b: this.ruleForm.B,
          c: this.ruleForm.C,
          d: this.ruleForm.D,
          answer: this.ruleForm.answer,
          jiexi: this.ruleForm.jiexi
        },
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
    submit() {
      let LJExcel = document.getElementById("LJExcel").files[0];
      if (LJExcel == null) {
        return;
      }
      let form = new FormData();
      form.append("file", LJExcel, LJExcel.name);

      this.myRequest({
        method: "post",
        url: "/tikus/" + this.ruleForm.count,
        data: form,
        processData: false,
        contentType: "multipart/form-data",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
</style>
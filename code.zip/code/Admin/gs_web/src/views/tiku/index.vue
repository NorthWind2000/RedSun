<template>
  <div class="goodsindex">
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="goodsData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="id" label="ID" width="50">
          </el-table-column>
          <el-table-column prop="question" label="题目" width="400">
          </el-table-column>
          <el-table-column prop="a" label="A" width="100">
          </el-table-column>
          <el-table-column prop="b" label="B" width="100">
          </el-table-column>
          <el-table-column prop="c" label="C" width="100">
          </el-table-column>
          <el-table-column prop="d" label="D" width="100">
          </el-table-column>
          <el-table-column prop="answer" label="答案" width="40">
          </el-table-column>
          <el-table-column prop="jiexi" label="解析" width="200">
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="deleteRow(scope.$index)"
                type="text"
                size="small"
              >
                删除
              </el-button>
              <el-button
                @click.native.prevent="alterGoods(scope.$index)"
                type="text"
                size="small"
              >
                修改
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="total"
        >
        </el-pagination>
      </el-col>
    </el-row>
    <!-- 修改弹窗 -->
    <el-dialog title="修改试题" :visible.sync="alterShow">
      <el-form :model="alterGoodsTable">
        <el-form-item
          label="题目"
          :label-width="formLabelWidth"
          prop="question"
        >
          <el-input
            v-model="alterGoodsTable.question"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="A"
          :label-width="formLabelWidth"
          prop="a"
        >
          <el-input
            v-model="alterGoodsTable.a"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="B"
          :label-width="formLabelWidth"
          prop="b"
        >
          <el-input
            v-model="alterGoodsTable.b"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="C"
          :label-width="formLabelWidth"
          prop="c"
        >
          <el-input
            v-model="alterGoodsTable.c"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="D"
          :label-width="formLabelWidth"
          prop="d"
        >
          <el-input
            v-model="alterGoodsTable.d"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="答案"
          :label-width="formLabelWidth"
          prop="answer"
        >
          <el-input
            v-model="alterGoodsTable.answer"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="解析"
          :label-width="formLabelWidth"
          prop="jiexi"
        >
          <el-input
            v-model="alterGoodsTable.jiexi"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="alterSUbmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      alterShow: false,
      formLabelWidth: "100px",
      total: 0,
      queryInfo: {
        name: "",
        type: "",
        page: 1,
        pageSize: 8,
      },
      alterGoodsTable: {
        index: 0,
        name: "",
        price: "",
      },
      goodsData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/tiku/allcount",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.total = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/tiku/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodsData = res.data;
      }
    });
  },
  methods: {
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/tiku/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    alterGoods(index) {
      console.log(index);
      this.alterGoodsTable.index = index;
      this.alterShow = true;
    },
    alterSUbmit() {
      this.alterShow = false;
      this.myRequest({
        method: "put",
        url: "/tiku/" + this.goodsData[this.alterGoodsTable.index].id,
        data: {
          name: this.alterGoodsTable.question,
          a: this.alterGoodsTable.a,
          b: this.alterGoodsTable.b,
          c: this.alterGoodsTable.c,
          d: this.alterGoodsTable.d,
          answer: this.alterGoodsTable.answer,
          jiexi: this.alterGoodsTable.jiexi,
        },
      })
    },
    deleteRow(index) {
      this.myRequest({
        method: "delete",
        url: "/tiku/" + this.goodsData[index].id,
      }).then((response) => {
                var res = response.data;
        if (res.code == "200") {
        this.goodsData.splice(index, 1);
        }
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
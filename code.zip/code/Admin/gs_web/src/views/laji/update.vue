<template>
  <div class="goodsindex">
    <el-divider content-position="left">单个添加</el-divider>
    <el-form :model="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item label="垃圾名称">
        <el-input v-model="ruleForm.ljname"></el-input>
      </el-form-item>
      <el-form-item label="垃圾类别">
        <el-radio-group v-model="ruleForm.type">
          <el-radio label="厨余(湿)垃圾"></el-radio>
          <el-radio label="其他(干)垃圾"></el-radio>
          <el-radio label="有害垃圾"></el-radio>
          <el-radio label="可回收垃圾"></el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="submitone"
          >添加</el-button
        ></el-form-item
      >
    </el-form>
    <el-divider content-position="left">批次添加</el-divider>
    <el-form :model="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item>
        <input type="file" id="LJExcel" accept=".xls,.xlsx" />
      </el-form-item>
      <el-form-item label="数据条数">
        <el-input v-model="ruleForm.ljname"></el-input>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="submit"
          >添加</el-button
        ></el-form-item
      >
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      ruleForm: {
        ljname: "",
        type: "",
        count: 0,
      },
    };
  },
  methods: {
    submitone() {
      this.myRequest({
        method: "post",
        url: "/laji",
        data: {
          name: this.ruleForm.ljname,
          type: this.ruleForm.type
        },
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
    submit() {
      let LJExcel = document.getElementById("LJExcel").files[0];
      if (LJExcel == null) {
        return;
      }
      let form = new FormData();
      form.append("file", LJExcel, LJExcel.name);

      this.myRequest({
        method: "post",
        url: "/lajis/" + this.ruleForm.count,
        data: form,
        processData: false,
        contentType: "multipart/form-data",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
</style>
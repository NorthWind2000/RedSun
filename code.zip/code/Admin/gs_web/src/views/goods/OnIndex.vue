<template>
  <div class="FromGood">
    <el-form
      :model="goodForm"
      ref="goodForm"
      label-width="120px"
      class="demo-ruleForm"
    >
      <el-form-item label="商品名称">
        <el-input
          v-model="goodForm.gname"
          placeholder="请输入商品名称"
        ></el-input>
      </el-form-item>
      <el-form-item label="商品描述">
        <el-input
          v-model="goodForm.note"
          placeholder="请输入商品描述"
        ></el-input>
      </el-form-item>
      <el-form-item label="商品积分">
        <el-input-number
          v-model="goodForm.jifen"
          :precision="0"
          :step="1"
          :max="10000"
          :min="0"
        ></el-input-number>
      </el-form-item>
      <el-form-item label="轮播图">
        <el-upload
          action=""
          ref="lunboupload"
          :on-change="lunboChange"
          :file-list="lunbofileList"
          :auto-upload="false"
          :multiple="true"
          :on-remove="lunboRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item label="宣传图">
        <el-upload
          action=""
          ref="xuanchuanupload"
          :on-change="xuanchuanChange"
          :file-list="xuanchuanfileList"
          :auto-upload="false"
          :multiple="true"
          :on-remove="xuanchuanRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm()">立即添加</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>

export default {
  data() {
    return {
      options:[],
      lunbofileList: [],
      xuanchuanfileList: [],
      goodForm: {
        gname: "",
        note: "",
        jifen: 0,
      },
  }
  },
  methods: {
    // 提交商品
    submitForm() {
      let lunbofiles = this.$refs.lunboupload.uploadFiles;
      let xuanchuanfiles = this.$refs.xuanchuanupload.uploadFiles;

      let filedata = new FormData(); //创建form对象
      filedata.append("goodsform", JSON.stringify(this.goodForm));
      //轮播
      for (var i = 0; i < lunbofiles.length; i++) {
        filedata.append("lunbopic", lunbofiles[i].raw);
      }
      //宣传
      for (var i = 0; i < xuanchuanfiles.length; i++) {
        filedata.append("xuanchuanpic", xuanchuanfiles[i].raw);
      }
      //添加请求头
      let config = {
        headers: { "Content-Type": "multipart/form-data" },
      };

      this.myRequest({
        method: "post",
        url: "/goods",
        config,
        data: filedata,
      }).then((response) => {
        console.log("成功");
      });
    },
    // 处理移除图片的操作
    lunboRemove(file) {
        // 1. 获取将要删除的图片的临时路径
        const { name } = file;
        // 2. 从数组中，找到这个图片对应的索引值
        const i = this.lunbofileList.findIndex((item) => item.name == name);
        // 3. 调用数组的splice方法，把图片信息对象，从pics数组中移除
        this.lunbofileList.splice(i, 1);
    },
    xuanchuanRemove(file){
        // 1. 获取将要删除的图片的临时路径
        const { name } = file;
        // 2. 从数组中，找到这个图片对应的索引值
        const i = this.xuanchuanfileList.findIndex((item) => item.name == name);
        this.xuanchuanfileList.splice(i, 1);
    },
    lunboChange(file) {
      this.lunbofileList.push(file);
    },
    xuanchuanChange(file) {
      this.xuanchuanfileList.push(file);
    },
  }
};
</script>

<style scoped>
.FromGood {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
</style>
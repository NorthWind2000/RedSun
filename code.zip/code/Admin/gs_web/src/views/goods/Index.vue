<template>
  <div class="goodsindex">
    <!-- 搜索条件 -->
    <el-row :gutter="20" class="goodsindex-queryInfo">
      <!-- 商品名称搜索 -->
      <el-col :xs="8" :sm="6" :md="6" :lg="4" :xl="4">
        <el-input
          class="goodsindex-queryInfo-li"
          v-model="queryInfo.name"
          clearable
          size="small"
          placeholder="请输入产品名称"
        ></el-input>
      </el-col>
      <el-col :xs="6" :sm="4" :md="3" :lg="2" :xl="2">
        <el-button
          type="primary"
          class="goodsindex-queryInfo-li"
          size="small"
          @click="search"
          >搜索</el-button
        >
      </el-col>
    </el-row>
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="goodsData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="gid" label="ID" width="300">
          </el-table-column>
          <el-table-column prop="gname" label="名称" width="550">
          </el-table-column>
          <el-table-column prop="jifen" label="积分" width="80">
          </el-table-column>
          <el-table-column prop="address" label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="deleteRow(scope.$index)"
                type="text"
                size="small"
              >
                下架
              </el-button>
              <el-button
                @click.native.prevent="alterGoods(scope.$index)"
                type="text"
                size="small"
              >
                修改
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="goodstotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
    <!-- 修改商品弹窗 -->
    <el-dialog title="修改商品" :visible.sync="alterShow">
      <el-form :model="alterGoodsTable">
        <el-form-item
          label="商品名称"
          :label-width="formLabelWidth"
          prop="name"
        >
          <el-input
            v-model="alterGoodsTable.name"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="商品价格"
          :label-width="formLabelWidth"
          prop="price"
        >
          <el-input
            v-model="alterGoodsTable.price"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="alterSUbmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      alterShow: false,
      formLabelWidth: "100px",
      goodstotal: 0,
      queryInfo: {
        name: "",
        type: "",
        page: 1,
        pageSize: 7,
      },
      alterGoodsTable: {
        index: 0,
        name: "",
        price: "",
      },
      goodsData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/goods/allcount/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodstotal = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/goods/1/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodsData = res.data;
      }
    });
  },
  methods: {
    search() {
      this.myRequest({
        method: "get",
        url: "/goods/search/" + this.queryInfo.name + "/" + 1,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/goods/1/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    alterGoods(index) {
      this.alterGoodsTable.index = index;
      this.alterShow = true;
    },
    alterSUbmit() {
      this.alterShow = false;
      this.myRequest({
        method: "put",
        url: "/goods/" + this.goodsData[this.alterGoodsTable.index].gid,
        data: {
          name: this.alterGoodsTable.name,
          price: this.alterGoodsTable.price,
        },
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData[this.alterGoodsTable.index].lmtime = res.data;
        }
      });
    },
    deleteRow(index) {
      this.myRequest({
        method: "get",
        url: "/goods/xiajia/" + this.goodsData[index].gid,
      }).then((response) => {
        this.goodsData.splice(index, 1);
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
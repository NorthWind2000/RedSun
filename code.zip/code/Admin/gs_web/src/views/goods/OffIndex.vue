<template>
  <div class="goodsindex">
    <!-- 搜索条件 -->
    <el-row :gutter="20" class="goodsindex-queryInfo">
      <!-- 商品名称搜索 -->
      <el-col :xs="8" :sm="6" :md="6" :lg="4" :xl="4">
        <el-input
          class="goodsindex-queryInfo-li"
          v-model="queryInfo.name"
          clearable
          size="small"
          placeholder="请输入商品名称"
        ></el-input>
      </el-col>
      <el-col :xs="6" :sm="4" :md="3" :lg="2" :xl="2">
        <el-button
          type="primary"
          class="goodsindex-queryInfo-li"
          size="small"
          @click="search"
          >搜索</el-button
        >
      </el-col>
    </el-row>
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="goodsData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="gid" label="ID" width="300"> </el-table-column>
          <el-table-column prop="gname" label="名称" width="550">
          </el-table-column>
          <el-table-column prop="jifen" label="积分" width="80">
          </el-table-column>
          <el-table-column prop="address" label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="shangjia(scope.$index)"
                type="text"
                size="small"
              >
                上架
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="goodstotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      goodstotal: 0,
      queryInfo: {
        name: "",
        type: "",
        page: 1,
        pageSize: 7,
      },
      goodsData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/goods/allcount/0",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodstotal = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/goods/0/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodsData = res.data;
      }
    });
  },
  methods: {
    search() {
      this.myRequest({
        method: "get",
        url: "/goods/search/" + this.queryInfo.name + "/" + 0,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/goods/0/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    shangjia(index) {
      this.myRequest({
        method: "get",
        url: "/goods/shangjia/" + this.goodsData[index].gid,
      }).then((response) => {
        this.goodsData.splice(index, 1);
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
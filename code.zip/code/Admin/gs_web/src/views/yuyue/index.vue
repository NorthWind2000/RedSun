<template>
  <div class="goodsindex">
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="goodsData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="id" label="ID" width="250"> </el-table-column>
          <el-table-column prop="realname" label="用户" width="100">
          </el-table-column>
          <el-table-column prop="phone" label="电话" width="150">
          </el-table-column>
          <el-table-column prop="type" label="回收类型" width="100">
          </el-table-column>
          <el-table-column prop="dizhi" label="上门地址" width="300">
          </el-table-column>
          <el-table-column prop="time" label="预约时间" width="150">
          </el-table-column>
          <el-table-column prop="status" label="状态" width="80">
          </el-table-column>
          <el-table-column prop="address" label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="alterGoods(scope.$index)"
                type="text"
                size="small"
              >
                详情
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="goodstotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
    <!-- 详情弹窗 -->
    <el-dialog title="回收进程" :visible.sync="alterShow">
      <el-steps :active="active" finish-status="success">
        <el-step title="待接单"></el-step>
        <el-step title="已接单"></el-step>
        <el-step title="上门回收进行中"></el-step>
        <el-step title="回收完毕"></el-step>
        <el-step title="订单完成"></el-step>
      </el-steps>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="xiayibu">下一步</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      curitemid: "",
      index:0,
      active: 0,
      alterShow: false,
      formLabelWidth: "100px",
      goodstotal: 0,
      queryInfo: {
        name: "",
        type: "",
        page: 1,
        pageSize: 7,
      },
      goodsData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/yuyue/allcount",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodstotal = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/yuyue/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.goodsData = res.data;
      }
    });
  },
  methods: {
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/yuyue/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.goodsData = res.data;
        }
      });
    },
    alterGoods(index) {
      this.index=index
      this.alterShow = true;
      this.curitemid = this.goodsData[index].id;
      this.active=this.goodsData[index].status
    },
    xiayibu(index) {
      if (this.active < 5) {
        this.alterShow = false;
        this.myRequest({
          method: "put",
          url: "/yuyue/" + this.curitemid,
        });
        this.goodsData[this.index].status += 1;
        this.active+=1
      }
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
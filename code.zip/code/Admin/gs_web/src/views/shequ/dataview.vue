<template>
  <div class="goodsindex">
    <el-select v-model="xiaoquname" @change="change" placeholder="请选择">
      <el-option
        v-for="item in options"
        :key="item.id"
        :label="item.name"
        :value="item.id"
      >
      </el-option>
    </el-select>
    <el-select v-model="typename" placeholder="请选择">
      <el-option
        v-for="item in types"
        :key="item.id"
        :label="item.name"
        :value="item.id"
      >
      </el-option>
    </el-select>
    <el-button
      v-loading="loading"
      style="margin-left: 20px"
      type="primary"
      class="Carousel-Info-li"
      size="small"
      @click="check"
      >检索</el-button
    >
    <div v-html="texthtml"></div>
    <div id="d564f2ea75aa4c9a8cdf805972411388"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      xiaoqu: {
        name: "",
        province: "",
        city: "",
        county: "",
        detailaddress: "",
      },
      loading:false,
      texthtml: "",
      options: [],
      xiaoquname: "",
      xqid: "",
      typename: "",
      types: [
        {
          id: "1",
          name: "时间分布图",
        },
        {
          id: "2",
          name: "主图",
        },
        {
          id: "3",
          name: "可回收垃圾",
        },
        {
          id: "4",
          name: "厨余垃圾",
        },
        {
          id: "5",
          name: "有害垃圾",
        },
        {
          id: "6",
          name: "其他垃圾",
        },
      ],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/xiaoqu",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.options = res.data;
      }
    });
  },
  methods: {
    check() {
      if(this.xqid==""||this.typename==""){
        return
      }
      this.loading=true
      this.myRequest({
        method: "get",
        url: "/keshihua/" + this.xqid + "/" + this.typename,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.texthtml = res.data.picc;
          function st() {
             eval(res.data.jss);
          }
          setTimeout(st, 50);
          this.loading=false
        }else{
          this.loading=false
        }
      });
    },
    change(e) {
      this.xqid = e;
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
</style>
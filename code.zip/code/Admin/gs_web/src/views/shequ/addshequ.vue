<template>
  <div class="goodsindex">
    <el-form :model="xiaoqu" label-width="100px" class="demo-ruleForm">
      <el-form-item label="小区名称">
        <el-input style="width:400px" v-model="xiaoqu.name"></el-input>
      </el-form-item>
      <el-form-item label="所在省">
        <el-input style="width:400px" v-model="xiaoqu.province"></el-input>
      </el-form-item>
      <el-form-item label="所在市">
        <el-input style="width:400px" v-model="xiaoqu.city"></el-input>
      </el-form-item>
      <el-form-item label="所在县/区">
        <el-input style="width:400px" v-model="xiaoqu.county"></el-input>
      </el-form-item>
      <el-form-item label="详细地址">
        <el-input style="width:400px" v-model="xiaoqu.detailaddress"></el-input>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="submitone"
          >添加</el-button
        ></el-form-item
      >
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      xiaoqu: {
        name: "",
        province: "",
        city: "",
        county:"",
        detailaddress:""
      },
    };
  },
  methods: {
    submitone() {
      this.myRequest({
        method: "post",
        url: "/xiaoqu",
        data:this.xiaoqu
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
    submit() {
      let LJExcel = document.getElementById("LJExcel").files[0];
      if (LJExcel == null) {
        return;
      }
      let form = new FormData();
      form.append("file", LJExcel, LJExcel.name);

      this.myRequest({
        method: "post",
        url: "/lajis/" + this.ruleForm.count,
        data: form,
        processData: false,
        contentType: "multipart/form-data",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.$message({
            message: "添加成功",
            type: "success",
          });
        }
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
</style>
#include<iostream>
#include<vector>
#include<string>
using namespace std;
void dfs(int idx,vector<vector<int>> &a,vector<int>& b){
    b[idx] = 1;
    for(int v:a[idx]){
        if(b[v]==0){
            dfs(v,a,b);
        }
    }
    b[idx] = 2;
}

int main(){
    int n,m;
    cin>>n>>m;
    vector<vector<int>> a(b);
    vector<int> b(n,0);
    if(m==0){
        cout<<0<<endl;
        return 0;
    }
    for(int i=0;i<m;i++){
        int tmp1,tmp2;
        cin>>tmp1>>tmp2;
        a[tmp1].push_back(tmp2);
        a[tmp2].push_back(tmp1);
    }
    int ans = 0;
    for(int i=0;i<n,i++){
        if(b[i]==0){
            ans++;
            dfs(i,a,b);
        }
    }
    cout<<ans<<endl;
}
<template>
  <div class="goodsindex">
    <!-- 搜索条件 -->
    <el-row :gutter="20" class="goodsindex-queryInfo">
      <!-- 用户搜索 -->
      <el-col :xs="8" :sm="6" :md="6" :lg="4" :xl="4">
        <el-input
          class="goodsindex-queryInfo-li"
          v-model="queryInfo.searchkey"
          clearable
          size="small"
          placeholder="请输入小区名称"
        ></el-input>
      </el-col>
      <el-col :xs="6" :sm="4" :md="3" :lg="2" :xl="2">
        <el-button
          type="primary"
          class="goodsindex-queryInfo-li"
          size="small"
          @click="search"
          >搜索</el-button
        >
      </el-col>
    </el-row>
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="xiaoquData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="id" label="小区编号" width="250">
          </el-table-column>
          <el-table-column prop="name" label="小区名称" width="120">
          </el-table-column>
          <el-table-column prop="province" label="所在省" width="120">
          </el-table-column>
          <el-table-column prop="city" label="所在市" width="120">
          </el-table-column>
          <el-table-column prop="county" label="所在县/区" width="150">
          </el-table-column>
          <el-table-column prop="detailaddress" label="详细地址" width="250">
          </el-table-column>
          <el-table-column label="小区回收员" width="100">
            <template slot-scope="scope">
              <el-button
                v-if="xiaoquData[scope.$index].ishsyalter"
                @click.native.prevent="alterHuishouyuan(scope.$index)"
                type="text"
                size="small"
              >
                修改
              </el-button>
              <el-button
                v-else
                @click.native.prevent="alterHuishouyuan(scope.$index)"
                type="text"
                size="small"
              >
                添加
              </el-button>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="alterXiaoQu(scope.$index)"
                type="text"
                size="small"
              >
                修改
              </el-button>
              <el-button
                @click.native.prevent="del(scope.$index)"
                type="text"
                size="small"
              >
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="xiaoqutotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
    <!-- 修改小区回收员弹窗 -->
    <el-dialog title="小区回收员" :visible.sync="huishouyuanShow">
      <el-form>
        <el-form-item
          label="回收员姓名"
          :label-width="formLabelWidth"
          prop="realname"
        >
          <el-input
            v-model="alterHuishouyuanTable.realname"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="账号" :label-width="formLabelWidth" prop="account">
          <el-input
            v-model="alterHuishouyuanTable.account"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="密码"
          :label-width="formLabelWidth"
          prop="password"
        >
          <el-input
            v-model="alterHuishouyuanTable.password"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="手机号" :label-width="formLabelWidth" prop="phone">
          <el-input
            v-model="alterHuishouyuanTable.phone"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="alterhsySUbmit">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 修改小区弹窗 -->
    <el-dialog title="修改商品" :visible.sync="alterShow">
      <el-form>
        <el-form-item
          label="小区名称"
          :label-width="formLabelWidth"
          prop="name"
        >
          <el-input
            v-model="alterXiaoquTable.name"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="所在省"
          :label-width="formLabelWidth"
          prop="province"
        >
          <el-input
            v-model="alterXiaoquTable.province"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="所在市" :label-width="formLabelWidth" prop="city">
          <el-input
            v-model="alterXiaoquTable.city"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="所在县/区"
          :label-width="formLabelWidth"
          prop="county"
        >
          <el-input
            v-model="alterXiaoquTable.county"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="详细地址"
          :label-width="formLabelWidth"
          prop="detailaddress"
        >
          <el-input
            v-model="alterXiaoquTable.detailaddress"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="alterSUbmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      xiaoquid: "",
      xiaoquname:"",
      huishouyuanShow: false,
      alterShow: false,
      xiaoquData: [],
      detailShow: false,
      formLabelWidth: "100px",
      xiaoqutotal: 0,
      queryInfo: {
        searchkey: "",
        page: 1,
        pageSize: 8,
      },
      xiaoquData: [],
      alterXiaoquTable: {},
      alterHuishouyuanTable: {},
    };
  },
  created() {
    this.getInit();
  },
  methods: {
    search() {
      if (this.queryInfo.searchkey == "") {
        this.getInit();
        return;
      }
      this.myRequest({
        method: "get",
        url: "/xiaoqu/search/" + this.queryInfo.searchkey,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          var dd = res.data;
          this.xiaoquData = [];
          for (var i = 0; i < dd.length; i++) {
            this.xiaoquData.push(dd[i]);
            if (dd[i].huishouyuanid ==null) {
              this.xiaoquData[i].ishsyalter = false;
            } else {
              this.xiaoquData[i].ishsyalter = true;
            }
          }
        }
      });
    },
    getInit() {
      this.myRequest({
        method: "get",
        url: "/xiaoqu/allcount",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.xiaoqutotal = res.data;
        }
      });
      this.myRequest({
        method: "get",
        url: "/xiaoqu/1",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          var dd = res.data;
          this.xiaoquData = [];
          for (var i = 0; i < dd.length; i++) {
            this.xiaoquData.push(dd[i]);
            if (dd[i].huishouyuanid ==null) {
              this.xiaoquData[i].ishsyalter = false;
            } else {
              this.xiaoquData[i].ishsyalter = true;
            }
          }
        }
      });
    },
    handleCurrentChange() {
      var a = "";
      if (this.queryInfo.searchkey != "") {
        a = "search/" + this.queryInfo.searchkey + "/";
      }
      this.myRequest({
        method: "get",
        url: "/xiaoqu/" + a + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          var dd = res.data;
          this.xiaoquData = [];
          for (var i = 0; i < dd.length; i++) {
            this.xiaoquData.push(dd[i]);
            if (dd[i].huishouyuanid ==null) {
              this.xiaoquData[i].ishsyalter = false;
            } else {
              this.xiaoquData[i].ishsyalter = true;
            }
          }
        }
      });
    },
    alterXiaoQu(index) {
      this.alterXiaoquTable = this.xiaoquData[index];
      this.alterShow = true;
    },
    alterHuishouyuan(index) {
      this.alterHuishouyuanTable={}
      if (this.xiaoquData[index].huishouyuanid == null) {
        this.xiaoquid = this.xiaoquData[index].id;
        this.xiaoquname=this.xiaoquData[index].name;
      } else {
        this.myRequest({
          method: "get",
          url: "/huishouyuan/" + this.xiaoquData[index].huishouyuanid,
        }).then((response) => {
          var res = response.data;
          if (res.code == "200") {
            this.alterHuishouyuanTable = res.data;
          }
        });
      }
      this.huishouyuanShow = true;
    },
    alterSUbmit() {
      this.alterShow = false;
      this.myRequest({
        method: "put",
        url: "/xiaoqu",
        data: this.alterXiaoquTable,
      });
    },
    alterhsySUbmit() {
      this.huishouyuanShow = false;
      if (this.alterHuishouyuanTable.id == null) {
        this.myRequest({
          method: "post",
          url: "/huishouyuan/"+this.xiaoquid+"/"+this.xiaoquname,
          data: this.alterHuishouyuanTable,
        });
      } else {
        this.myRequest({
          method: "put",
          url: "/huishouyuan",
          data: this.alterHuishouyuanTable,
        });
      }
    },
    del(index) {
      this.myRequest({
        method: "delete",
        url: "/xiaoqu/" + this.xiaoquData[index].id,
      });
      this.xiaoquData.splice(index, 1);
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: bxiaoqu-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
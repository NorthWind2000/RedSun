<template>
  <div class="goodsindex">
    <el-select v-model="xiaoquname" @change="change" placeholder="请选择">
      <el-option
        v-for="item in options"
        :key="item.id"
        :label="item.name"
        :value="item.id"
      >
      </el-option>
    </el-select>
    <el-button style="margin-left:20px" plain @click="youke">游客用户</el-button>
    <!-- 检索结果 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="usersData" border size="small" style="width: 89%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="openid" label="账号" width="250">
          </el-table-column>
          <el-table-column prop="realname" label="姓名" width="150">
          </el-table-column>
          <el-table-column prop="phone" label="电话" width="180">
          </el-table-column>
          <el-table-column prop="jifen" label="积分" width="100">
          </el-table-column>
          <el-table-column prop="detailaddress" label="地址" width="320">
          </el-table-column>
          <el-table-column prop="xiaoqu" label="小区" width="150">
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="usertotal"
        >
        </el-pagination>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      alterShow: false,
      formLabelWidth: "100px",
      usertotal: 0,
      queryInfo: {
        account: "",
        type: "",
        page: 1,
        pageSize: 8,
      },
      usersData: [],
      options: [],
      xiaoquname: "",
      xqid:""
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/xiaoqu",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.options = res.data;
      }
    });
  },
  methods: {
    handleSizeChange() {},
    change(e) {
      this.xqid=e
      this.myRequest({
        method: "get",
        url: "/user/count/"+e,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.usertotal = res.data;
        }
      });
      this.myRequest({
        method: "get",
        url: "/user/1/"+e,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.usersData = res.data;
        }
      });
    },
    youke(){
      this.xqid="youke"
      this.myRequest({
        method: "get",
        url: "/user/count/youke",
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.usertotal = res.data;
        }
      });
      this.myRequest({
        method: "get",
        url: "/user/" + this.queryInfo.page+'/youke',
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.usersData = res.data;
        }
      });
    },
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/user/" + this.queryInfo.page+'/'+this.xqid,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.usersData = res.data;
        }
      });
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>
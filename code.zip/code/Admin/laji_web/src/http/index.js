import axios from 'axios'

// 创建axios实例
const service = axios.create({
    // baseURL: process.env.VUE_APP_BASE_API, //URL地址   环境变量文件 .env.development
    baseURL:"http://www.360zcc.top:8083",
    // baseURL:"http://127.0.0.1:8083",
    timeout: 5000 ,//超时
    withCredentials: false,  //跨域时若要发生cookie,需要设置该选项
})

// // 请求拦截器
// service.interceptors.request.use(
//     config => {
//         // 设置令牌请求头
//         config.headers['Authorization'] = getToken()
//         return config
//     },
//     error => {
//         return Promise.reject(error)
//     }
// )

export default service;
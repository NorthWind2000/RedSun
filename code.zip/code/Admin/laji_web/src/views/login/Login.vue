<template>
  <div class="login">
    <vue-particles
      class="login-bg"
      color="#39AFFD"
      :particleOpacity="0.7"
      :particlesNumber="100"
      shapeType="polygon"
      :particleSize="4"
      linesColor="#8DD1FE"
      :linesWidth="1"
      :lineLinked="true"
      :lineOpacity="0.4"
      :linesDistance="150"
      :moveSpeed="3"
      :hoverEffect="true"
      hoverMode="grab"
      :clickEffect="true"
      clickMode="push"
    >
    </vue-particles>
    <!-- 登录面板 -->
    <div class="login-box">
      <div class="login-box-title">后台管理系统</div>
      <div class="login-box-from">
        <el-form
          :model="loginForm"
          :rules="rules"
          ref="loginForm"
          class="demo-ruleForm"
        >
          <el-form-item prop="username">
            <el-input
              v-model="loginForm.username"
              placeholder="请输入用户名"
              size="medium"
            >
              <el-button slot="prepend" icon="el-icon-user"></el-button>
            </el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              show-password
              v-model="loginForm.password"
              placeholder="请输入密码"
              size="medium"
            >
              <el-button slot="prepend" icon="el-icon-key"></el-button>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="medium"
              :loading="loading"
              style="width: 100%"
              @click="submitForm('loginForm')"
              >立即登陆</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { setToken } from "@/utils/auth";

export default {
  data() {
    let letterRule = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("输入内容不能为空"));
      } else {
        callback();
      }
    };
    return {
      loading: false, //登陆状态
      loginForm: {
        // 登陆表单
        username: "",
        password: "",
      },
      rules: {
        //登陆验证规则
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          {
            min: 3,
            max: 18,
            message: "长度在 3 到 18 个字符",
            trigger: "blur",
          },
          { validator: letterRule, trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          {
            min: 0,
            max: 16,
            message: "长度在 6 到 18 个字符",
            trigger: "blur",
          },
          { validator: letterRule, trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loading = true;
          this.login();
        } else {
          // console.log('error submit!!');
          return false;
        }
      });
    },
    login() {
      axios({
        method: "get",
        url:"http://www.360zcc.top:8083/admin/login?account=" +this.loginForm.username +"&password=" +this.loginForm.password,
      })
        .then((response) => {
          this.loading = false;
          var res=response.data
          if (res.code == '200') {
            this.setToken(res.data)
            // 登陆成功后重定向
            this.$router.push({
              path: this.$route.query.redirect || "/index",
            });
          }
        })
        .catch((err) => {
          this.loading = true;
          // console.log(err)
        });
    },
  },
};
</script>

<style scoped>
.login {
  width: 100%;
  height: 100%;
  position: relative;
}
.login-bg {
  width: 100%;
  height: 100%;
  background: #3e3e3e;
}
.login-box {
  width: 350px;
  background: hsla(0, 0%, 100%, 0.3);
  border-radius: 5px;
  box-shadow: 0 0 2px #f7f7f7;
  border: 1px solid #f7f7f7;
  position: absolute;
  left: 50%;
  top: 50%;
  margin-left: -175px;
  margin-top: -150px;
}
.login-box-title {
  line-height: 50px;
  font-size: 20px;
  color: #ffffff;
  text-align: center;
  border-bottom: 1px solid #ffffff;
}
.login-box-from {
  width: 100%;
  height: auto;
  padding: 30px;
  box-sizing: border-box;
}
</style>
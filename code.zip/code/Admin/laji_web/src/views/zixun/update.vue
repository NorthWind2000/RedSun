<template>
  <div>
    <el-form
      style="margin-top: 20px; margin-right: 20px"
      :model="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="文章标题">
        <el-input v-model="ruleForm.title"></el-input>
      </el-form-item>
      <el-form-item label="文章摘要">
        <el-input v-model="ruleForm.summary"></el-input>
      </el-form-item>
      <el-form-item label="封面">
        <el-upload
          action=""
          ref="fengmianupload"
          :auto-upload="false"
          :multiple="false"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </el-form-item>
    </el-form>
    <el-divider content-position="left">文章内容编辑</el-divider>
    <div style="margin: 10px 300px">
      <editor-bar
        v-model="detail"
        :isClear="isClear"
        @change="change"
        @clearend="clearend"
      ></editor-bar>
    </div>
    <el-row style="width: 100px; height: 50px; margin: 10px auto;display:flex;">
      <el-button @click="sumbit" type="primary" round>提交</el-button>
      <el-button @click="clear" type="primary" round>清空</el-button>
    </el-row>
  </div>
</template>  
<script>
import EditorBar from "../../components/wangEnduit";
export default {
  components: { EditorBar },
  data() {
    return {
      imageUrl: "",
      test: "",
      isClear: false,
      detail: "",
      fengmian: [],
      ruleForm: {
        title: "",
        content: "",
        summary:""
      },
    };
  },
  methods: {
    change(val) {
      this.ruleForm.content=val
    },
    sumbit() {
      let fengmianimg = this.$refs.fengmianupload.uploadFiles;

      let filedata = new FormData(); //创建form对象
      filedata.append("zixun", JSON.stringify(this.ruleForm));
      filedata.append("fengmian", fengmianimg[0].raw);
      //添加请求头
      let config = {
        headers: { "Content-Type": "multipart/form-data" },
      };

      this.myRequest({
        method: "post",
        url: "/zixun",
        config,
        data: filedata,
      }).then((response) => {
       this.$message({
          message: '提交成功',
          type: 'success'
        });
      });
    },
    clear(){
      this.isClear=true
    },
    clearend(){
      this.isClear=false
    }
  },
};
</script>

<style scoped>

</style>
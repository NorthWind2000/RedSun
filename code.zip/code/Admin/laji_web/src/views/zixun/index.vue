<template>
  <div class="goodsindex">
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24">
        <el-table :data="zixunData" border size="small" style="width: 100%">
          <el-table-column type="index" label="序" width="50">
          </el-table-column>
          <el-table-column prop="id" label="ID" width="250"> </el-table-column>
          <el-table-column prop="title" label="标题" width="500">
          </el-table-column>
          <el-table-column prop="status" label="状态" width="100">
          </el-table-column>
          <el-table-column prop="publishtime" label="发布时间" width="200">
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="xiajia(scope.$index)"
                type="text"
                size="small"
              >
                下线
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <!-- 分页 -->
    <el-row :gutter="20" class="goodsindex-list">
      <el-col :span="24" class="goodsindex-page-box">
        <el-pagination
          :hide-on-single-page="true"
          @current-change="handleCurrentChange"
          :current-page.sync="queryInfo.page"
          :page-size="queryInfo.pageSize"
          :total="total"
        >
        </el-pagination>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formLabelWidth: "100px",
      total: 0,
      queryInfo: {
        name: "",
        page: 1,
        pageSize: 8,
      },
      zixunData: [],
    };
  },
  created() {
    this.myRequest({
      method: "get",
      url: "/zixun/1/allcount",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.total = res.data;
      }
    });
    this.myRequest({
      method: "get",
      url: "/zixun/1/1",
    }).then((response) => {
      var res = response.data;
      if (res.code == "200") {
        this.zixunData = res.data;
      }
    });
  },
  methods: {
    handleCurrentChange() {
      this.myRequest({
        method: "get",
        url: "/zixun/1/" + this.queryInfo.page,
      }).then((response) => {
        var res = response.data;
        if (res.code == "200") {
          this.zixunData = res.data;
        }
      });
    },
    xiajia(index) {
      this.myRequest({
        method: "get",
        url: "/zixun/xiajia/" + this.zixunData[index].id,
      });
      this.zixunData.splice(index, 1);
    },
  },
};
</script>

<style scoped>
.goodsindex {
  width: 100%;
  min-height: 100%;
  padding: 15px;
  box-sizing: border-box;
}
/* 搜索 */
.goodsindex-queryInfo {
  margin-bottom: 10px;
}
.goodsindex-queryInfo-li {
  width: 100%;
  height: auto;
}
/* 列表 */
.goodsindex-list {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}
/* 分页 */
.goodsindex-page-box {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
}
</style>